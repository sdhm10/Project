#include "GameObject.h"

bool GameObject::Init_Room1()
{

	// ������Ʈ 2 ~ 61�� �� �ܺ�
	// 1�� �� ���� ��
	obj[2].OBJ_TYPE = OBJ_WALL;
	obj[2].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[2].x = 0.f;
	obj[2].y = 0.f;
	obj[2].width = WALL_SIZE;
	obj[2].height = WINSIZEY;
	obj[2].isAlive = true;
	obj[2].isWall = true;
	obj[2].isItem = false;
	obj[2].rcObject = RectMake(obj[2].x, obj[2].y, obj[2].width, obj[2].height);

	// 1�� �� ���� ��
	obj[3].OBJ_TYPE = OBJ_WALL;
	obj[3].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[3].x = 0.f;
	obj[3].y = 0.f;
	obj[3].width = WINSIZEX;
	obj[3].height = WALL_SIZE;
	obj[3].isAlive = true;
	obj[3].isWall = true;
	obj[3].isItem = false;
	obj[3].rcObject = RectMake(obj[3].x, obj[3].y, obj[3].width, obj[3].height);

	// 1�� �� �Ʒ��� ��
	obj[4].OBJ_TYPE = OBJ_WALL;
	obj[4].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[4].x = 0.f;
	obj[4].y = WINSIZEY - WALL_SIZE;
	obj[4].width = WINSIZEX;
	obj[4].height = WALL_SIZE;
	obj[4].isAlive = true;
	obj[4].isWall = true;
	obj[4].isItem = false;
	obj[4].rcObject = RectMake(obj[4].x, obj[4].y, obj[4].width, obj[4].height);

	// 1�� �� ������ �� ��
	obj[5].OBJ_TYPE = OBJ_WALL;
	obj[5].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[5].x = WINSIZEX - WALL_SIZE;
	obj[5].y = 0.f;
	obj[5].width = WALL_SIZE;
	obj[5].height = (WINSIZEY - WALL_SIZE) / 2;
	obj[5].isAlive = true;
	obj[5].isWall = true;
	obj[5].isItem = false;
	obj[5].rcObject = RectMake(obj[5].x, obj[5].y, obj[5].width, obj[5].height);

	// 1�� �� ������ �Ʒ� ��
	obj[6].OBJ_TYPE = OBJ_WALL;
	obj[6].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[6].x = WINSIZEX - WALL_SIZE;
	obj[6].y = WINSIZEY / 2 + WALL_SIZE / 2;
	obj[6].width = WALL_SIZE;
	obj[6].height = (WINSIZEY - WALL_SIZE) / 2;
	obj[6].isAlive = true;
	obj[6].isWall = true;
	obj[6].isItem = false;
	obj[6].rcObject = RectMake(obj[6].x, obj[6].y, obj[6].width, obj[6].height);

	// 1�� �� ������ ��
	obj[7].OBJ_TYPE = OBJ_DOOR;
	obj[7].image = IMAGEMANAGER->FindImage(TEXT("Door"));
	obj[7].x = WINSIZEX - WALL_SIZE;
	obj[7].y = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[7].width = WALL_SIZE;
	obj[7].height = WALL_SIZE;
	obj[7].isAlive = false;
	obj[7].isWall = true;
	obj[7].isItem = false;
	obj[7].rcObject = RectMake(obj[7].x, obj[7].y, obj[7].width, obj[7].height);

	return true;
}