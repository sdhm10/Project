#include "GameObject.h"


bool GameObject::Init_Room5()
{

	// 5�� �� ���� ��
	obj[32].OBJ_TYPE = OBJ_WALL;
	obj[32].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[32].x = 0.f;
	obj[32].y = WINSIZEY * 2;
	obj[32].width = WALL_SIZE;
	obj[32].height = WINSIZEY;
	obj[32].isAlive = true;
	obj[32].isWall = true;
	obj[32].isItem = false;
	obj[32].rcObject = RectMake(obj[32].x, obj[32].y, obj[32].width, obj[32].height);

	// 5�� �� �� ���� ��
	obj[33].OBJ_TYPE = OBJ_WALL;
	obj[33].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[33].x = 0.f;
	obj[33].y = WINSIZEY * 2;
	obj[33].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[33].height = WALL_SIZE;
	obj[33].isAlive = true;
	obj[33].isWall = true;
	obj[33].isItem = false;
	obj[33].rcObject = RectMake(obj[33].x, obj[33].y, obj[33].width, obj[33].height);

	// 5�� �� �� ������ ��
	obj[34].OBJ_TYPE = OBJ_WALL;
	obj[34].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[34].x = WINSIZEX / 2 + WALL_SIZE / 2;
	obj[34].y = WINSIZEY * 2;
	obj[34].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[34].height = WALL_SIZE;
	obj[34].isAlive = true;
	obj[34].isWall = true;
	obj[34].isItem = false;
	obj[34].rcObject = RectMake(obj[34].x, obj[34].y, obj[34].width, obj[34].height);

	// 5�� �� ���� ��
	obj[35].OBJ_TYPE = OBJ_DOOR;
	obj[35].image = IMAGEMANAGER->FindImage(TEXT("Door"));
	obj[35].x = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[35].y = WINSIZEY * 2;
	obj[35].width = WALL_SIZE;
	obj[35].height = WALL_SIZE;
	obj[35].isAlive = false;
	obj[35].isWall = true;
	obj[35].isItem = false;
	obj[35].rcObject = RectMake(obj[35].x, obj[35].y, obj[35].width, obj[35].height);

	// 5�� �� �Ʒ��� ��
	obj[36].OBJ_TYPE = OBJ_WALL;
	obj[36].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[36].x = 0.f;
	obj[36].y = WINSIZEY * 3 - WALL_SIZE;
	obj[36].width = WINSIZEX;
	obj[36].height = WALL_SIZE;
	obj[36].isAlive = true;
	obj[36].isWall = true;
	obj[36].isItem = false;
	obj[36].rcObject = RectMake(obj[36].x, obj[36].y, obj[36].width, obj[36].height);

	// 5�� �� ������ �� ��
	obj[37].OBJ_TYPE = OBJ_WALL;
	obj[37].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[37].x = WINSIZEX - WALL_SIZE;
	obj[37].y = WINSIZEY * 2;
	obj[37].width = WALL_SIZE;
	obj[37].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[37].isAlive = true;
	obj[37].isWall = true;
	obj[37].isItem = false;
	obj[37].rcObject = RectMake(obj[37].x, obj[37].y, obj[37].width, obj[37].height);

	// 5�� �� ������ �Ʒ� ��
	obj[38].OBJ_TYPE = OBJ_WALL;
	obj[38].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[38].x = WINSIZEX - WALL_SIZE;
	obj[38].y = WINSIZEY * 2 + (WINSIZEY / 2 + WALL_SIZE / 2);
	obj[38].width = WALL_SIZE;
	obj[38].height = (WINSIZEY - WALL_SIZE) / 2;
	obj[38].isAlive = true;
	obj[38].isWall = true;
	obj[38].isItem = false;
	obj[38].rcObject = RectMake(obj[38].x, obj[38].y, obj[38].width, obj[38].height);

	// 5�� �� ������ ��
	obj[39].OBJ_TYPE = OBJ_DOOR;
	obj[39].image = IMAGEMANAGER->FindImage(TEXT("Door"));
	obj[39].x = WINSIZEX - WALL_SIZE;
	obj[39].y = WINSIZEY * 2 + (WINSIZEY / 2 - WALL_SIZE / 2);
	obj[39].width = WALL_SIZE;
	obj[39].height = WALL_SIZE;
	obj[39].isAlive = true;
	obj[39].isWall = true;
	obj[39].isItem = false;
	obj[39].rcObject = RectMake(obj[39].x, obj[39].y, obj[39].width, obj[39].height);




	// 5�� �� ��ֹ� 1
	obj[74].OBJ_TYPE = OBJ_STONE;
	obj[74].image = IMAGEMANAGER->FindImage(TEXT("Stone"));
	obj[74].x = (WINSIZEX / 2) - (WALL_SIZE / 2);
	obj[74].y = (WINSIZEY * 2) + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[74].width = WALL_SIZE;
	obj[74].height = WALL_SIZE;
	obj[74].isAlive = true;
	obj[74].isWall = true;
	obj[74].isItem = false;
	obj[74].rcObject = RectMake(obj[74].x, obj[74].y, obj[74].width, obj[74].height);

	// 5�� �� ��ֹ� 2
	obj[75].OBJ_TYPE = OBJ_STONE;
	obj[75].image = IMAGEMANAGER->FindImage(TEXT("Stone"));
	obj[75].x = (WINSIZEX / 4) - (WALL_SIZE / 2);
	obj[75].y = (WINSIZEY * 2) + (WINSIZEY / 2) - (WALL_SIZE / 2);
	obj[75].width = WALL_SIZE;
	obj[75].height = WALL_SIZE;
	obj[75].isAlive = true;
	obj[75].isWall = true;
	obj[75].isItem = false;
	obj[75].rcObject = RectMake(obj[75].x, obj[75].y, obj[75].width, obj[75].height);

	// 5�� �� ��ֹ� 3
	obj[76].OBJ_TYPE = OBJ_STONE;
	obj[76].image = IMAGEMANAGER->FindImage(TEXT("Stone"));
	obj[76].x = (WINSIZEX / 4 * 3) - (WALL_SIZE / 2);
	obj[76].y = (WINSIZEY * 2) + (WINSIZEY / 2) - (WALL_SIZE / 2);
	obj[76].width = WALL_SIZE;
	obj[76].height = WALL_SIZE;
	obj[76].isAlive = true;
	obj[76].isWall = true;
	obj[76].isItem = false;
	obj[76].rcObject = RectMake(obj[76].x, obj[76].y, obj[76].width, obj[76].height);

	// 5�� �� ��ֹ� 4
	obj[77].OBJ_TYPE = OBJ_STONE;
	obj[77].image = IMAGEMANAGER->FindImage(TEXT("Stone"));
	obj[77].x = (WINSIZEX / 2) - (WALL_SIZE / 2);
	obj[77].y = (WINSIZEY * 2) + (WINSIZEY / 4 * 3) - (WALL_SIZE / 2);
	obj[77].width = WALL_SIZE;
	obj[77].height = WALL_SIZE;
	obj[77].isAlive = true;
	obj[77].isWall = true;
	obj[77].isItem = false;
	obj[77].rcObject = RectMake(obj[77].x, obj[77].y, obj[77].width, obj[77].height);


	// 5���� ȸ�� ������ 1
	obj[89].image = IMAGEMANAGER->AddFrameImage(TEXT("HealthPack"), TEXT("Image/HealthPack.bmp"), 42, 30, 1, 1, true, RGB(0, 255, 0));
	obj[89].x = (WINSIZEX / 2);
	obj[89].y = (WINSIZEY * 2) + (WINSIZEY / 2) - (ITEM_HEIGHT / 2);							// ��ġ Y
	obj[89].width = ITEM_WIDTH;									// ��
	obj[89].height = ITEM_HEIGHT;								// ����
	obj[89].isAlive = true;										// ��������
	obj[89].isWall = false;										// ���ΰ�?
	obj[89].isItem = true;										// �������ΰ�?
	obj[89].dir = DIRECTION::DIR_NONE;							// ��������ΰ�?
	obj[89].rcObject = RectMakeCenter(obj[89].x, obj[89].y, obj[89].width, obj[89].height);


	return true;
}