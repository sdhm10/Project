#include "GameObject.h"

bool GameObject::Init_Room8()
{
	// 8�� �� ���� ��
	obj[56].OBJ_TYPE = OBJ_WALL;
	obj[56].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[56].x = 0.f;
	obj[56].y = WINSIZEY * 3;
	obj[56].width = WALL_SIZE;
	obj[56].height = WINSIZEY;
	obj[56].isAlive = true;
	obj[56].isWall = true;
	obj[56].isItem = false;
	obj[56].rcObject = RectMake(obj[56].x, obj[56].y, obj[56].width, obj[56].height);

	// 8�� �� ���� ��
	obj[57].OBJ_TYPE = OBJ_WALL;
	obj[57].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[57].x = 0.f;
	obj[57].y = WINSIZEY * 3;
	obj[57].width = WINSIZEX;
	obj[57].height = WALL_SIZE;
	obj[57].isAlive = true;
	obj[57].isWall = true;
	obj[57].isItem = false;
	obj[57].rcObject = RectMake(obj[57].x, obj[57].y, obj[57].width, obj[57].height);

	// 8�� �� �Ʒ��� ��
	obj[58].OBJ_TYPE = OBJ_WALL;
	obj[58].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[58].x = 0.f;
	obj[58].y = WINSIZEY * 4 - WALL_SIZE;
	obj[58].width = WINSIZEX;
	obj[58].height = WALL_SIZE;
	obj[58].isAlive = true;
	obj[58].isWall = true;
	obj[58].isItem = false;
	obj[58].rcObject = RectMake(obj[58].x, obj[58].y, obj[58].width, obj[58].height);

	// 8�� �� ������ �� ��
	obj[59].OBJ_TYPE = OBJ_WALL;
	obj[59].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[59].x = WINSIZEX - WALL_SIZE;
	obj[59].y = WINSIZEY * 3;
	obj[59].width = WALL_SIZE;
	obj[59].height = (WINSIZEY - WALL_SIZE) / 2;
	obj[59].isAlive = true;
	obj[59].isWall = true;
	obj[59].isItem = false;
	obj[59].rcObject = RectMake(obj[59].x, obj[59].y, obj[59].width, obj[59].height);

	// 8�� �� ������ �Ʒ� ��
	obj[60].OBJ_TYPE = OBJ_WALL;
	obj[60].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[60].x = WINSIZEX - WALL_SIZE;
	obj[60].y = WINSIZEY * 3 + (WINSIZEY / 2 + WALL_SIZE / 2);
	obj[60].width = WALL_SIZE;
	obj[60].height = (WINSIZEY - WALL_SIZE) / 2;
	obj[60].isAlive = true;
	obj[60].isWall = true;
	obj[60].isItem = false;
	obj[60].rcObject = RectMake(obj[60].x, obj[60].y, obj[60].width, obj[60].height);

	return true;
}