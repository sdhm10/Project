#include "StalkerTest.h"


StalkerTest::StalkerTest()
{
	gameObject = new GameObject;
	player = new Player;
	enemy = new Enemy;
	bullets = new Bullets;

	StartImage = IMAGEMANAGER->AddImage(TEXT("Start"), TEXT("Image/StartImage.bmp"), 1000, 800, false, false);
	LandImage = IMAGEMANAGER->AddImage(TEXT("Land"), TEXT("Image/Land.bmp"), 1000, 800, false, false);
	ReWardImage = IMAGEMANAGER->AddImage(TEXT("Reward"), TEXT("Image/Reward.bmp"), 1000, 800, false, false);
	Start = false;
}


StalkerTest::~StalkerTest()
{
	delete gameObject;
	delete player;
	delete enemy;
	delete bullets;
}

bool StalkerTest::Init()
{
	_ClearRoom = RectMake( 0, WINSIZEY * 3, WINSIZEX ,WINSIZEY );		// Ŭ�����
	_rcClient = { 0,0, WINSIZEX, WINSIZEY };					// ī�޶� �׽�Ʈ Ŭ���̾�Ʈ
	_rcWorld = { 0,0, WINSIZEX*5, WINSIZEY*5 };					// ī�޶� �׽�Ʈ ����

	// Bullet Init
	bullets->Init();
	// GameObject Init
	gameObject->Init();
	// Player Init
	player->Init();
	// Enemy Group Init
	enemy->Init();


	if (CAMERA->Init(player->GetPos(), _rcClient, _rcWorld) == false)
	{
		return false;
	}


	//
	HitPlayer = 0;
	HitWall = 0;

	return true;
}

void StalkerTest::Release()
{
	gameObject->Release();
	player->Release();
	enemy->Release();
	bullets->Release();
}


void StalkerTest::Update()
{
	if (!Start)
	{
		if (KEYMANAGER->isOnceKeyDown(VK_SPACE))
		{
			player->SetIsAlive(true);
			Start = true;
		}
	}
	else
	{
		EFFECTMANAGER->Update();

		//////////
		// źȯ �׷� ��ü ������Ʈ �Լ�
		player->Update(*bullets);
		enemy->Update(*bullets, *player);
		gameObject->Update(*bullets, *player, *enemy);
		bullets->Update();
		////////////

		//// źȯ�� ���� ��쿡 ���� �浹ó�� �̺�Ʈ �Լ� 
		HitEvent();
		////////////

		CAMERA->Update();			// ī�޶� ������Ʈ

		//if (GetTickCount() - DeadTime > 5000.f && isAlive == true) {
		//	isAlive = false;
		//}


		if (!player->GetIsAlive() && KEYMANAGER->isOnceKeyDown(VK_SPACE))
		{
			Start = false;
			// Bullet Init
			bullets->Init();
			// GameObject Init
			gameObject->Init();
			// Player Init
			player->Init();
			// Enemy Group Init
			enemy->Init();
		}

		if (CollisionRectAndRect(player->CollisionRECT(), _ClearRoom) && KEYMANAGER->isOnceKeyDown(VK_SPACE))
		{
			Start = false;
			// Bullet Init
			bullets->Init();
			// GameObject Init
			gameObject->Init();
			// Player Init
			player->Init();
			// Enemy Group Init
			enemy->Init();
		}
	}
}

void StalkerTest::Render(HDC hdc)
{

	LandImage->Render(hdc);
	ReWardImage->Render(hdc, 0 - CAMERA->getPosition()->x, WINSIZEY*3 - CAMERA->getPosition()->y);
	// źȯ �׷� ��ü ������ �Լ�;
	gameObject->Render(hdc);
	bullets->Render(hdc);
	enemy->Render(hdc);
	player->Render(hdc);




	// �׽�Ʈ��
	TCHAR szTemp[100] = { 0, };
	_stprintf_s(szTemp, _countof(szTemp), TEXT("HitPlayer  :  %d,	PlayerHP : %d"), HitPlayer, player->GetHp());
	TextOut(hdc, WINSIZEX / 2 - 60, 30, szTemp, static_cast<int>(_tcslen(szTemp)));
	_stprintf_s(szTemp, _countof(szTemp), TEXT("HitWall  :  %d"), HitWall);
	TextOut(hdc, WINSIZEX / 2 - 60, 50, szTemp, static_cast<int>(_tcslen(szTemp)));


	if (!Start)
		StartImage->Render(hdc);
	
}



// źȯ�� ���� ��쿡 ���� �浹ó�� �̺�Ʈ �Լ� 
void StalkerTest::HitEvent()
{
	// �� �迭	źȯ-�� �浹ó��
	enemy->HitEvent(*bullets);


	// �÷��̾� - �� źȯ �浹ó��
	// player.HitEvent(bullets);
	bool temp = player->HitEvent(*bullets);
	if (temp)
	{
		// ���⿡ �̺�Ʈ�� �ǰ� �̺�Ʈ�� �߻��Ѵ�.
		HitPlayer++;
	}


}