#pragma once

#include "GameNode.h"
#include "GameHeader.h"
#include "Animation.h"
#include "Player.h"

#define	MAX_MONSTER 31

struct Monster
{
	Image*		image;
	Animation*  ani;
	RECT		rcMonster;	// �浹�ڽ�

	float		posX;			// ��ġX
	float		posY;			// ��ġY
	float		angle;			// ����
	float		endX;			// �ѽ� �� X
	float		endY;			// �ѽ� �� Y
	float		length;			// �ѽ� ����
	int			radius;			// ũ��
	float		realizeRange;	// �ν� ����
	int			hp;				// ü��
	float		speed;			// �ӵ�
	int			checkRealPos;
	bool		isAlive;		// ����üũ
	bool		isPlayer;		// ���� false

	MONSTERTYPE type;
	STATE		state;			// ����
	DIRECTION	monDir;			// ����

	POINT		CameraPos;		// ī�޶� ������
};
class Enemy	: public GameNode
{
private:
	Image* MonsterImageType[4];
	Image*  HPImage;
	RECT	_HPbar;
	Monster	_Monster[MAX_MONSTER];

	int		_Bossphasenum;
	int		_BossPattern;
	DWORD	_BossTickCount;
public:
	Enemy();
	~Enemy();

	virtual bool Init();
	virtual void Release();
	virtual void Update(Bullets& inputBullets, Player& inputPlayer);
	virtual void Render(HDC hdc);

	
	void HitEvent(Bullets& inputBullets);
	void EnemyMove(Bullets& inputBullets, Player& inputPlayer);


	void TurretMove(Monster & inputMonster, Bullets& inputBullets, Player& inputPlayer);
	void HomingMove(Monster& inputMonster, Bullets& inputBullets, Player& inputPlayer);
	void ShootingMove(Monster & inputMonster, Bullets & inputBullets, Player & inputPlayer);
	void BossMove(Monster & inputMonster, Bullets & inputBullets, Player & inputPlayer);

	void EnemyFire(Monster& inputMonster, Bullets& inputBullets);

	
	void BossPattern1(Monster& boss, Bullets& bullet, int phasenum);
	void BossPattern2(Monster& boss, Bullets& bullet, int phasenum);
	void BossPattern3(Monster& boss, Bullets& bullet, int phasenum);


	// ī�޶� �Ŵ��� ����
	void	SetPos(int inputIndex, POINT p) { _Monster[inputIndex].CameraPos = p; }
	POINT*	GetPos(int inputIndex) { return &_Monster[inputIndex].CameraPos; }
	//

	//==============================================================================================
	// Get �Լ�
	inline bool GetIsPlayer(int inputEnemyIndex) { return _Monster[inputEnemyIndex].isPlayer; }					// ����ڰ� �� źȯ�ΰ�? �ƴϸ� ���� �� źȯ�ΰ�?
	inline bool GetIsAlive(int inputEnemyIndex) { return _Monster[inputEnemyIndex].isAlive; }					// ���� ���� ����
	inline float GetX(int inputEnemyIndex) { return _Monster[inputEnemyIndex].posX; }							// ���� ��ġ X
	inline float GetY(int inputEnemyIndex) { return _Monster[inputEnemyIndex].posY; }							// ���� ��ġ Y
	inline float GetSpeed(int inputEnemyIndex) { return _Monster[inputEnemyIndex].speed; }						// ���� �ӵ�
	inline float GetAngle(int inputEnemyIndex) { return _Monster[inputEnemyIndex].angle; }						// ���� ����
	inline int GetRadius(int inputEnemyIndex) { return _Monster[inputEnemyIndex].radius; }						// ���� ������
	inline int GetHP(int inputEnemyIndex) { return _Monster[inputEnemyIndex].hp; }								// ���� HP
	inline RECT CollisionRECT(int inputEnemyIndex) { return _Monster[inputEnemyIndex].rcMonster; }				// ���� �簢�� �浹��ü

	inline int GetCheckRealPos(int inputEnemyIndex) { return _Monster[inputEnemyIndex].checkRealPos; }

	// Set �Լ�
	inline void SetIsPlayer(int inputEnemyIndex, bool inputIsPlayer) { _Monster[inputEnemyIndex].isPlayer = inputIsPlayer; }
	inline void SetIsAlive(int inputEnemyIndex, bool inputIsAlive) { _Monster[inputEnemyIndex].isAlive = inputIsAlive; }
	inline void SetX(int inputEnemyIndex, float inputX) { _Monster[inputEnemyIndex].posX = inputX; }
	inline void SetY(int inputEnemyIndex, float inputY) { _Monster[inputEnemyIndex].posY = inputY; }
	inline void SetSpeed(int inputEnemyIndex, float inputSpeed) { _Monster[inputEnemyIndex].speed = inputSpeed; }
	inline void SetAngle(int inputEnemyIndex, float inputAngle) { _Monster[inputEnemyIndex].angle = inputAngle; }
	inline void SetRadius(int inputEnemyIndex, int inputRadius) { _Monster[inputEnemyIndex].radius = inputRadius; }
	inline void SetHP(int inputEnemyIndex, int inputHP) { _Monster[inputEnemyIndex].hp = inputHP; }

	//==============================================================================================

};

