#pragma once

#pragma warning(disable:4996)

// �ý��� ���
#include <Windows.h>
#include <assert.h>
#include <tchar.h>
#include <stdio.h>
#include <math.h>

#include <iostream>
#include <algorithm>
#include <string>
#include <vector>
#include <array>
#include <list>
#include <map>

using std::string;
using std::vector;
using std::list;
using std::map;


// ����� ���
#include "CustomDefine.h"
#include "Util.h"
#include "CommonMacroFunction.h"
#include "CollisionFunction.h"
#include "Image.h"

//  �̱��� ���
#include "RandomFunction.h"
#include "KeyManager.h"
#include "TimeManager.h"
#include "ImageManager.h"
#include "Camera.h"
#include "EffectManager.h"

// �̱��� ��ü ��ũ��
#define RAND			RandomFunction::getSingleton()
#define CAMERA			Camera::getSingleton()
#define KEYMANAGER		KeyManager::getSingleton()
#define TIMEMANAGER		TimeManager::getSingleton()
#define IMAGEMANAGER	ImageManager::getSingleton()
#define EFFECTMANAGER	EffectManager::getSingleton()

// ������ ���̰��� ��ũ��
#define WINSTYLE		WS_CAPTION | WS_SYSMENU
#define WINSIZEX		1000
#define WINSIZEY		800
#define WINSTARTX		100
#define WINSTARTY		100

// �޸� ���� ��ũ��
#define SAFE_DELETE(p)	{if(p) {delete (p); (p) = NULL;}}
#define SAFE_RELEASE(p)	{if(p) {(p)->Release(); (p) = NULL;}}

