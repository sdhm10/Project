#include "MainGame.h"

MainGame::MainGame()
{

}

MainGame::~MainGame()
{
}


bool MainGame::Init()
{
	GameNode::Init(true);

	//================
	GetClientRect(_hWnd, &_rcClient);
	//================

	wallTest = new Wall;
	assert(wallTest != NULL);
	wallTest->Init();

	//////////////
	return true;
}

void MainGame::Release()
{
	GameNode::Release();

	//================
	wallTest->Release();
	//================
}

void MainGame::Update()
{
	GameNode::Update();


	//================
	wallTest->Update();
	//================
}

void MainGame::Render(HDC hdc)
{
	HDC backDC = this->GetBackBuffer()->GetMemDC();
	PatBlt(backDC, 0, 0, WINSIZEX, WINSIZEY, WHITENESS);			// ������ HDC ���ÿ� backDC���
																	// GameNode::Render(hdc);
																	//================														
	//================
	wallTest->Render(backDC);
	//================

	this->GetBackBuffer()->Render(hdc, 0, 0);
}