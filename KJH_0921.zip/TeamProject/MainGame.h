#pragma once

#include "GameHeader.h"
#include "Wall.h"

class Wall;

class MainGame : public GameNode
{
private:
	Wall* wallTest;

	RECT _rcClient;

public:
	MainGame();
	~MainGame();

	virtual bool Init();
	virtual void Release();
	virtual void Update();
	virtual void Render(HDC hdc);
};

