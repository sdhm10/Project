#pragma once

//enum DS_STATE
//{
//	LEFT = -1,
//	NONE,
//	RIGHT,
//};


// ���� ���� ����
enum DIRECTION
{
	DIR_NONE = 0,
	DIR_LEFT,
	DIR_RIGHT,
	DIR_UP,
	DIR_DOWN,
};

// ���� ����
enum GUNYTPE
{
	GUNYTPE_NONE = 0,
	GUNYTPE_RIFLE,
	GUNYTPE_SHOTGUN,
	GUNYTPE_LASER,
	GUNYTPE_ROCKET,
};


#define PI			3.141592654f
#define PI2			PI*2

#if defined(_UNICODE)
typedef  std::wstring		tstring;  //std::basic_string<wchar>
#else	
typedef  std::string		tstring;   //std::basic_string<char>
#endif // #if defined(_UNICODE)


//Extern
extern HWND _hWnd;
extern HINSTANCE _hInst;
extern POINT _ptMouse;