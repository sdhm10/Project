#pragma once

#include "GameHeader.h"
#include "StalkerTest.h"

class MainGame : public GameNode
{
private:
	StalkerTest* stalkerTest; 

	RECT _rcClient;

public:
	MainGame();
	~MainGame();

	virtual bool Init();
	virtual void Release();
	virtual void Update();
	virtual void Render(HDC hdc);
};

