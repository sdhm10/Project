#pragma once

//enum DS_STATE
//{
//	LEFT = -1,
//	NONE,
//	RIGHT,
//};


// ���� ���� ����
enum DIRECTION
{
	DIR_NONE = 0,
	DIR_LEFT,
	DIR_RIGHT,
	DIR_UP,
	DIR_DOWN,
};

// ���� ����
enum GUNYTPE
{
	GUNYTPE_NONE = 0,
	GUNYTPE_RIFLE,
	GUNYTPE_SHOTGUN,
	GUNYTPE_BOMB,
};


// ���� Ÿ��
enum MONSTERTYPE
{
	TYPE_BOSS,
	TYPE_TURRET,
	TYPE_HOMING,
	TYPE_SHOOT,
};

// �����ΰ�
enum ISWHO
{
	WHO_PLAYER,
	WHO_ENEMY,
	WHO_WALL,
};

// ���� ����
enum STATE
{
	STATE_IDLE = 0,
	STATE_MOVE,
	STATE_ATTACK,
	STATE_BEATTACKED,
	STATE_EVADE,
	STATE_DEAD,
};

#define PI			3.141592654f
#define PI2			PI*2
#define COLOR_M		RGB(255, 0, 255)



#if defined(_UNICODE)
typedef  std::wstring		tstring;  //std::basic_string<wchar>
#else	
typedef  std::string		tstring;   //std::basic_string<char>
#endif // #if defined(_UNICODE)


//Extern
extern HWND _hWnd;
extern HINSTANCE _hInst;
extern POINT _ptMouse;