#pragma once

#include "GameHeader.h"

namespace UTIL
{
	//float getDistance(float startX, float startY, float endX, float endY)
	//{
	//	float x = endX - startX;
	//	float y = endY - startY;

	//	return sqrtf(x * x + y * y);
	//}


	float getDistance(const float startX, const float startY, const float endX, const float endY);

	float getAngle(const float x1, const float y1, const float x2, const float y2);

}