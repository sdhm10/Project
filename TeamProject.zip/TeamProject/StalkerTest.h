#pragma once

#include "GameNode.h"
#include "GameHeader.h"
#include "Bullet.h"

#define MAX_BULLET	5
#define MAX_ENEMY	4

struct Bullet2
{
	float	x, y;
	float	speed;
	float	angle;
	float	radius;
	float	gravity;
	bool	fire;
	int		boundCount;
};

struct Stalker
{
	float	x, y;
	float	angle;
	float	endx, endy;
	float	length;
	float	radius;
	float	speed;
	bool	isDead;
	RECT	rc;
};

class StalkerTest : public GameNode
{
	Stalker		Player;

	Stalker		StalkerEnemy[MAX_ENEMY];

//	Bullet2  _bullet[MAX_BULLET];
	Bullet  _bullet[MAX_BULLET];

public:
	StalkerTest();
	~StalkerTest();

	virtual bool Init();
	virtual void Release();
	virtual void Update();
	virtual void Render(HDC hdc);
/////////////////////////////

	void BulletMove();			// źȯ ���� �Լ�
	void BulletFire();			// �⺻ źȯ �߻� �Լ�		
	void ShotGunFire();			// ���� źȯ �߻� �Լ�

	void PlayerController();
	void EnemyMove(Stalker& inputStalker);
	void EnemyRender(HDC hdc, Stalker& inputStalker);
	void HitEnemy();
};

