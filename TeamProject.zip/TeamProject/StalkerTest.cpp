#include "StalkerTest.h"


StalkerTest::StalkerTest()
{
}


StalkerTest::~StalkerTest()
{
}

bool StalkerTest::Init()
{
	// Bullet Init
	for (int i = 0; i < MAX_BULLET; i++)
	{
		_bullet[i].Init();	// źȯ �ʱ�ȭ
	}

	// Player Init
	Player.angle = PI / 2.f;
	Player.x = static_cast<float>(WINSIZEX) / 2.f;
	Player.y = static_cast<float>(WINSIZEY) / 2.f;
	Player.endx = Player.x;
	Player.endy = Player.y;
	Player.length = 10.f;
	Player.radius = 50.f;
	Player.rc = RectMakeCenter(Player.x, Player.y, Player.radius, Player.radius);
	Player.speed = 4.f;
	Player.isDead = false;


	// Enemy Group Init
	for (int i = 0; i < MAX_ENEMY; i++)
	{
		StalkerEnemy[i].angle = PI / 2.f;
		StalkerEnemy[i].endx = StalkerEnemy[i].x;
		StalkerEnemy[i].endy = StalkerEnemy[i].y;
		StalkerEnemy[i].length = 10.f;
		StalkerEnemy[i].radius = 50.f;
		StalkerEnemy[i].rc = RectMakeCenter(StalkerEnemy[i].x, StalkerEnemy[i].y, StalkerEnemy[i].radius, StalkerEnemy[i].radius);
		StalkerEnemy[i].speed = 3.f;
		StalkerEnemy[i].isDead = false;
	}
	StalkerEnemy[0].x = 0.f;
	StalkerEnemy[0].y = 0.f;
	StalkerEnemy[1].x = static_cast<float>(WINSIZEX);
	StalkerEnemy[1].y = 0.f;
	StalkerEnemy[2].x = 0.f;
	StalkerEnemy[2].y = static_cast<float>(WINSIZEY);
	StalkerEnemy[3].x = static_cast<float>(WINSIZEX);
	StalkerEnemy[3].y = static_cast<float>(WINSIZEY);


	return true;
}

void StalkerTest::Release()
{

}


void StalkerTest::Update()
{
//////////
	BulletMove();			// źȯ �̵�
/////////


	// ���� ����´�.
	// �� �迭
	for (int i = 0; i < MAX_ENEMY; i++)
	{
		EnemyMove(StalkerEnemy[i]);
	}

	// źȯ�� ���� ���� ó���ϴ� �Լ�.
	HitEnemy();

	// �÷��̾�
	PlayerController();

}

void StalkerTest::Render(HDC hdc)
{
	// Bullet Render
	for (int i = 0; i < MAX_BULLET; i++)
	{
		_bullet[i].Render(hdc);
		// �׽�Ʈ��
		//TCHAR szTemp[100] = { 0, };
		//_stprintf_s(szTemp, _countof(szTemp), TEXT("�׽�Ʈ  :  %d"), _bullet[i].GetIsFire());
		//TextOut(hdc, WINSIZEX / 2 - 60, 30, szTemp, static_cast<int>(_tcslen(szTemp)));
	}

	// �÷��̾�
	EllipseMakeCenter(hdc, Player.x, Player.y, Player.radius, Player.radius);
	LineMake(hdc, Player.x, Player.y, Player.endx, Player.endy);
	
	// �� �迭
	for (int i = 0; i < MAX_ENEMY; i++)
	{
		EnemyRender(hdc, StalkerEnemy[i]);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
// źȯ �߻� �Լ�
void StalkerTest::BulletFire()
{
	for (int i = 0; i < MAX_BULLET; i++)
	{
		if (_bullet[i].GetIsFire())
			continue;
		
		_bullet[i].BulletFire(Player.endx, Player.endy, Player.angle, Player.length);

		break;
	}
}

void StalkerTest::ShotGunFire()
{
	int tempBulletNumber = 0;
	float tempAngle = PI/6.f;

	for(int j = 0 ; j < 5 ; j++)
	{
		for (int i = 0; i < MAX_BULLET; i++)
		{
			if (_bullet[i].GetIsFire())
				continue;

			_bullet[i].BulletFire(Player.endx, Player.endy, Player.angle + tempAngle, Player.length);
			tempAngle = -tempAngle;
			tempAngle /= 2;
			tempBulletNumber--;
			break;
		}
	}

}

// źȯ �̵� �Լ�
void StalkerTest::BulletMove()
{
	for (int i = 0; i < MAX_BULLET; i++)
	{
		_bullet[i].Update();
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////


// �÷��̾� ��Ʈ�ѷ� �Լ�
void StalkerTest::PlayerController()
{
	// �÷��̾�
	if (KEYMANAGER->isStayKeyDown(VK_LEFT))
	{
		Player.angle += 0.04f;
	}
	if (KEYMANAGER->isStayKeyDown(VK_RIGHT))
	{
		Player.angle -= 0.04f;
	}
	if (KEYMANAGER->isStayKeyDown(VK_UP))
	{
		Player.x += cosf(Player.angle) * Player.speed;
		Player.y += -sinf(Player.angle) * Player.speed;
	}
	if (KEYMANAGER->isStayKeyDown(VK_DOWN))
	{
		Player.x -= cosf(Player.angle) * Player.speed;
		Player.y -= -sinf(Player.angle) * Player.speed;
	}
	if (KEYMANAGER->isOnceKeyDown(VK_SPACE))
	{
		// �⺻
//		BulletFire();

		// ����
		ShotGunFire();

	}
	if (KEYMANAGER->isOnceKeyDown('Z'))
	{
		Player.speed++;
	}
	if (KEYMANAGER->isOnceKeyDown('X'))
	{
		Player.speed--;
	}

	//_skr1.x += cosf(_skr1.angle) * 1.1f;			//
	//_skr1.y += -sinf(_skr1.angle) *1.1f;			//

	Player.endx = Player.x + cosf(Player.angle) * 25.f;
	Player.endy = Player.y + (-sinf(Player.angle)) * 25.f;
	Player.rc = RectMakeCenter(Player.x, Player.y, Player.radius, Player.radius);
}

// �� �̵� �Լ�(�÷��̾�� �����Ѵ�.)
void StalkerTest::EnemyMove(Stalker& inputStalker)
{
	if (!inputStalker.isDead)
	{
		//	_skr2.angle = UTIL::getAngle(_skr2.x, _skr2.y, _skr1.x, _skr1.y);
		inputStalker.angle = UTIL::getAngle(inputStalker.x, inputStalker.y, Player.x + (cosf(Player.angle) * 1.1f), Player.y + (-sinf(Player.angle) *1.1f));
		inputStalker.x += cosf(inputStalker.angle) * inputStalker.speed;
		inputStalker.y += -sinf(inputStalker.angle) * inputStalker.speed;

		inputStalker.endx = inputStalker.x + cosf(inputStalker.angle) * 25.f;
		inputStalker.endy = inputStalker.y + (-sinf(inputStalker.angle)) * 25.f;
		inputStalker.rc = RectMakeCenter(inputStalker.x, inputStalker.y, inputStalker.radius, inputStalker.radius);
	}
}

// ���� �׸��� �Լ�
void StalkerTest::EnemyRender(HDC hdc, Stalker & inputStalker)
{
	// ��
	if (!inputStalker.isDead)
	{

		HPEN pen = CreatePen(PS_SOLID, 2, RGB(255, 0, 0));
		HPEN oldpen = (HPEN)SelectObject(hdc, pen);

		SelectObject(hdc, pen);

		//	Ellipse(hdc, _skr2.rc.left, _skr2.rc.top, _skr2.rc.right, _skr2.rc.bottom);
		EllipseMakeCenter(hdc, inputStalker.x, inputStalker.y, inputStalker.radius, inputStalker.radius);
		LineMake(hdc, inputStalker.x, inputStalker.y, inputStalker.endx, inputStalker.endy);

		SelectObject(hdc, oldpen);
		DeleteObject(pen);
	}
}

void StalkerTest::HitEnemy()
{
	// �� �迭		źȯ-�� �浹ó��
	for (int i = 0; i < MAX_ENEMY; i++)
	{
		for (int j = 0; j < MAX_BULLET; j++)
		{
			if (CollisionCircleAndCircle(_bullet[j].GetRadius(), _bullet[j].GetX(), _bullet[j].GetY(),
				StalkerEnemy[i].radius / 2, StalkerEnemy[i].x, StalkerEnemy[i].y)
				&& _bullet[j].GetIsFire()
				&& !StalkerEnemy[i].isDead)
			{
				_bullet[j].SetIsFire(false);
				StalkerEnemy[i].isDead = true;
			}

		}
	}
}