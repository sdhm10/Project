#include "GameHeader.h"
#include "Player.h"
#include "Animation.h"


Player::Player()
{
	// �÷��̾� �̹���
	playerImage = new Image;
	playerImage = IMAGEMANAGER->AddFrameImage(TEXT("Player"), TEXT("Image/Player.bmp"), 480, 360, 12, 6, true, RGB(0, 255, 0));

	// �� �̹���
	gunImage = new Image;
	gunImage->Init(TEXT("Image/Gun.bmp"), 280, 320, 4, 4, true, RGB(0, 255, 0));
}


Player::~Player()
{
	SAFE_DELETE(playerAni);
	SAFE_DELETE(playerImage);
	SAFE_DELETE(gunImage);
}



bool Player::Init()
{
	dirState	= DIR_RIGHT;
	playerState = STATE_IDLE;
	posX		= WINSIZEX / 2;
	posY		= WINSIZEY / 2;
	handX		= posX;
	handY		= posY;
	PlayerR		= 20;
	angle		= 0.f;
	isAlive		= true;
	speed		= 5.f;
	gunType		= GUNYTPE_RIFLE;
	
	isPlayer	= true;
	playerRc	= RectMakeCenter(posX, posY, PlayerR*2, PlayerR*2);

	// �÷��̾� �ִϸ��̼�
	playerAni = new Animation;
	playerAni->Init(playerImage);
	playerAni->setFPS(1);
	return true;


}

void Player::Release()
{
}

// Bullets& bullets �� �߰� 
void Player::Update(Bullets& bullets)
{
	PlayerController(bullets);
	FrameMove();

	if (!playerAni->isPlay())		// �����κ� fasle�� �Ǿ������ÿ�
	{
		playerAni->start();
		playerState = STATE_IDLE;
	}

	playerAni->frameUpdate(TIMEMANAGER->getElapsedTime() * 6);
}

void Player::Render(HDC hdc)
{

	// ��
	gunImage->FrameRender(hdc, handX - 35, handY - 40, gunImage->GetFrameX(), gunImage->GetFrameY());
	//LineMake(hdc, _Player.posX, _Player.posY, _Player.handX, _Player.handY);
	//EllipseMakeCenter(hdc, _Player.handX, _Player.handY, 10, 10);

	// �÷��̾�
	Rectangle(hdc, playerRc.left, playerRc.top, playerRc.right, playerRc.bottom);	// �����
	playerImage->AniRender(hdc, posX - 20, posY - 30, playerAni);
	//EllipseMakeCenter(hdc, posX, posY, PlayerR*2, PlayerR * 2);
}

void Player::PlayerController(Bullets& bullets)
{

	if (KEYMANAGER->isStayKeyDown(VK_LEFT))
	{
		if(playerState != STATE_EVADE)
		playerState = STATE_MOVE;

		dirState = DIR_LEFT;
		angle = PI;
		posX -= speed;
	}
	else if (KEYMANAGER->isStayKeyDown(VK_RIGHT))
	{
		if (playerState != STATE_EVADE)
		playerState = STATE_MOVE;

		dirState = DIR_RIGHT;
		angle = 0;
		posX += speed;
	}
	else if (KEYMANAGER->isStayKeyDown(VK_UP))
	{
		if (playerState != STATE_EVADE)
		playerState = STATE_MOVE;

		dirState = DIR_UP;
		angle = PI / 2;
		posY -= speed;
	}
	else if (KEYMANAGER->isStayKeyDown(VK_DOWN))
	{
		if (playerState != STATE_EVADE)
		playerState = STATE_MOVE;

		dirState = DIR_DOWN;
		angle = PI + (PI / 2);
		posY += speed;
	}
	else
	{
		if(playerState !=STATE_EVADE)
		playerState = STATE_IDLE;		// ���ڸ��� �������� IDLE���·� ��ȯ
	}
	

	if (KEYMANAGER->isOnceKeyDown('A'))
	{
		playerState = STATE_ATTACK;
		PlayerAttack(bullets);
	}
	if (KEYMANAGER->isOnceKeyDown('S'))
	{
		playerState = STATE_EVADE;
	}

	if (KEYMANAGER->isOnceKeyDown('1'))
	{
		gunType = GUNYTPE::GUNYTPE_RIFLE;
		gunImage->SetFrameY(0);
	}
	else if (KEYMANAGER->isOnceKeyDown('2'))
	{
		gunType = GUNYTPE::GUNYTPE_SHOTGUN;
		gunImage->SetFrameY(1);
	}
	else if (KEYMANAGER->isOnceKeyDown('3'))
	{
		gunType = GUNYTPE::GUNYTPE_BOMB;
		gunImage->SetFrameY(3);
	}

	playerRc = RectMakeCenter(posX, posY, PlayerR * 2, PlayerR * 2);
	handX = posX + cosf(angle) * 20;
	handY = posY + (- sinf(angle)) * 20;
}


bool Player::PlayerAttack(Bullets& bullets)
{
	if(gunType == GUNYTPE::GUNYTPE_RIFLE)
		bullets.BulletFire(handX, handY, angle, 30.f, isPlayer, GUNYTPE::GUNYTPE_RIFLE);
	else if (gunType == GUNYTPE::GUNYTPE_SHOTGUN)
		bullets.ShotGunFire(handX, handY, angle, 30.f, isPlayer, GUNYTPE::GUNYTPE_SHOTGUN);
	else if (gunType == GUNYTPE::GUNYTPE_BOMB)
		bullets.BombFire(handX, handY, angle, 30.f, isPlayer, GUNYTPE::GUNYTPE_BOMB);

	return true;
}

void Player::PlayerBeAttacked()
{
	if(playerState != STATE_BEATTACKED && playerState != STATE_EVADE)	// + CollisionCircleAndCircle(�Ѿ�,�÷��̾� �Ǵ� ��,�÷��̾�) <-- �̺κ��� PlayerMove�� ����Ͽ� �������� �Ѿ�´�.

	playerState = STATE_BEATTACKED;
	for (int i = 0; i < 5; i++)		// ü�°��� �κ�
	{
		if (hp[i + 1] == NULL)
		{
			hp[i] = 0;

			if (hp[0] == 0)
			{
				playerState = STATE_DEAD;
				isAlive = false;
			}

			break;
		}
		

	}
}

void Player::FrameMove()
{
	if (playerState == STATE_MOVE)
	{
		switch (dirState)		// ������ ���·� 4����ó��
		{
		case DIR_LEFT :
			gunImage->SetFrameX(1);
			playerAni->setPlayFrame(24, 29, false, true);
			break;
		case DIR_RIGHT:
			gunImage->SetFrameX(0);
			playerAni->setPlayFrame(36, 41, false, true);
			break;
		case DIR_UP:
			gunImage->SetFrameX(3);
			playerAni->setPlayFrame(60, 65, false, true);
			break;
		case DIR_DOWN:
			gunImage->SetFrameX(2);
			playerAni->setPlayFrame(48, 53, false, true);
			break;
		default:
			break;
		}
	}
	
	if (playerState == STATE_IDLE)
	{
		switch (dirState)
		{
		case DIR_LEFT:
			playerAni->setPlayFrame(0, 5, false, true);
			break;
		case DIR_RIGHT:
			playerAni->setPlayFrame(0, 5, false, true);
			break;
		case DIR_DOWN:
			playerAni->setPlayFrame(0, 5, false, true);
			break;
		case DIR_UP:
			playerAni->setPlayFrame(12,17, false, true);
			break;
		default:
			break;
		}
	}

	if (playerState == STATE_EVADE)		// �������� �Ϻ� �����Ǵ� ����������
	{
		switch (dirState)
		{
		case DIR_LEFT:
			gunImage->SetFrameX(1);
			playerAni->setPlayFrame(30, 35, false, false);
			break;
		case DIR_RIGHT:
			gunImage->SetFrameX(0);
			playerAni->setPlayFrame(42, 47, false, false);
			break;
		case DIR_UP:
			gunImage->SetFrameX(3);
			playerAni->setPlayFrame(66, 71, false, false);
			break;
		case DIR_DOWN:
			gunImage->SetFrameX(2);
			playerAni->setPlayFrame(54, 59, false, false);
			break;
		default:
			break;
		}
	}

	if (playerState == STATE_DEAD)
	{
		playerAni->setPlayFrame(18, 23, false, false);
	}

}

// �÷��̾� źȯ �ǰݽ� �̺�Ʈ �߻� �Լ�
bool Player::HitEvent(Bullets& bullets)
{
	// źȯ�� ���� ��ü�� x, y, ������/2, PC/NPC����, ���翩��
	// �Ű������� �Է��Ѵ�.
	if (bullets.HitCollision(posX, posY, PlayerR / 2, isPlayer, isAlive)
		&& isAlive
		&& isPlayer)
	{
		// ���⿡ �̺�Ʈ�� �ǰ� �̺�Ʈ�� �߻��Ѵ�.
		// Player.isAlive = false;
		// PlayerBeAttacked();

		return true;
	}
	
	return false;
}


// UI ü��, ���õ� ��

// ������Ʈ : Wall.Door.HealthPoint

// �� : ����,��������,������,������

// �÷��̾� : ��Ʈ�̺�Ʈ, ȸ�ǽ� �̵��Ÿ�

// ���� : ����(������), HP ui�� 

// �Ϲ��� : 3��� ���


//