#pragma once
#include "GameNode.h"
#define		MAX_MONSTER 31

struct Monster
{
	Image*		image;
	Animation*  ani;
	RECT		follow;		// �߰�

	float		angle;		// ����
	int			Len;		// ũ��
	int			posX;		// ����
	int			posY;		
	int			hp;			// ü��
	int			speed;		// �ӵ�
	bool		isAlive;	// ����üũ

	MONSTERTYPE type;
	ISWHO		who;		// �����ΰ�
	STATE		state;		// ����
	DIRECTION	monDir;		// ����
};
class Enemy	: public GameNode
{
private:
	Image* MonsterImageType[4];
	Monster	_Monster[MAX_MONSTER];

public:
	Enemy();
	~Enemy();

	virtual bool Init();
	virtual void Release();
	virtual void Update();
	virtual void Render(HDC hdc);

	void HomingTarget();

};

