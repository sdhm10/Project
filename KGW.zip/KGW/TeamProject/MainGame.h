#pragma once

#include "GameHeader.h"
#include "StalkerTest.h"
#include "Player.h"
#include "Enemy.h"

class MainGame : public GameNode
{
private:
	StalkerTest* stalkerTest; 

	Player _player;
	Enemy _enemy;

	RECT _rcClient;

public:
	MainGame();
	~MainGame();

	virtual bool Init();
	virtual void Release();
	virtual void Update();
	virtual void Render(HDC hdc);
};

