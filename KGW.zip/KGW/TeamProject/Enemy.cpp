#include "GameHeader.h"
#include "Enemy.h"
#include "Animation.h"
#include "Player.h"


Enemy::Enemy()
{
}


Enemy::~Enemy()
{
}

bool Enemy::Init()
{
	// �̹��� ã�ƿ���
	IMAGEMANAGER->AddFrameImage(TEXT("Boss"), TEXT("IMAGE/Boss.bmp"), 200, 210, 4, 3, true, RGB(0, 255, 0));
	IMAGEMANAGER->AddFrameImage(TEXT("Homing"), TEXT("Image/Homing.bmp"), 200, 160, 5, 2, true, RGB(0, 255, 0));
	IMAGEMANAGER->AddFrameImage(TEXT("Shooting"), TEXT("Image/Shooting.bmp"), 200, 193, 4, 4, true, RGB(0, 255, 0));
	IMAGEMANAGER->AddFrameImage(TEXT("Turret"), TEXT("Image/Turret.bmp"), 192, 64, 6, 1, true, RGB(0, 255, 0));
	
	for (int i = 0; i < MAX_MONSTER; i++)
	{
		// ���� �κ�

		_Monster[i].angle	  = PI + (PI / 2);
		_Monster[i].posX	  = (i % 10) * 100;			// �ӽ�
		_Monster[i].posY	  = 0;						//
		_Monster[i].hp		  = 3;
		_Monster[i].isAlive	  = true;
		_Monster[i].speed	  = 5;
		_Monster[i].state     = STATE_IDLE;
		_Monster[i].monDir    = DIR_DOWN;
		_Monster[i].who		  = WHO_ENEMY;
		_Monster[i].ani		  = new Animation;

		if (i < 10)		// ����
		{
			_Monster[i].type = TYPE_HOMING;
			_Monster[i].image = IMAGEMANAGER->FindImage(TEXT("Homing"));
		}
		else if (i >= 10 && i < 20)	 // źȯ�߻�
		{
			_Monster[i].type = TYPE_SHOOT;
			_Monster[i].image = IMAGEMANAGER->FindImage(TEXT("Shooting"));
		}
		else if (i >= 20 && i < 30)	 // �ͷ���
		{
			_Monster[i].type = TYPE_TURRET;
			_Monster[i].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
		}
		if (i == 30) // ����
		{
			_Monster[i].type  = TYPE_BOSS;
			_Monster[i].hp	  = 50;
			_Monster[i].speed = 3;
			_Monster[i].image = IMAGEMANAGER->FindImage(TEXT("Boss"));
		}
		_Monster[i].ani->Init(_Monster[i].image);
		_Monster[i].ani->setFPS(1);
	}

	return true;
}

void Enemy::Release()
{
	for (int i = 0; i < MAX_MONSTER; i++)
	{
		SAFE_DELETE(_Monster[i].ani);
	}
	IMAGEMANAGER->DeleteImage("Boss");
	IMAGEMANAGER->DeleteImage("Turret");
	IMAGEMANAGER->DeleteImage("Shooting");
	IMAGEMANAGER->DeleteImage("Homing");
}

void Enemy::Update()
{
	for (int i = 0; i < MAX_MONSTER - 1; i++)	// �νĹ���
	{
		_Monster[i].follow = RectMakeCenter(_Monster[i].posX, _Monster[i].posY, 300, 300);
	}
}

void Enemy::Render(HDC hdc)
{
	for (int i = 0; i < MAX_MONSTER - 1; i++)
	{
	//	Rectangle(hdc, _Monster[i].follow.left, _Monster[i].follow.top, _Monster[i].follow.right, _Monster[i].follow.bottom);
		_Monster[i].image->AniRender(hdc, _Monster[i].posX, _Monster[i].posY, _Monster[i].ani);
	}
}

void Enemy::HomingTarget()
{

}


