#include "GameHeader.h"
#include "Player.h"
#include "Animation.h"


Player::Player()
{
}


Player::~Player()
{
}



bool Player::Init()
{
	_Player.dirState	= DIR_RIGHT;
	_Player.playerState = STATE_IDLE;
	_Player.posX		= WINSIZEX / 2;
	_Player.posY		= WINSIZEY / 2;
	_Player.handX		= _Player.posX;
	_Player.handY		= _Player.posY;
	_Player.PlayerR		= 20;
	_Player.angle		= 0;
	_Player.isAlive		= true;
	_Player.speed		= 5;
	_Player.gunType		= GUNYTPE_RIFLE;
	_Player.who			= WHO_PLAYER;
	
	// �÷��̾� �̹���
	_Player.playerImage = IMAGEMANAGER->AddFrameImage(TEXT("Player"), TEXT("Image/Player.bmp"), 480, 360, 12, 6, true, RGB(0, 255, 0));
	// �� �̹���
	_Player.gunImage= new Image;
	_Player.gunImage->Init(TEXT("Image/Gun.bmp"), 280, 320, 4, 4, true, RGB(0, 255, 0));

	// �÷��̾� �ִϸ��̼�
	_Player.playerAni = new Animation;
	_Player.playerAni->Init(_Player.playerImage);
	_Player.playerAni->setFPS(1);
	return true;


}

void Player::Release()
{
	IMAGEMANAGER->DeleteImage(TEXT("Player"));
	SAFE_DELETE(_Player.playerAni);
}

void Player::Update()
{
	PlayerMove();
	FrameMove();
	SelectGunType();

	if (!_Player.playerAni->isPlay())		// �����κ� fasle�� �Ǿ������ÿ�
	{
		_Player.playerAni->start();
		_Player.playerState = STATE_IDLE;
	}

	_Player.playerAni->frameUpdate(TIMEMANAGER->getElapsedTime() * 6);
}

void Player::Render(HDC hdc)
{
	// ��
	_Player.gunImage->FrameRender(hdc, _Player.handX - 35, _Player.handY - 40, _Player.gunImage->GetFrameX(), _Player.gunImage->GetFrameY());
	//LineMake(hdc, _Player.posX, _Player.posY, _Player.handX, _Player.handY);
	//EllipseMakeCenter(hdc, _Player.handX, _Player.handY, 10, 10);

	// �÷��̾�
	_Player.playerImage->AniRender(hdc, _Player.posX - 20, _Player.posY - 30, _Player.playerAni);
	//EllipseMakeCenter(hdc, _Player.posX, _Player.posY, _Player.PlayerR, _Player.PlayerR * 2);
}

void Player::PlayerMove()
{

	if (KEYMANAGER->isStayKeyDown(VK_LEFT))
	{
		if(_Player.playerState != STATE_EVADE)
		_Player.playerState = STATE_MOVE;

		_Player.dirState = DIR_LEFT;
		_Player.angle = PI;
		_Player.posX -= _Player.speed;
	}
	else if (KEYMANAGER->isStayKeyDown(VK_RIGHT))
	{
		if (_Player.playerState != STATE_EVADE)
		_Player.playerState = STATE_MOVE;

		_Player.dirState = DIR_RIGHT;
		_Player.angle = 0;
		_Player.posX += _Player.speed;
	}
	else if (KEYMANAGER->isStayKeyDown(VK_UP))
	{
		if (_Player.playerState != STATE_EVADE)
		_Player.playerState = STATE_MOVE;

		_Player.dirState = DIR_UP;
		_Player.angle = PI / 2;
		_Player.posY -= _Player.speed;
	}
	else if (KEYMANAGER->isStayKeyDown(VK_DOWN))
	{
		if (_Player.playerState != STATE_EVADE)
		_Player.playerState = STATE_MOVE;

		_Player.dirState = DIR_DOWN;
		_Player.angle = PI + (PI / 2);
		_Player.posY += _Player.speed;
	}
	else
	{
		if(_Player.playerState !=STATE_EVADE)
		_Player.playerState = STATE_IDLE;		// ���ڸ��� �������� IDLE���·� ��ȯ
	}
	
	if (KEYMANAGER->isOnceKeyDown('A'))
	{
		_Player.playerState = STATE_ATTACK;
		PlayerAttack();
	}
	if (KEYMANAGER->isOnceKeyDown('S'))
	{
		_Player.playerState = STATE_EVADE;
	}



	_Player.handX = _Player.posX + cosf(_Player.angle) * 20;
	_Player.handY = _Player.posY + (- sinf(_Player.angle)) * 20;
}

void Player::SelectGunType()
{
	if (KEYMANAGER->isOnceKeyDown('1'))
	{
		_Player.gunType = GUNYTPE_RIFLE;
		_Player.gunImage->SetFrameY(0);
	}
	else if (KEYMANAGER->isOnceKeyDown('2'))
	{
		_Player.gunType = GUNYTPE_SHOTGUN;
		_Player.gunImage->SetFrameY(1);
	}
	else if (KEYMANAGER->isOnceKeyDown('3'))
	{
		_Player.gunType = GUNYTPE_LASER;
		_Player.gunImage->SetFrameY(3);
	}
	else if (KEYMANAGER->isOnceKeyDown('4'))
	{
		_Player.gunType = GUNYTPE_ROCKET;
		_Player.gunImage->SetFrameY(2);
	}
}

void Player::PlayerAttack()
{
	// �Ѿ� �߰�
}

void Player::PlayerBeAttacked()
{
	if(_Player.playerState != STATE_BEATTACKED && _Player.playerState != STATE_EVADE)	// + CollisionCircleAndCircle(�Ѿ�,�÷��̾� �Ǵ� ��,�÷��̾�) <-- �̺κ��� PlayerMove�� ����Ͽ� �������� �Ѿ�´�.

	_Player.playerState = STATE_BEATTACKED;
	for (int i = 0; i < 5; i++)		// ü�°��� �κ�
	{
		if (_Player.hp[i + 1] == NULL)
		{
			_Player.hp[i] = 0;

			if (_Player.hp[0] == 0)
			{
				_Player.playerState = STATE_DEAD;
				_Player.isAlive = false;
			}

			break;
		}
		

	}
}

void Player::FrameMove()
{
	if (_Player.playerState == STATE_MOVE)
	{
		switch (_Player.dirState)		// ������ ���·� 4����ó��
		{
		case DIR_LEFT :
			_Player.gunImage->SetFrameX(1);
			_Player.playerAni->setPlayFrame(24, 29, false, true);
			break;
		case DIR_RIGHT:
			_Player.gunImage->SetFrameX(0);
			_Player.playerAni->setPlayFrame(36, 41, false, true);
			break;
		case DIR_UP:
			_Player.gunImage->SetFrameX(3);
			_Player.playerAni->setPlayFrame(60, 65, false, true);
			break;
		case DIR_DOWN:
			_Player.gunImage->SetFrameX(2);
			_Player.playerAni->setPlayFrame(48, 53, false, true);
			break;
		default:
			break;
		}
	}
	
	if (_Player.playerState == STATE_IDLE)
	{
		switch (_Player.dirState)
		{
		case DIR_LEFT:
			_Player.playerAni->setPlayFrame(0, 5, false, true);
			break;
		case DIR_RIGHT:
			_Player.playerAni->setPlayFrame(0, 5, false, true);
			break;
		case DIR_DOWN:
			_Player.playerAni->setPlayFrame(0, 5, false, true);
			break;
		case DIR_UP:
			_Player.playerAni->setPlayFrame(12,17, false, true);
			break;
		default:
			break;
		}
	}

	if (_Player.playerState == STATE_EVADE)		// �������� �Ϻ� �����Ǵ� ����������
	{
		switch (_Player.dirState)
		{
		case DIR_LEFT:
			_Player.gunImage->SetFrameX(1);
			_Player.playerAni->setPlayFrame(30, 35, false, false);
			break;
		case DIR_RIGHT:
			_Player.gunImage->SetFrameX(0);
			_Player.playerAni->setPlayFrame(42, 47, false, false);
			break;
		case DIR_UP:
			_Player.gunImage->SetFrameX(3);
			_Player.playerAni->setPlayFrame(66, 71, false, false);
			break;
		case DIR_DOWN:
			_Player.gunImage->SetFrameX(2);
			_Player.playerAni->setPlayFrame(54, 59, false, false);
			break;
		default:
			break;
		}
	}

	if (_Player.playerState == STATE_DEAD)
	{
		_Player.playerAni->setPlayFrame(18, 23, false, false);
	}

}


// ���� �����Ӱ��úκ� �Ϸ�

// �÷��̾� SetFrameY�κ� �Ϸ�
// �ִϸ��̼� ��� SetFrameX�κ� ä��������ɵ�

// ���ݴ������� (if��������Ͽ� �Ѿ� Ȥ�� ���� �ε����ÿ�)
// �����Ӻκ� (���� �̱���) �Ϸ� �ڿ� 
// �ٽ� ���ݹ����� �ִ°����� (state�� beattacked�� �ƴҽÿ� beattacked�Լ��� ���)
// ���� ������ state�� beattacked, gettickcount����ϰų� �ؼ� �÷��̾ �ٽ� idle���·� �ٲٴ��� �ϸ� �ɵ�
