#pragma once

//CollisionFunction.h

// �簢�� �浹
bool CollisionRectAndRect(const RECT& r1, const RECT& r2);


// �� �浹
bool CollisionCircleAndCircle(const float r1, const float x1,
	const float y1, const float r2, const float x2, const float y2);

