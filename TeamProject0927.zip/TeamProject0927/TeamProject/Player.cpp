#include "GameHeader.h"
#include "Player.h"
#include "Animation.h"


Player::Player()
{
}


Player::~Player()
{
	SAFE_DELETE(playerAni);
	SAFE_DELETE(gunImage);
	for (int i = 0; i < 5; i++)
		SAFE_DELETE(hpImage[i]);
	SAFE_DELETE(playerImage);
}



bool Player::Init()
{
	playerImage = new Image;
	playerImage = IMAGEMANAGER->AddFrameImage(TEXT("Player"), TEXT("Image/Player.bmp"), 480, 360, 12, 6, true, RGB(0, 255, 0));

	gunImage = new Image;
	gunImage->Init(TEXT("Image/Gun.bmp"), 280, 320, 4, 4, true, RGB(0, 255, 0));

	IMAGEMANAGER->AddFrameImage(TEXT("GUNUI"), TEXT("Image/GUNUI.bmp"), 120, 80, 3, 2, true, RGB(0, 255, 0));

	GunTypeUI[0].GunUI = IMAGEMANAGER->FindImage(TEXT("GUNUI"));
	GunTypeUI[0].isSelect = true;
	GunTypeUI[0].GunUI->SetFrameX(0);

	GunTypeUI[1].GunUI = IMAGEMANAGER->FindImage(TEXT("GUNUI"));
	GunTypeUI[1].isSelect = false;
	GunTypeUI[1].GunUI->SetFrameX(1);

	GunTypeUI[2].GunUI = IMAGEMANAGER->FindImage(TEXT("GUNUI"));
	GunTypeUI[2].isSelect = false;
	GunTypeUI[2].GunUI->SetFrameX(2);

	for (int i = 0; i < 5; i++)
	{
		hpImage[i] = new Image;
		hpImage[i]->Init(TEXT("Image/HPobj.bmp"), 60, 30, 2, 1, true, RGB(0, 255, 0));
		hpImage[i]->SetFrameX(0);
	}

	SGReloadTime = 0;
	RKReloadTime = 0;

	CameraPos.x = posX;
	CameraPos.y = posY;


	dirState	= DIR_RIGHT;
	playerState = STATE_IDLE;
	posX		= WINSIZEX / 2;
	posY		= WINSIZEY / 2;
	CameraPos.x		= posX;
	CameraPos.y		= posY;
	handX		= posX;
	handY		= posY;
	PlayerR		= 20;
	angle		= 0.f;
	isAlive		= true;
	speed		= 5.f;
	gunType		= GUNYTPE_RIFLE;
	hp			= 5;

	isPlayer	= true;
	playerRc = RectMakeCenter(posX, posY, PlayerR * 2, PlayerR * 2);

	playerAni = new Animation;
	playerAni->Init(playerImage);
	playerAni->setFPS(1);

	return true;
}

void Player::Release()
{

}

void Player::Update(Bullets& bullets)
{
	SGReloadTime++;
	RKReloadTime++;

	if (isAlive)
		PlayerController(bullets);

	FrameMove();

	if(DeadCheck())
		playerAni->setPlayFrame(18, 23, false, false);


	if (!playerAni->isPlay())
	{
		if (isAlive)
		{
			playerAni->start();
			playerState = STATE_IDLE;
		}
	}

	playerAni->frameUpdate(TIMEMANAGER->getElapsedTime() * 6);
}

void Player::Render(HDC hdc)
{

	gunImage->FrameRender(hdc, handX - 35 - CAMERA->getPosition()->x, handY - 40 - CAMERA->getPosition()->y, gunImage->GetFrameX(), gunImage->GetFrameY());
	playerImage->AniRender(hdc, posX - 20 - CAMERA->getPosition()->x, posY - 30 - CAMERA->getPosition()->y, playerAni);

	for (int i = 0; i < 5; i++)
	{
		if (hp <= i)
			hpImage[i]->FrameRender(hdc, i * 30, 20, 1, 0);
		else
			hpImage[i]->FrameRender(hdc, i * 30, 20, 0, 0);
	}

	for (int i = 0; i < 3; i++)
	{
		if (GunTypeUI[i].isSelect)
			GunTypeUI[i].GunUI->FrameRender(hdc, 200 + (i * 40), 10, i, 0);
		else
			GunTypeUI[i].GunUI->FrameRender(hdc, 200 + (i * 40), 10, i, 1);
	}
}

void Player::PlayerController(Bullets& bullets)
{

	if (KEYMANAGER->isStayKeyDown(VK_LEFT))
	{
		if(playerState != STATE_EVADE)
		playerState = STATE_MOVE;

		dirState = DIR_LEFT;
		angle = PI;
		posX -= speed;
	}
	else if (KEYMANAGER->isStayKeyDown(VK_RIGHT))
	{
		if (playerState != STATE_EVADE)
		playerState = STATE_MOVE;

		dirState = DIR_RIGHT;
		angle = 0;
		posX += speed;
	}
	else if (KEYMANAGER->isStayKeyDown(VK_UP))
	{
		if (playerState != STATE_EVADE)
		playerState = STATE_MOVE;

		dirState = DIR_UP;
		angle = PI / 2;
		posY -= speed;
	}
	else if (KEYMANAGER->isStayKeyDown(VK_DOWN))
	{
		if (playerState != STATE_EVADE)
		playerState = STATE_MOVE;

		dirState = DIR_DOWN;
		angle = PI + (PI / 2);
		posY += speed;
	}
	else
	{
		if(playerState !=STATE_EVADE && playerState !=STATE_DEAD)
		playerState = STATE_IDLE;
	}
	

	if (KEYMANAGER->isOnceKeyDown('A'))
	{
		playerState = STATE_ATTACK;
		PlayerAttack(bullets);
	}
	if (KEYMANAGER->isOnceKeyDown('S'))
	{
		playerState = STATE_EVADE;
	}

	if (KEYMANAGER->isOnceKeyDown('1'))
	{
		gunType = GUNYTPE::GUNYTPE_RIFLE;
		gunImage->SetFrameY(0);
		GunTypeUI[0].isSelect = true;
		GunTypeUI[1].isSelect = false;
		GunTypeUI[2].isSelect = false;
	}
	else if (KEYMANAGER->isOnceKeyDown('2'))
	{
		gunType = GUNYTPE::GUNYTPE_SHOTGUN;
		gunImage->SetFrameY(1);
		GunTypeUI[0].isSelect = false;
		GunTypeUI[1].isSelect = true;
		GunTypeUI[2].isSelect = false;
	}
	else if (KEYMANAGER->isOnceKeyDown('3'))
	{
		gunType = GUNYTPE::GUNYTPE_BOMB;
		gunImage->SetFrameY(3);
		GunTypeUI[0].isSelect = false;
		GunTypeUI[1].isSelect = false;
		GunTypeUI[2].isSelect = true;
	}

	playerRc = RectMakeCenter(posX, posY, PlayerR * 2, PlayerR * 2);
	handX = posX + cosf(angle) * 20;
	handY = posY + (- sinf(angle)) * 20;
	CameraPos.x = posX;
	CameraPos.y = posY;
}


bool Player::PlayerAttack(Bullets& bullets)
{
	switch (gunType)
	{
	case GUNYTPE_RIFLE:
		bullets.BulletFire(handX, handY, angle, 30.f, isPlayer, GUNYTPE::GUNYTPE_RIFLE);
		break;
	case GUNYTPE_SHOTGUN:
		if (SGReloadTime >= SHOTGUNRELOAD)
		{
			SGReloadTime = 0;
			bullets.ShotGunFire(handX, handY, angle, 30.f, isPlayer, GUNYTPE::GUNYTPE_SHOTGUN);
		}
		break;
	case GUNYTPE_BOMB:
		if (RKReloadTime >= ROCKETRELOAD)
		{
			RKReloadTime = 0;
			bullets.BombFire(handX, handY, angle, 30.f, isPlayer, GUNYTPE::GUNYTPE_BOMB);
		}
		break;
	default:
		break;
	}

	return true;
}


void Player::FrameMove()
{
	if (playerState == STATE_MOVE)
	{
		switch (dirState)
		{
		case DIR_LEFT :
			gunImage->SetFrameX(1);
			playerAni->setPlayFrame(24, 29, false, true);
			break;
		case DIR_RIGHT:
			gunImage->SetFrameX(0);
			playerAni->setPlayFrame(36, 41, false, true);
			break;
		case DIR_UP:
			gunImage->SetFrameX(3);
			playerAni->setPlayFrame(60, 65, false, true);
			break;
		case DIR_DOWN:
			gunImage->SetFrameX(2);
			playerAni->setPlayFrame(48, 53, false, true);
			break;
		default:
			break;
		}
	}
	
	if (playerState == STATE_IDLE)
	{
		switch (dirState)
		{
		case DIR_LEFT:
			playerAni->setPlayFrame(0, 5, false, true);
			break;
		case DIR_RIGHT:
			playerAni->setPlayFrame(0, 5, false, true);
			break;
		case DIR_DOWN:
			playerAni->setPlayFrame(0, 5, false, true);
			break;
		case DIR_UP:
			playerAni->setPlayFrame(12,17, false, true);
			break;
		default:
			break;
		}
	}

	if (playerState == STATE_EVADE)
	{
		switch (dirState)
		{
		case DIR_LEFT:
			gunImage->SetFrameX(1);
			playerAni->setPlayFrame(30, 35, false, false);
			break;
		case DIR_RIGHT:
			gunImage->SetFrameX(0);
			playerAni->setPlayFrame(42, 47, false, false);
			break;
		case DIR_UP:
			gunImage->SetFrameX(3);
			playerAni->setPlayFrame(66, 71, false, false);
			break;
		case DIR_DOWN:
			gunImage->SetFrameX(2);
			playerAni->setPlayFrame(54, 59, false, false);
			break;
		default:
			break;
		}
	}

	if (playerState == STATE_DEAD)
	{
		playerAni->setPlayFrame(18, 23, false, false);
	}

}

bool Player::HitEvent(Bullets& bullets)
{
	if (playerState == STATE_EVADE)	
		return false;

	if (bullets.HitCollision(posX, posY, PlayerR /2 , isPlayer, isAlive)
		&& isAlive
		&& isPlayer
		)
	{
		hp--;
		return true;
	}
	
	return false;
}

bool Player::DeadCheck()
{
	if (hp <= 0)
	{
		playerState == STATE_DEAD;
		isAlive = false;

		return true;
	}

	return false;
}