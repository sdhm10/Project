#include "GameObject.h"

bool GameObject::Init_Room2()
{
	// 2�� �� ���� �� ��
	obj[8].OBJ_TYPE = OBJ_WALL;
	obj[8].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[8].x = WINSIZEX;
	obj[8].y = 0.f;
	obj[8].width = WALL_SIZE;
	obj[8].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[8].isAlive = true;
	obj[8].isWall = true;
	obj[8].isItem = false;
	obj[8].rcObject = RectMake(obj[8].x, obj[8].y, obj[8].width, obj[8].height);

	// 2�� �� ���� �Ʒ� ��
	obj[9].OBJ_TYPE = OBJ_WALL;
	obj[9].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[9].x = WINSIZEX;
	obj[9].y = WINSIZEY / 2 + WALL_SIZE / 2;
	obj[9].width = WALL_SIZE;
	obj[9].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[9].isAlive = true;
	obj[9].isWall = true;
	obj[9].isItem = false;
	obj[9].rcObject = RectMake(obj[9].x, obj[9].y, obj[9].width, obj[9].height);

	// 2�� �� ���� ��
	obj[10].OBJ_TYPE = OBJ_DOOR;
	obj[10].image = IMAGEMANAGER->FindImage(TEXT("Door"));
	obj[10].x = WINSIZEX;
	obj[10].y = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[10].width = WALL_SIZE;
	obj[10].height = WALL_SIZE;
	obj[10].isAlive = false;
	obj[10].isWall = true;
	obj[10].isItem = false;
	obj[10].rcObject = RectMake(obj[10].x, obj[10].y, obj[10].width, obj[10].height);

	// 2�� �� ���� ��
	obj[11].OBJ_TYPE = OBJ_WALL;
	obj[11].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[11].x = WINSIZEX;
	obj[11].y = 0.f;
	obj[11].width = WINSIZEX;
	obj[11].height = WALL_SIZE;
	obj[11].isAlive = true;
	obj[11].isWall = true;
	obj[11].isItem = false;
	obj[11].rcObject = RectMake(obj[11].x, obj[11].y, obj[11].width, obj[11].height);

	// 2�� �� �Ʒ� ���� ��
	obj[12].OBJ_TYPE = OBJ_WALL;
	obj[12].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[12].x = WINSIZEX;
	obj[12].y = WINSIZEY - WALL_SIZE;
	obj[12].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[12].height = WALL_SIZE;
	obj[12].isAlive = true;
	obj[12].isWall = true;
	obj[12].isItem = false;
	obj[12].rcObject = RectMake(obj[12].x, obj[12].y, obj[12].width, obj[12].height);

	// 2�� �� �Ʒ� ������ ��
	obj[13].OBJ_TYPE = OBJ_WALL;
	obj[13].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[13].x = WINSIZEX + (WINSIZEX / 2 + WALL_SIZE / 2);
	obj[13].y = WINSIZEY - WALL_SIZE;
	obj[13].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[13].height = WALL_SIZE;
	obj[13].isAlive = true;
	obj[13].isWall = true;
	obj[13].isItem = false;
	obj[13].rcObject = RectMake(obj[13].x, obj[13].y, obj[13].width, obj[13].height);

	// 2�� �� �Ʒ� ��
	obj[14].OBJ_TYPE = OBJ_DOOR;
	obj[14].image = IMAGEMANAGER->FindImage(TEXT("Door"));
	obj[14].x = WINSIZEX + (WINSIZEX / 2 - WALL_SIZE / 2);
	obj[14].y = WINSIZEY - WALL_SIZE;
	obj[14].width = WALL_SIZE;
	obj[14].height = WALL_SIZE;
	obj[14].isAlive = true;
	obj[14].isWall = true;
	obj[14].isItem = false;
	obj[14].rcObject = RectMake(obj[14].x, obj[14].y, obj[14].width, obj[14].height);

	// 2�� �� ������ ��
	obj[15].OBJ_TYPE = OBJ_WALL;
	obj[15].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[15].x = WINSIZEX * 2 - WALL_SIZE;
	obj[15].y = 0.f;
	obj[15].width = WALL_SIZE;
	obj[15].height = WINSIZEY;
	obj[15].isAlive = true;
	obj[15].isWall = true;
	obj[15].isItem = false;
	obj[15].rcObject = RectMake(obj[15].x, obj[15].y, obj[15].width, obj[15].height);

	// 2�� �� ��ֹ� 1
	obj[62].OBJ_TYPE = OBJ_STONE;
	obj[62].image = IMAGEMANAGER->FindImage(TEXT("Stone"));
	obj[62].x = WINSIZEX + (WINSIZEX / 4) - (WALL_SIZE / 2);
	obj[62].y = WINSIZEY / 4 - (WALL_SIZE / 2);
	obj[62].width = WALL_SIZE;
	obj[62].height = WALL_SIZE;
	obj[62].isAlive = true;
	obj[62].isWall = true;
	obj[62].isItem = false;
	obj[62].rcObject = RectMake(obj[62].x, obj[62].y, obj[62].width, obj[62].height);

	// 2�� �� ��ֹ� 2
	obj[63].OBJ_TYPE = OBJ_STONE;
	obj[63].image = IMAGEMANAGER->FindImage(TEXT("Stone"));
	obj[63].x = WINSIZEX + (WINSIZEX / 4) - (WALL_SIZE / 2);
	obj[63].y = (WINSIZEY / 4) * 3 - (WALL_SIZE / 2);
	obj[63].width = WALL_SIZE;
	obj[63].height = WALL_SIZE;
	obj[63].isAlive = true;
	obj[63].isWall = true;
	obj[63].isItem = false;
	obj[63].rcObject = RectMake(obj[63].x, obj[63].y, obj[63].width, obj[63].height);


	// 2�� �� ��ֹ� 3
	obj[64].OBJ_TYPE = OBJ_STONE;
	obj[64].image = IMAGEMANAGER->FindImage(TEXT("HeightWall"));
	obj[64].x = WINSIZEX + (WINSIZEX / 2) - (WALL_SIZE / 2);
	obj[64].y = (WINSIZEY / 3) - (WALL_SIZE / 2);
	obj[64].width = WALL_SIZE;
	obj[64].height = (WINSIZEY / 4) + WALL_SIZE*2;
	obj[64].isAlive = true;
	obj[64].isWall = true;
	obj[64].isItem = false;
	obj[64].rcObject = RectMake(obj[64].x, obj[64].y, obj[64].width, obj[64].height);


	// 2���� ȸ�� ������ 1
	obj[86].image = IMAGEMANAGER->AddFrameImage(TEXT("HealthPack"), TEXT("Image/HealthPack.bmp"), 42, 30, 1, 1, true, RGB(0, 255, 0));
	obj[86].x = WINSIZEX * 2 - (WALL_SIZE+ITEM_WIDTH) - ITEM_WIDTH/2;	// ��ġ X
	obj[86].y = WINSIZEY/2 - ITEM_HEIGHT/2;						// ��ġ Y
	obj[86].width = ITEM_WIDTH;						// ��
	obj[86].height = ITEM_HEIGHT;					// ����
	obj[86].isAlive = true;							// ��������
	obj[86].isWall = false;							// ���ΰ�?
	obj[86].isItem = true;							// �������ΰ�?
	obj[86].dir = DIRECTION::DIR_NONE;				// ��������ΰ�?
	obj[86].rcObject = RectMakeCenter(obj[86].x, obj[86].y, obj[86].width, obj[86].height);

	return true;
}