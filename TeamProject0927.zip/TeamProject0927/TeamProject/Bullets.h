#pragma once

#include "GameNode.h"
#include "GameHeader.h"
#include "Animation.h"

#define MAX_BULLET			100		// �ִ� źȯ ��(����)
#define MAX_PARTICLETIME	180.f	// �ִ� ���Ľð�(�Ҽ�/ms)

#define PARTICLE_SIZE	40			//  źȯ ��ƼŬ ũ��
#define BOMB_SIZE		128			//	��ź ���� ũ��


struct Ammo
{
	GUNYTPE	gunType;			// � ���� źȯ�ΰ�?
	bool	isFire;				// źȯ�� ���ư��� �ִ� ��Ȳ�ΰ�? 
	bool	isParticle;			// źȯ�� ���� �Ǵ� ����ȭ ���ΰ�?
	bool	isPlayer;			// �÷��̾ �� źȯ�ΰ�? �ƴϸ� ���� �� źȯ�ΰ�?
	float	x, y;				// źȯ�� ��ġ
	float	speed;				// źȯ�� �ӵ�
	float	angle;				// źȯ�� ����
	float	length;
	int		radius;				// źȯ�� ������
	int		boundMAX;			// źȯ�� �ִ� �ñ� �� �ִ� ��.
	int		boundCount;			// źȯ�� ƨ�� Ƚ��.
	int		damage;				// źȯ ������.
	float	ParticleTime;		// źȯ�� ���Ľ��۽ð�.
	RECT	rcBullet;			// źȯ�� �浹 �簢�� ��ü

	POINT	CameraPos;			// ī�޶� ������

	bool	isBoss;
};


class Bullets : public GameNode
{
private:
	Image * imgBullet;
	Image *			imgBomb;

	Animation *		aniBulletRifle;
	Animation *		aniBulletEnemy;
	Animation *		aniBulletBomb;

	Ammo * bullet;
	int	bulletIndex;

public:
	Bullets();
	~Bullets();

	//==============================================
	void BulletMove();
	bool BulletFire(const float& inputEndX, const float& inputEndY, const float& inputAngle, const float& inputGunLength, const bool & inputIsPlayer, const GUNYTPE & inputGunType);
	void ShotGunFire(const float & inputEndX, const float & inputEndY, const float & inputAngle, const float & inputGunLength, const bool & inputIsPlayer, const GUNYTPE & inputGunType);
	void BombFire(const float & inputEndX, const float & inputEndY, const float & inputAngle, const float & inputGunLength, const bool & inputIsPlayer, const GUNYTPE & inputGunType);
	bool HitCollision(const float & ObjectX, const float & ObjectY, const float & ObjectRadius, const bool & ObjectIsPlayer, const bool & ObjectIsAlive);		// 
	bool HitCollisionRect(const RECT & ObjectRECT, const bool & ObjectIsPlayer, const bool & ObjectIsAlive);
	void BossPattern2(const float& posX, const float& posY, const float& angle, const float& length, const bool& isPlayer);
	void BossPattern3(const float& posX, const float& posY, const float& angle, const float& length, const bool& isPlayer);
	void BossBulletMove();
	//================================================================

	virtual bool Init();
	virtual void Release();
	virtual void Update();
	virtual void Render(HDC hdc);
	void	SetPos(int inputIndex, POINT p) { bullet[inputIndex].CameraPos = p; }
	POINT*	GetPos(int inputIndex) { return &bullet[inputIndex].CameraPos; }

	inline bool		GetIsBoss(int inputIndex) { return bullet[inputIndex].isBoss; }
	inline float   GetAngle(int inputIndex) { return bullet[inputIndex].angle; }
	inline void    SetAngle(int inputIndex, float angle) { bullet[inputIndex].angle = angle; }
	inline float   GetX(int inputIndex) { return bullet[inputIndex].x; }
	inline void    SetX(int inputIndex, float _x) { bullet[inputIndex].x = _x; }
	inline float   GetY(int inputIndex) { return bullet[inputIndex].y; }
	inline void	   SetY(int inputIndex, float _y) { bullet[inputIndex].y = _y; }
};