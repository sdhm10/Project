#pragma once

#include "GameNode.h"
#include "Bullets.h"

#define SHOTGUNRELOAD 120
#define ROCKETRELOAD  300

struct GUNTYPEUI
{
	Image* GunUI;
	bool   isSelect;
};

class Player : public GameNode			// ���ӳ�� ���
{
private:
	Image*		playerImage;			// ������
	Image*		hpImage[5];				// ü��UI
	Image*		gunImage;				// �ѱ� �̹���
	GUNTYPEUI	GunTypeUI[3];
	Animation*	playerAni;				// �ִϸ��̼�
	DWORD		SGReloadTime;
	DWORD		RKReloadTime;
	POINT		CameraPos;				// ī�޶� ����
	RECT		playerRc;				// �浹üũ��
	int			hp;						// ü��
	int			PlayerR;				// ������
	float		angle;					// ���� (0,90,180,270)
	float		posX;					// ��ġ
	float		posY;
	float		handX;					// �ѱ��� ��ġ
	float		handY;
	float		speed;					// �ӵ�
	bool		isAlive;				// ����üũ
	bool		isPlayer;				// PC/NPC
	GUNYTPE		gunType;				// ������ ���� ����
	DIRECTION	dirState;				// ������ġ
	STATE		playerState;			// �÷��̾� ����








public:
	Player();
	~Player();

	void PlayerController(Bullets& bullets);	
	bool PlayerAttack(Bullets& bullets);		
	void FrameMove();							
	bool HitEvent(Bullets& bullets);			
	bool DeadCheck();

	virtual bool Init();
	virtual void Release();
	virtual void Update(Bullets& bullets);
	virtual void Render(HDC hdc);

	// ī�޶� �Ŵ��� ����
	void	SetPos(POINT p) { CameraPos = p; }
	POINT*	GetPos() { return &CameraPos; }

	//==============================================================================================
	inline GUNYTPE GetGUNYTPE() { return gunType; }		
	inline bool GetIsPlayer() { return isPlayer; }
	inline bool GetIsAlive() { return isAlive; }		
	inline float GetX() { return posX; }				
	inline float GetY() { return posY; }				
	inline float GetSpeed() { return speed; }			
	inline float GetAngle() { return angle; }			
	inline int GetRadius() { return PlayerR; }			
	inline RECT CollisionRECT() { return playerRc; }	

	inline void SetGUNYTPE(GUNYTPE inputGUNYTPE) { gunType = inputGUNYTPE; }
	inline void SetIsPlayer(bool inputIsPlayer) { isPlayer = inputIsPlayer; }
	inline void SetIsAlive(bool inputIsAlive) { isAlive = inputIsAlive; }
	inline void SetX(float inputX) { posX = inputX; }
	inline void SetY(float inputY) { posY = inputY; }
	inline void SetSpeed(float inputSpeed) { speed = inputSpeed; }
	inline void SetAngle(float inputAngle) { angle = inputAngle; }
	inline void SetRadius(int inputRadius) { PlayerR = inputRadius; }
	//==============================================================================================
	inline int GetHp() { return hp; }		
	inline void SetHp(int _hp) { hp += _hp; }
	inline void SetHpAdd() { ++hp; }			
};

