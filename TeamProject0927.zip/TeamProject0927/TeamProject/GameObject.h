#pragma once

#include "GameHeader.h"
#include "Animation.h"
#include "Player.h"
#include "Enemy.h"


#define MAX_OBJECT	100
#define MAX_OBJECT_IMAGE 5
#define ITEM_WIDTH 42.f
#define ITEM_HEIGHT 30.f

#define WALL_SIZE 50

struct Game_Object
{
	Image*		image;

	float		x, y;				// ��ġ X,Y
	float		width, height;		// �� ũ��(��, ����)
	bool		isAlive;			// ����ó�� isDead -> isAlive�� ����. true�� �ǹ̰� �ݴ�� �����
	bool		isWall;				// ���ΰ�?
	bool		isItem;				// �������ΰ�?
	RECT		rcObject;			// �簢�� �浹��ü
	DIRECTION	dir;				// ����

	OBJECT      OBJ_TYPE;
	POINT		CameraPos;			// ī�޶� ������
};


class GameObject
{
private:
	Game_Object obj[MAX_OBJECT];
	Image* ObjectImageType[MAX_OBJECT_IMAGE];

public:
	GameObject();
	~GameObject();

	virtual bool Init();
	virtual void Release();
	virtual void Update(Bullets& inputBullets, Player& inputPlayer, Enemy& inputEnemy);
	virtual void Render(HDC hdc);

	bool Init_Room1();			// 1����
	bool Init_Room2();			// 2����
	bool Init_Room3();			// 3����
	bool Init_Room4();			// 4����
	bool Init_Room5();			// 5����
	bool Init_Room6();			// 6����
	bool Init_Room7();			// 7����
	bool Init_Room8();			// 8����

	void	SetPos(int inputIndex, POINT p) { obj[inputIndex].CameraPos = p; }
	POINT*	GetPos(int inputIndex) { return &obj[inputIndex].CameraPos; }

	void HitEvent(Bullets & inputBullets, Player & inputPlayer, Enemy & inputEnemy);
	void HitBullets(Bullets & inputBullets);
	void HitPlayerEnemy(Player & inputPlayer, Enemy & inputEnemy);
	bool HitItem(Player & inputPlayer);
	int HitTest(const RECT & r1, const RECT & r2);


	bool DoorOpenEvent(Enemy & inputEnemy,int EnemyindexStart, int EnemyindexEnd, int DoorIndex1, int DoorIndex2);

	bool DoorCloseEvent(Enemy & inputEnemy, Player & inputPlayer, int Enemyindex, int DoorIndex1, int DoorIndex2);


	//==============================================================================================
	inline bool GetIsWall(int inputObjectIndex) { return obj[inputObjectIndex].isWall; }
	inline bool GetIsAlive(int inputObjectIndex) { return obj[inputObjectIndex].isAlive; }		
	inline float GetX(int inputObjectIndex) { return obj[inputObjectIndex].x; }					
	inline float GetY(int inputObjectIndex) { return obj[inputObjectIndex].y; }					
	inline float GetWidth(int inputObjectIndex) { return obj[inputObjectIndex].width; }			
	inline float GetHeight(int inputObjectIndex) { return obj[inputObjectIndex].height; }		
	inline RECT CollisionRECT(int inputObjectIndex) { return obj[inputObjectIndex].rcObject; }	

	inline void SetIsWall(int inputObjectIndex, bool inputIsWall) { obj[inputObjectIndex].isWall = inputIsWall; }
	inline void SetIsAlive(int inputObjectIndex, bool inputIsAlive) { obj[inputObjectIndex].isAlive = inputIsAlive; }
	inline void SetX(int inputObjectIndex, float inputX) { obj[inputObjectIndex].x = inputX; }
	inline void SetY(int inputObjectIndex, float inputY) { obj[inputObjectIndex].y = inputY; }
	inline void GetWidth(int inputObjectIndex, float inputWidth) { obj[inputObjectIndex].width = inputWidth; }
	inline void GetHeight(int inputObjectIndex, float inputHeight) { obj[inputObjectIndex].height = inputHeight; }
	//==============================================================================================
};