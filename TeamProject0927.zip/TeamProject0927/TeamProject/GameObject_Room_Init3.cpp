#include "GameObject.h"

bool GameObject::Init_Room3()
{

	// 3�� �� ���� �� ��
	obj[16].OBJ_TYPE = OBJ_WALL;
	obj[16].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[16].x = WINSIZEX;
	obj[16].y = WINSIZEY;
	obj[16].width = WALL_SIZE;
	obj[16].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[16].isAlive = true;
	obj[16].isWall = true;
	obj[16].isItem = false;
	obj[16].rcObject = RectMake(obj[16].x, obj[16].y, obj[16].width, obj[16].height);

	// 3�� �� ���� �Ʒ� ��
	obj[17].OBJ_TYPE = OBJ_WALL;
	obj[17].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[17].x = WINSIZEX;
	obj[17].y = WINSIZEY + (WINSIZEY / 2 + WALL_SIZE / 2);
	obj[17].width = WALL_SIZE;
	obj[17].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[17].isAlive = true;
	obj[17].isWall = true;
	obj[17].isItem = false;
	obj[17].rcObject = RectMake(obj[17].x, obj[17].y, obj[17].width, obj[17].height);

	// 3�� �� ���� ��
	obj[18].OBJ_TYPE = OBJ_DOOR;
	obj[18].image = IMAGEMANAGER->FindImage(TEXT("Door"));
	obj[18].x = WINSIZEX;
	obj[18].y = WINSIZEY + (WINSIZEY / 2 - WALL_SIZE / 2);
	obj[18].width = WALL_SIZE;
	obj[18].height = WALL_SIZE;
	obj[18].isAlive = true;
	obj[18].isWall = true;
	obj[18].isItem = false;
	obj[18].rcObject = RectMake(obj[18].x, obj[18].y, obj[18].width, obj[18].height);

	// 3�� �� �� ���� ��
	obj[19].OBJ_TYPE = OBJ_WALL;
	obj[19].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[19].x = WINSIZEX;
	obj[19].y = WINSIZEY;
	obj[19].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[19].height = WALL_SIZE;
	obj[19].isAlive = true;
	obj[19].isWall = true;
	obj[19].isItem = false;
	obj[19].rcObject = RectMake(obj[19].x, obj[19].y, obj[19].width, obj[19].height);

	// 3�� �� �� ������ ��
	obj[20].OBJ_TYPE = OBJ_WALL;
	obj[20].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[20].x = WINSIZEX + (WINSIZEX / 2 + WALL_SIZE / 2);
	obj[20].y = WINSIZEY;
	obj[20].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[20].height = WALL_SIZE;
	obj[20].isAlive = true;
	obj[20].isWall = true;
	obj[20].isItem = false;
	obj[20].rcObject = RectMake(obj[20].x, obj[20].y, obj[20].width, obj[20].height);

	// 3�� �� ���� ��
	obj[21].OBJ_TYPE = OBJ_DOOR;
	obj[21].image = IMAGEMANAGER->FindImage(TEXT("Door"));
	obj[21].x = WINSIZEX + (WINSIZEX / 2 - WALL_SIZE / 2);
	obj[21].y = WINSIZEY;
	obj[21].width = WALL_SIZE;
	obj[21].height = WALL_SIZE;
	obj[21].isAlive = false;
	obj[21].isWall = true;
	obj[21].isItem = false;
	obj[21].rcObject = RectMake(obj[21].x, obj[21].y, obj[21].width, obj[21].height);

	// 3�� �� �Ʒ��� ��
	obj[22].OBJ_TYPE = OBJ_WALL;
	obj[22].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[22].x = WINSIZEX;
	obj[22].y = WINSIZEY * 2 - WALL_SIZE;
	obj[22].width = WINSIZEX;
	obj[22].height = WALL_SIZE;
	obj[22].isAlive = true;
	obj[22].isWall = true;
	obj[22].isItem = false;
	obj[22].rcObject = RectMake(obj[22].x, obj[22].y, obj[22].width, obj[22].height);

	// 3�� �� ������ ��
	obj[23].OBJ_TYPE = OBJ_WALL;
	obj[23].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[23].x = WINSIZEX * 2 - WALL_SIZE;
	obj[23].y = WINSIZEY;
	obj[23].width = WALL_SIZE;
	obj[23].height = WINSIZEY;
	obj[23].isAlive = true;
	obj[23].isWall = true;
	obj[23].isItem = false;
	obj[23].rcObject = RectMake(obj[23].x, obj[23].y, obj[23].width, obj[23].height);



	// 3�� �� ��ֹ� 1
	obj[65].OBJ_TYPE = OBJ_STONE;
	obj[65].image = IMAGEMANAGER->FindImage(TEXT("HeightWall"));
	obj[65].x = WINSIZEX + (WINSIZEX / 2) - (WALL_SIZE / 2);
	obj[65].y = WINSIZEY + (WINSIZEY / 3) - (WALL_SIZE / 2);
	obj[65].width = WALL_SIZE;
	obj[65].height = WINSIZEY / 3 * 2 - (WALL_SIZE / 2);
	obj[65].isAlive = true;
	obj[65].isWall = true;
	obj[65].isItem = false;
	obj[65].rcObject = RectMake(obj[65].x, obj[65].y, obj[65].width, obj[65].height);

	// 3�� �� ��ֹ� 2
	obj[66].OBJ_TYPE = OBJ_STONE;
	obj[66].image = IMAGEMANAGER->FindImage(TEXT("Stone"));
	obj[66].x = WINSIZEX + (WINSIZEX / 4) - (WALL_SIZE / 2);
	obj[66].y = WINSIZEY + (WINSIZEY / 3) - (WALL_SIZE / 2);
	obj[66].width = WALL_SIZE;
	obj[66].height = WALL_SIZE;
	obj[66].isAlive = true;
	obj[66].isWall = true;
	obj[66].isItem = false;
	obj[66].rcObject = RectMake(obj[66].x, obj[66].y, obj[66].width, obj[66].height);

	// 3�� �� ��ֹ� 3
	obj[67].OBJ_TYPE = OBJ_STONE;
	obj[67].image = IMAGEMANAGER->FindImage(TEXT("Stone"));
	obj[67].x = WINSIZEX + (WINSIZEX / 4 * 3) - (WALL_SIZE / 2);
	obj[67].y = WINSIZEY + (WINSIZEY / 3) - (WALL_SIZE / 2);
	obj[67].width = WALL_SIZE;
	obj[67].height = WALL_SIZE;
	obj[67].isAlive = true;
	obj[67].isWall = true;
	obj[67].isItem = false;
	obj[67].rcObject = RectMake(obj[67].x, obj[67].y, obj[67].width, obj[67].height);


	// 3���� ȸ�� ������ 1
	obj[87].image = IMAGEMANAGER->AddFrameImage(TEXT("HealthPack"), TEXT("Image/HealthPack.bmp"), 42, 30, 1, 1, true, RGB(0, 255, 0));
	obj[87].x = WINSIZEX + (WINSIZEX / 4 * 3) - (WALL_SIZE / 2);
	obj[87].y = WINSIZEY * 2 - (WALL_SIZE + ITEM_HEIGHT);					// ��ġ Y
	obj[87].width = ITEM_WIDTH;						// ��
	obj[87].height = ITEM_HEIGHT;					// ����
	obj[87].isAlive = true;							// ��������
	obj[87].isWall = false;							// ���ΰ�?
	obj[87].isItem = true;							// �������ΰ�?
	obj[87].dir = DIRECTION::DIR_NONE;				// ��������ΰ�?
	obj[87].rcObject = RectMakeCenter(obj[87].x, obj[87].y, obj[87].width, obj[87].height);

	return true;
}