#include "Bullets.h"

Bullets::Bullets()
{

}

Bullets::~Bullets()
{
	// źȯ
	SAFE_DELETE(aniBulletRifle);
	SAFE_DELETE(aniBulletEnemy);
	SAFE_DELETE(aniBulletBomb);

	SAFE_DELETE(imgBullet);
	SAFE_DELETE(imgBomb);

	delete[] bullet;
}

bool Bullets::Init()
{
	imgBullet = IMAGEMANAGER->AddFrameImage(TEXT("Bullet"), TEXT("Image/Bullet(40,120).bmp"), 40, 120, 1, 4, true, RGB(0, 255, 0));
	imgBomb = IMAGEMANAGER->AddFrameImage(TEXT("Bomb"), TEXT("Image/Bomb(30,30).bmp"), 30, 30, 1, 1, true, RGB(0, 255, 0));

	EFFECTMANAGER->AddEffect(TEXT("Effect_Crash"),
		TEXT("Image/Effect_Crash.bmp"),
		PARTICLE_SIZE * 3, PARTICLE_SIZE,
		40, 40,
		1, 0.3f, 10,
		RGB(0, 255, 0));


	EFFECTMANAGER->AddEffect(TEXT("Effect_Bomb"),
		TEXT("Image/Effect_Bomb.bmp"),
		BOMB_SIZE * 6, BOMB_SIZE,
		128, 128,
		1, 0.3f, 10,
		RGB(0, 255, 0));


	bullet = new Ammo[MAX_BULLET];
	bulletIndex = 0;


	bulletIndex = 0;
	
	//�÷��̾� źȯ
	aniBulletRifle = new Animation;
	aniBulletRifle->Init(imgBullet);
	aniBulletRifle->setPlayFrame(0, 1, false, true);
	aniBulletRifle->setFPS(1);

	// ��źȯ
	aniBulletEnemy = new Animation;
	aniBulletEnemy->Init(imgBullet);
	aniBulletEnemy->setPlayFrame(1, 2, false, true);
	aniBulletEnemy->setFPS(1);

	// ��ź
	aniBulletBomb = new Animation;
	aniBulletBomb->Init(imgBomb);
	aniBulletBomb->setPlayFrame(0, 1, false, true);
	aniBulletBomb->setFPS(1);


	// źȯ �迭 �ʱ�ȭ
	for (int i = 0; i < MAX_BULLET; i++)
	{
		bullet[i].length = 0.f;
		bullet[i].gunType = GUNYTPE::GUNYTPE_NONE;	// � ���� źȯ�ΰ�?
		bullet[i].isFire = false;					// źȯ�� ���ư��� �ִ� ��Ȳ�ΰ�? 
		bullet[i].isParticle = false;				// źȯ�� ���� �Ǵ� ����ȭ ���ΰ�?
		bullet[i].isPlayer = false;					// �÷��̾ �� źȯ�ΰ�? �ƴϸ� ���� �� źȯ�ΰ�?
		bullet[i].x = 0.f;							// źȯ��ġ X
		bullet[i].y = 0.f;							// źȯ��ġ Y
		bullet[i].CameraPos.x = bullet[i].x;		// ī�޶� ���� X
		bullet[i].CameraPos.y = bullet[i].y;		// ī�޶� ���� Y
		bullet[i].speed = 0.f;						// źȯ�� �ӵ�
		bullet[i].radius = 0;						// źȯ�� ������
		bullet[i].boundCount = 0;					// źȯ�� �ִ� �ñ� �� �ִ� ��.
		bullet[i].boundMAX = 1;						// źȯ�� ƨ�� Ƚ��.
		bullet[i].damage = 0;						// źȯ ������
		bullet[i].ParticleTime = 0.f;				// źȯ�� ���Ľ��۽ð�
		bullet[i].rcBullet = RectMakeCenter(bullet[i].x, bullet[i].y, bullet[i].radius * 2, bullet[i].radius * 2);	// źȯ�� �浹 �簢�� ��ü

		bullet[i].isBoss = false;
	}

	return true;
}

void Bullets::Release()
{

}


void Bullets::Update()
{
	BulletMove();
	BossBulletMove();
}


void Bullets::Render(HDC hdc)
{
	for (int i = 0; i < MAX_BULLET; i++)
	{
		if (bullet[i].isParticle)
		{
			if (bullet[i].gunType == GUNYTPE::GUNYTPE_BOMB)
			{
				bullet[i].rcBullet = RectMakeCenter(bullet[i].x, bullet[i].y, BOMB_SIZE, BOMB_SIZE);
				bullet[i].radius = BOMB_SIZE / 2;
			}

			EFFECTMANAGER->Render(hdc);

			continue;
		}

		if (bullet[i].isFire == false)
			continue;

		if (!bullet[i].isPlayer)
		{
			imgBullet->AniRender(hdc, bullet[i].x - bullet[i].radius*2 - CAMERA->getPosition()->x, bullet[i].y - bullet[i].radius*2 - CAMERA->getPosition()->y, aniBulletEnemy);
		}

		if (bullet[i].gunType == GUNYTPE::GUNYTPE_RIFLE && bullet[i].isPlayer)
		{
			imgBullet->AniRender(hdc, bullet[i].x - bullet[i].radius*2 - CAMERA->getPosition()->x, bullet[i].y - bullet[i].radius*2 - CAMERA->getPosition()->y, aniBulletRifle);
		}
		else if (bullet[i].gunType == GUNYTPE::GUNYTPE_SHOTGUN && bullet[i].isPlayer)
		{
			imgBullet->AniRender(hdc, bullet[i].x - bullet[i].radius * 2 - CAMERA->getPosition()->x, bullet[i].y - bullet[i].radius * 2 - CAMERA->getPosition()->y, aniBulletRifle);
		}
		else if (bullet[i].gunType == GUNYTPE::GUNYTPE_BOMB && bullet[i].isPlayer)
		{
			imgBomb->AniRender(hdc, bullet[i].x - bullet[i].radius - CAMERA->getPosition()->x, bullet[i].y - bullet[i].radius - CAMERA->getPosition()->y, aniBulletBomb);
		}

	}
}

void Bullets::BulletMove()
{
	for (int i = 0; i < MAX_BULLET; i++)
	{

		if (GetTickCount() - bullet[i].ParticleTime > MAX_PARTICLETIME)
		{
			bullet[i].isParticle = false;
		}

		if (bullet[i].boundCount >= bullet[i].boundMAX)
		{
			bullet[i].boundCount = 0;
			bullet[i].isFire = false;
			bullet[i].isParticle = true;

			if (bullet[i].gunType == GUNYTPE::GUNYTPE_BOMB)
				EFFECTMANAGER->Play(TEXT("Effect_Bomb"), bullet[i].x - CAMERA->getPosition()->x, bullet[i].y - CAMERA->getPosition()->y);
			if (bullet[i].gunType == GUNYTPE::GUNYTPE_RIFLE)
				EFFECTMANAGER->Play(TEXT("Effect_Crash"), bullet[i].x - CAMERA->getPosition()->x, bullet[i].y - CAMERA->getPosition()->y);
			if (bullet[i].gunType == GUNYTPE::GUNYTPE_SHOTGUN)
				EFFECTMANAGER->Play(TEXT("Effect_Crash"), bullet[i].x - CAMERA->getPosition()->x, bullet[i].y - CAMERA->getPosition()->y);

			bullet[i].ParticleTime = GetTickCount();
		}

		if (bullet[i].isFire == false || bullet[i].isParticle == true)
		{
			continue;
		}

		if (bullet[i].isBoss == true)
			continue;

		bullet[i].x += cosf(bullet[i].angle) * bullet[i].speed;
		bullet[i].y += -sinf(bullet[i].angle) * bullet[i].speed;
		bullet[i].CameraPos.x = bullet[i].x;		// ī�޶� ����
		bullet[i].CameraPos.y = bullet[i].y;		// ī�޶� ����
		bullet[i].rcBullet = RectMakeCenter(bullet[i].x, bullet[i].y, bullet[i].radius * 2, bullet[i].radius * 2);
		
		if (bullet[i].x - bullet[i].radius - CAMERA->getPosition()->x < 0)
		{
			bullet[i].angle = PI - bullet[i].angle;
			bullet[i].boundCount++;
		}
		if (bullet[i].y - bullet[i].radius - CAMERA->getPosition()->y < 0)
		{
			bullet[i].angle = PI2 - bullet[i].angle;
			bullet[i].boundCount++;
		}
		if (bullet[i].x + bullet[i].radius - CAMERA->getPosition()->x > WINSIZEX)
		{
			bullet[i].angle = PI - bullet[i].angle;
			bullet[i].boundCount++;
		}
		if (bullet[i].y + bullet[i].radius - CAMERA->getPosition()->y > WINSIZEY)
		{
			bullet[i].angle = PI2 - bullet[i].angle;
			bullet[i].boundCount++;
		}
	}
}

bool Bullets::BulletFire(const float & inputEndX, const float & inputEndY, const float & inputAngle, const float & inputGunLength, const bool & inputIsPlayer, const GUNYTPE & inputGunType)
{

	for (int i = 0; i < MAX_BULLET; i++)
	{
		if (bullet[i].isFire == true || bullet[i].isParticle == true)
			continue;

		bullet[i].isBoss = false;
		bullet[i].isFire = true;
		bullet[i].isParticle = false;
		bullet[i].gunType = inputGunType;
		bullet[i].isPlayer = inputIsPlayer;
		bullet[i].speed = 6.f;
		bullet[i].radius = 10;
		bullet[i].boundMAX = 1;
		bullet[i].boundCount = 0;
		bullet[i].x = inputEndX + (cosf(inputAngle) * (inputGunLength));
		bullet[i].y = inputEndY + (-sinf(inputAngle) * (inputGunLength));

		bullet[i].angle = inputAngle;
		bullet[i].rcBullet = RectMakeCenter(bullet[i].x, bullet[i].y, bullet[i].radius * 2, bullet[i].radius * 2);

		break;
	}

	return true;
}

void Bullets::ShotGunFire(const float & inputEndX, const float & inputEndY, const float & inputAngle, const float & inputGunLength, const bool & inputIsPlayer, const GUNYTPE & inputGunType)
{
	int tempBulletNumber = 0;
	float tempAngle = PI / 6.f;

	for (int j = 0; j < 5; j++)
	{
		for (int i = 0; i < MAX_BULLET; i++)
		{
			if (bullet[i].isFire == true || bullet[i].isParticle == true)
				continue;

			bullet[i].isBoss = false;
			bullet[i].isFire = true;
			bullet[i].isParticle = false;
			bullet[i].gunType = inputGunType;
			bullet[i].isPlayer = inputIsPlayer;
			bullet[i].speed = 6.f;
			bullet[i].radius = 10;
			bullet[i].boundMAX = 1;
			bullet[i].boundCount = 0;
			bullet[i].length = inputGunLength;
			bullet[i].x = inputEndX + (cosf(inputAngle) * (bullet[i].length));
			bullet[i].y = inputEndY + (-sinf(inputAngle) * (bullet[i].length));
			bullet[i].angle = inputAngle + tempAngle;

			tempAngle = -tempAngle;
			tempAngle /= 2;
			tempBulletNumber--;

			bullet[i].rcBullet = RectMakeCenter(bullet[i].x, bullet[i].y, bullet[i].radius * 2, bullet[i].radius * 2);

			break;
		}
	}
}

void Bullets::BombFire(const float & inputEndX, const float & inputEndY, const float & inputAngle, const float & inputGunLength, const bool & inputIsPlayer, const GUNYTPE & inputGunType)
{
	for (int i = 0; i < MAX_BULLET; i++)
	{
		if (bullet[i].isFire == true || bullet[i].isParticle == true)
			continue;

		bullet[i].isBoss = false;
		bullet[i].isFire = true;
		bullet[i].isParticle = false;
		bullet[i].gunType = inputGunType;
		bullet[i].isPlayer = inputIsPlayer;
		bullet[i].speed = 3.f;
		bullet[i].boundMAX = 1;
		bullet[i].boundCount = 0;
		bullet[i].radius = 15;
		bullet[i].x = inputEndX + (cosf(inputAngle) * (inputGunLength));
		bullet[i].y = inputEndY + (-sinf(inputAngle) * (inputGunLength));
		bullet[i].angle = inputAngle;

		bullet[i].rcBullet = RectMakeCenter(bullet[i].x, bullet[i].y, bullet[i].radius * 2, bullet[i].radius * 2);
		break;
	}
}

bool Bullets::HitCollision(const float & ObjectX, const float & ObjectY, const float & ObjectRadius, const bool & ObjectIsPlayer, const bool & ObjectIsAlive)
{
	for (int i = 0; i < MAX_BULLET; i++)
	{
		if (CollisionCircleAndCircle(bullet[i].radius, bullet[i].x, bullet[i].y,
			ObjectRadius, ObjectX, ObjectY)
			&& bullet[i].isFire
			&& bullet[i].isPlayer != ObjectIsPlayer
			&& ObjectIsAlive)
		{
			bullet[i].isFire = false;
			bullet[i].isParticle = true;
			bullet[i].isBoss = false;

			if (bullet[i].gunType == GUNYTPE::GUNYTPE_BOMB)
				EFFECTMANAGER->Play(TEXT("Effect_Bomb"), bullet[i].x - CAMERA->getPosition()->x, bullet[i].y - CAMERA->getPosition()->y);
			if (bullet[i].gunType == GUNYTPE::GUNYTPE_RIFLE)
				EFFECTMANAGER->Play(TEXT("Effect_Crash"), bullet[i].x - CAMERA->getPosition()->x, bullet[i].y - CAMERA->getPosition()->y);
			if (bullet[i].gunType == GUNYTPE::GUNYTPE_SHOTGUN)
				EFFECTMANAGER->Play(TEXT("Effect_Crash"), bullet[i].x - CAMERA->getPosition()->x, bullet[i].y - CAMERA->getPosition()->y);

			if (bullet[i].isParticle)
			{
				bullet[i].ParticleTime = GetTickCount();
			}
			

			return true;
		}

		if (CollisionCircleAndCircle(bullet[i].radius, bullet[i].x, bullet[i].y,
			ObjectRadius, ObjectX, ObjectY)
			&& bullet[i].isParticle
			&& bullet[i].gunType == GUNYTPE::GUNYTPE_BOMB
			&& bullet[i].isPlayer != ObjectIsPlayer
			&& ObjectIsAlive)
		{
			return true;
		}
	}

	return false;
}

bool Bullets::HitCollisionRect(const RECT & ObjectRECT, const bool & ObjectIsPlayer, const bool & ObjectIsAlive)
{


	for (int i = 0; i < MAX_BULLET; i++)
	{
		if (CollisionRectAndRect(bullet[i].rcBullet, ObjectRECT)
			&& bullet[i].isFire
			&& bullet[i].isPlayer != ObjectIsPlayer
			&& ObjectIsAlive)
		{
			bullet[i].isFire = false;
			bullet[i].isParticle = true;
			bullet[i].isBoss = false;

			if (bullet[i].gunType == GUNYTPE::GUNYTPE_BOMB)
				EFFECTMANAGER->Play(TEXT("Effect_Bomb"), bullet[i].x - CAMERA->getPosition()->x, bullet[i].y - CAMERA->getPosition()->y);
			if (bullet[i].gunType == GUNYTPE::GUNYTPE_RIFLE)
				EFFECTMANAGER->Play(TEXT("Effect_Crash"), bullet[i].x - CAMERA->getPosition()->x, bullet[i].y - CAMERA->getPosition()->y);
			if (bullet[i].gunType == GUNYTPE::GUNYTPE_SHOTGUN)
				EFFECTMANAGER->Play(TEXT("Effect_Crash"), bullet[i].x - CAMERA->getPosition()->x, bullet[i].y - CAMERA->getPosition()->y);

			if (bullet[i].isParticle)
			{
				bullet[i].ParticleTime = GetTickCount();
			}

			return true;
		}
	}


	return false;
}


void Bullets::BossPattern2(const float & posX, const float & posY, const float & angle, const float & length, const bool & isPlayer)
{
	for (int i = 0; i < MAX_BULLET; i++)
	{
		if (bullet[i].isFire == true || bullet[i].isParticle == true)
			continue;

		bullet[i].isFire = true;
		bullet[i].isParticle = false;
		bullet[i].gunType = GUNYTPE_RIFLE;
		bullet[i].isPlayer = isPlayer;
		bullet[i].isBoss = false;
		bullet[i].speed = 5.f;
		bullet[i].radius = 10;
		bullet[i].boundMAX = 1;
		bullet[i].boundCount = 0;
		bullet[i].angle = angle;
		bullet[i].x = posX + (cosf(angle) * (length));
		bullet[i].y = posY + (-sinf(angle) * (length));


		bullet[i].ParticleTime = GetTickCount();
		bullet[i].rcBullet = RectMakeCenter(bullet[i].x, bullet[i].y, bullet[i].radius * 2, bullet[i].radius * 2);

		break;
	}
}

void Bullets::BossPattern3(const float & posX, const float & posY, const float & angle, const float & length, const bool & isPlayer)
{
	for (int i = 0; i < MAX_BULLET; i++)
	{
		if (bullet[i].isFire == true || bullet[i].isParticle == true)
			continue;

		bullet[i].isFire = true;
		bullet[i].isParticle = false;
		bullet[i].gunType = GUNYTPE_RIFLE;
		bullet[i].isPlayer = isPlayer;
		bullet[i].length = length;
		bullet[i].isBoss = true;
		bullet[i].speed = 5.f;
		bullet[i].radius = 10;
		bullet[i].boundMAX = 1;
		bullet[i].boundCount = 0;
		bullet[i].angle = angle;
		bullet[i].x = posX + (cosf(angle) * (bullet[i].length));
		bullet[i].y = posY + (-sinf(angle) * (bullet[i].length));


		bullet[i].ParticleTime = GetTickCount();
		bullet[i].rcBullet = RectMakeCenter(bullet[i].x, bullet[i].y, bullet[i].radius * 2, bullet[i].radius * 2);

		break;
	}
}

void Bullets::BossBulletMove()
{
	int dir = 1;


	for (int i = 0; i < MAX_BULLET; i++)
	{
		if (bullet[i].isFire == false || bullet[i].isBoss == false)
			continue;

		bullet[i].angle += dir * 0.01f;

		bullet[i].x = WINSIZEX / 2 + WINSIZEX + cosf(bullet[i].angle) * bullet[i].length;		
		bullet[i].y = (WINSIZEY * 3) + (WINSIZEY / 2) + -sinf(bullet[i].angle) * bullet[i].length;			
		bullet[i].rcBullet = RectMakeCenter(bullet[i].x, bullet[i].y, bullet[i].radius * 2, bullet[i].radius * 2);
	
		if (bullet[i].x - bullet[i].radius - CAMERA->getPosition()->x < 0)
		{
			bullet[i].angle = PI - bullet[i].angle;
			bullet[i].boundCount++;
		}
		if (bullet[i].y - bullet[i].radius - CAMERA->getPosition()->y < 0)
		{
			bullet[i].angle = PI2 - bullet[i].angle;
			bullet[i].boundCount++;
		}
		if (bullet[i].x + bullet[i].radius - CAMERA->getPosition()->x > WINSIZEX)
		{
			bullet[i].angle = PI - bullet[i].angle;
			bullet[i].boundCount++;
		}
		if (bullet[i].y + bullet[i].radius - CAMERA->getPosition()->y > WINSIZEY)
		{
			bullet[i].angle = PI2 - bullet[i].angle;
			bullet[i].boundCount++;
		}

		if (GetTickCount() - bullet[i].ParticleTime > 5000.f)
		{
			bullet[i].isFire = false;
			bullet[i].isBoss = false;
			bullet[i].ParticleTime = NULL;
		}

		if (bullet[i].length != bullet[i + 1].length)
			dir *= -1;
	}
}

