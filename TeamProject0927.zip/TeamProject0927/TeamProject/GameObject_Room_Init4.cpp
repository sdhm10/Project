#include "GameObject.h"


bool GameObject::Init_Room4()
{

	// 4�� �� ���� ��
	obj[24].OBJ_TYPE = OBJ_WALL;
	obj[24].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[24].x = 0.f;
	obj[24].y = WINSIZEY;
	obj[24].width = WALL_SIZE;
	obj[24].height = WINSIZEY;
	obj[24].isAlive = true;
	obj[24].isWall = true;
	obj[24].isItem = false;
	obj[24].rcObject = RectMake(obj[24].x, obj[24].y, obj[24].width, obj[24].height);

	// 4�� �� ���� ��
	obj[25].OBJ_TYPE = OBJ_WALL;
	obj[25].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[25].x = 0.f;
	obj[25].y = WINSIZEY;
	obj[25].width = WINSIZEX;
	obj[25].height = WALL_SIZE;
	obj[25].isAlive = true;
	obj[25].isWall = true;
	obj[25].isItem = false;
	obj[25].rcObject = RectMake(obj[25].x, obj[25].y, obj[25].width, obj[25].height);

	// 4�� �� �Ʒ� ���� ��
	obj[26].OBJ_TYPE = OBJ_WALL;
	obj[26].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[26].x = 0.f;
	obj[26].y = WINSIZEY * 2 - WALL_SIZE;
	obj[26].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[26].height = WALL_SIZE;
	obj[26].isAlive = true;
	obj[26].isWall = true;
	obj[26].isItem = false;
	obj[26].rcObject = RectMake(obj[26].x, obj[26].y, obj[26].width, obj[26].height);

	// 4�� �� �Ʒ� ���� ��
	obj[27].OBJ_TYPE = OBJ_WALL;
	obj[27].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[27].x = WINSIZEX / 2 + WALL_SIZE / 2;
	obj[27].y = WINSIZEY * 2 - WALL_SIZE;
	obj[27].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[27].height = WALL_SIZE;
	obj[27].isAlive = true;
	obj[27].isWall = true;
	obj[27].isItem = false;
	obj[27].rcObject = RectMake(obj[27].x, obj[27].y, obj[27].width, obj[27].height);

	// 4�� �� �Ʒ� ��
	obj[28].OBJ_TYPE = OBJ_DOOR;
	obj[28].image = IMAGEMANAGER->FindImage(TEXT("Door"));
	obj[28].x = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[28].y = WINSIZEY * 2 - WALL_SIZE;
	obj[28].width = WALL_SIZE;
	obj[28].height = WALL_SIZE;
	obj[28].isAlive = true;
	obj[28].isWall = true;
	obj[28].isItem = false;
	obj[28].rcObject = RectMake(obj[28].x, obj[28].y, obj[28].width, obj[28].height);

	// 4�� �� ������ �� ��
	obj[29].OBJ_TYPE = OBJ_WALL;
	obj[29].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[29].x = WINSIZEX - WALL_SIZE;
	obj[29].y = WINSIZEY;
	obj[29].width = WALL_SIZE;
	obj[29].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[29].isAlive = true;
	obj[29].isWall = true;
	obj[29].isItem = false;
	obj[29].rcObject = RectMake(obj[29].x, obj[29].y, obj[29].width, obj[29].height);

	// 4�� �� ������ �Ʒ� ��
	obj[30].OBJ_TYPE = OBJ_WALL;
	obj[30].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[30].x = WINSIZEX - WALL_SIZE;
	obj[30].y = WINSIZEY + (WINSIZEY / 2 + WALL_SIZE / 2);
	obj[30].width = WALL_SIZE;
	obj[30].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[30].isAlive = true;
	obj[30].isWall = true;
	obj[30].isItem = false;
	obj[30].rcObject = RectMake(obj[30].x, obj[30].y, obj[30].width, obj[30].height);

	// 4�� �� ������ ��
	obj[31].OBJ_TYPE = OBJ_DOOR;
	obj[31].image = IMAGEMANAGER->FindImage(TEXT("Door"));
	obj[31].x = WINSIZEX - WALL_SIZE;
	obj[31].y = WINSIZEY + (WINSIZEY / 2 - WALL_SIZE / 2);
	obj[31].width = WALL_SIZE;
	obj[31].height = WALL_SIZE;
	obj[31].isAlive = false;
	obj[31].isWall = true;
	obj[31].isItem = false;
	obj[31].rcObject = RectMake(obj[31].x, obj[31].y, obj[31].width, obj[31].height);



	// 4�� �� ��ֹ� 1
	obj[68].OBJ_TYPE = OBJ_STONE;
	obj[68].image = IMAGEMANAGER->FindImage(TEXT("Stone"));
	obj[68].x = (WINSIZEX / 4) - (WALL_SIZE / 2);
	obj[68].y = WINSIZEY + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[68].width = WALL_SIZE;
	obj[68].height = WALL_SIZE;
	obj[68].isAlive = true;
	obj[68].isWall = true;
	obj[68].isItem = false;
	obj[68].rcObject = RectMake(obj[68].x, obj[68].y, obj[68].width, obj[68].height);

	// 4�� �� ��ֹ� 2
	obj[69].OBJ_TYPE = OBJ_STONE;
	obj[69].image = IMAGEMANAGER->FindImage(TEXT("WidthWall"));
	obj[69].x = (WINSIZEX - WALL_SIZE) / 2 - WALL_SIZE;
	obj[69].y = WINSIZEY + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[69].width = (WINSIZEX + WALL_SIZE) / 2;
	obj[69].height = WALL_SIZE;
	obj[69].isAlive = true;
	obj[69].isWall = true;
	obj[69].isItem = false;
	obj[69].rcObject = RectMake(obj[69].x, obj[69].y, obj[69].width, obj[69].height);

	// 4�� �� ��ֹ� 3
	obj[70].OBJ_TYPE = OBJ_STONE;
	obj[70].image = IMAGEMANAGER->FindImage(TEXT("WidthWall"));
	obj[70].x = WALL_SIZE;
	obj[70].y = WINSIZEY + (WINSIZEY / 2) - (WALL_SIZE / 2);
	obj[70].width = (WINSIZEX + WALL_SIZE) / 2;
	obj[70].height = WALL_SIZE;
	obj[70].isAlive = true;
	obj[70].isWall = true;
	obj[70].isItem = false;
	obj[70].rcObject = RectMake(obj[70].x, obj[70].y, obj[70].width, obj[70].height);

	// 4�� �� ��ֹ� 4
	obj[71].OBJ_TYPE = OBJ_STONE;
	obj[71].image = IMAGEMANAGER->FindImage(TEXT("Stone"));
	obj[71].x = (WINSIZEX / 4 * 3) - (WALL_SIZE / 2);
	obj[71].y = WINSIZEY + (WINSIZEY / 2) - (WALL_SIZE / 2);
	obj[71].width = WALL_SIZE;
	obj[71].height = WALL_SIZE;
	obj[71].isAlive = true;
	obj[71].isWall = true;
	obj[71].isItem = false;
	obj[71].rcObject = RectMake(obj[71].x, obj[71].y, obj[71].width, obj[71].height);

	// 4�� �� ��ֹ� 5
	obj[72].OBJ_TYPE = OBJ_STONE;
	obj[72].image = IMAGEMANAGER->FindImage(TEXT("Stone"));
	obj[72].x = (WINSIZEX / 4) - (WALL_SIZE / 2);
	obj[72].y = WINSIZEY + (WINSIZEY / 4 * 3) - (WALL_SIZE / 2);
	obj[72].width = WALL_SIZE;
	obj[72].height = WALL_SIZE;
	obj[72].isAlive = true;
	obj[72].isWall = true;
	obj[72].isItem = false;
	obj[72].rcObject = RectMake(obj[72].x, obj[72].y, obj[72].width, obj[72].height);

	// 4�� �� ��ֹ� 6
	obj[73].OBJ_TYPE = OBJ_STONE;
	obj[73].image = IMAGEMANAGER->FindImage(TEXT("WidthWall"));
	obj[73].x = (WINSIZEX - WALL_SIZE) / 2 - WALL_SIZE;
	obj[73].y = WINSIZEY + (WINSIZEY / 4 * 3) - (WALL_SIZE / 2);
	obj[73].width = (WINSIZEX + WALL_SIZE) / 2;
	obj[73].height = WALL_SIZE;
	obj[73].isAlive = true;
	obj[73].isWall = true;
	obj[73].isItem = false;
	obj[73].rcObject = RectMake(obj[73].x, obj[73].y, obj[73].width, obj[73].height);


	// 4���� ȸ�� ������ 1
	obj[88].image = IMAGEMANAGER->AddFrameImage(TEXT("HealthPack"), TEXT("Image/HealthPack.bmp"), 42, 30, 1, 1, true, RGB(0, 255, 0));
	obj[88].x = WINSIZEX - (WALL_SIZE + ITEM_WIDTH);
	obj[88].y = WINSIZEY + WALL_SIZE/2*3;							// ��ġ Y
	obj[88].width = ITEM_WIDTH;									// ��
	obj[88].height = ITEM_HEIGHT;								// ����
	obj[88].isAlive = true;										// ��������
	obj[88].isWall = false;										// ���ΰ�?
	obj[88].isItem = true;										// �������ΰ�?
	obj[88].dir = DIRECTION::DIR_NONE;							// ��������ΰ�?
	obj[88].rcObject = RectMakeCenter(obj[88].x, obj[88].y, obj[88].width, obj[88].height);

	return true;
}