#include "MainGame.h"

MainGame::MainGame()
{
	stalkerTest = new StalkerTest;
	assert(stalkerTest != NULL);
	stalkerTest->Init();
}

MainGame::~MainGame()
{
	stalkerTest->Release();
}


bool MainGame::Init()
{
	GameNode::Init(true);

	//================
	GetClientRect(_hWnd, &_rcClient);
	//================



	//////////////
	return true;
}

void MainGame::Release()
{
	GameNode::Release();

	//================
	stalkerTest->Release();
	//================
}

void MainGame::Update()
{
	GameNode::Update();


	//================
	stalkerTest->Update();
	//================
}

void MainGame::Render(HDC hdc)
{
	HDC backDC = this->GetBackBuffer()->GetMemDC();
	PatBlt(backDC, 0, 0, WINSIZEX, WINSIZEY, WHITENESS);			// ������ HDC ���ÿ� backDC���
																	// GameNode::Render(hdc);
																	//================														
	//================
	stalkerTest->Render(backDC);
	//================

	this->GetBackBuffer()->Render(hdc, 0, 0);
}