#include "StalkerTest.h"


StalkerTest::StalkerTest()
{
	gameObject = new GameObject;
	player = new Player;
	enemy = new Enemy;
	bullets = new Bullets;

	StartImage = IMAGEMANAGER->AddImage(TEXT("Start"), TEXT("Image/StartImage.bmp"), 1000, 800, false, false);
	LandImage = IMAGEMANAGER->AddImage(TEXT("Land"), TEXT("Image/Land.bmp"), 1000, 800, false, false);
	ReWardImage = IMAGEMANAGER->AddImage(TEXT("Reward"), TEXT("Image/Reward.bmp"), 1000, 800, false, false);
	RestartImage = IMAGEMANAGER->AddImage(TEXT("ReStart"), TEXT("Image/reStart.bmp"), 50, 50, true, RGB(0,255,0));
	Start = false;
}


StalkerTest::~StalkerTest()
{
	delete gameObject;
	delete player;
	delete enemy;
	delete bullets;
}

bool StalkerTest::Init()
{
	_ClearRoom = RectMake(0, WINSIZEY * 3, WINSIZEX, WINSIZEY);
	_rcClient  = { 0,0, WINSIZEX, WINSIZEY };
	_rcWorld   = { 0,0, WINSIZEX*5, WINSIZEY*5 };

	bullets->Init();
	gameObject->Init();
	player->Init();
	enemy->Init();


	if (CAMERA->Init(player->GetPos(), _rcClient, _rcWorld) == false)
	{
		return false;
	}


	return true;
}

void StalkerTest::Release()
{
	gameObject->Release();
	player->Release();
	enemy->Release();
	bullets->Release();
}


void StalkerTest::Update()
{
	if (!Start)
	{
		if (KEYMANAGER->isOnceKeyDown(VK_SPACE))
		{
			player->SetIsAlive(true);
			Start = true;
		}
	}
	else
	{
		EFFECTMANAGER->Update();

		player->Update(*bullets);
		enemy->Update(*bullets, *player);
		gameObject->Update(*bullets, *player, *enemy);
		bullets->Update();
		HitEvent();

		CAMERA->Update();			// ī�޶� ������Ʈ

		if (!player->GetIsAlive() && KEYMANAGER->isOnceKeyDown(VK_SPACE))
		{
			Start = false;
			bullets->Init();
			gameObject->Init();
			player->Init();
			enemy->Init();
		}

		if (CollisionRectAndRect(player->CollisionRECT(), _ClearRoom) && KEYMANAGER->isOnceKeyDown(VK_SPACE))
		{
			Start = false;
			bullets->Init();
			gameObject->Init();
			player->Init();
			enemy->Init();
		}
	}
}

void StalkerTest::Render(HDC hdc)
{

	LandImage->Render(hdc);
	ReWardImage->Render(hdc, 0 - CAMERA->getPosition()->x, WINSIZEY*3 - CAMERA->getPosition()->y);

	gameObject->Render(hdc);
	bullets->Render(hdc);
	enemy->Render(hdc);
	player->Render(hdc);

	if (!player->GetIsAlive())
		RestartImage->Render(hdc, player->GetPos()->x - CAMERA->getPosition()->x - 30, player->GetPos()->y - CAMERA->getPosition()->y - 50);

	if (!Start)
		StartImage->Render(hdc);
	
}

void StalkerTest::HitEvent()
{
	enemy->HitEvent(*bullets);
	player->HitEvent(*bullets);
}