#include "GameObject.h"


bool GameObject::Init_Room7()
{

	// 7�� �� ���� �� ��
	obj[48].OBJ_TYPE = OBJ_WALL;
	obj[48].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[48].x = WINSIZEX;
	obj[48].y = WINSIZEY * 3;
	obj[48].width = WALL_SIZE;
	obj[48].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[48].isAlive = true;
	obj[48].isWall = true;
	obj[48].isItem = false;
	obj[48].rcObject = RectMake(obj[48].x, obj[48].y, obj[48].width, obj[48].height);

	// 7�� �� ���� �Ʒ� ��
	obj[49].OBJ_TYPE = OBJ_WALL;
	obj[49].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[49].x = WINSIZEX;
	obj[49].y = WINSIZEY * 3 + (WINSIZEY / 2 + WALL_SIZE / 2);
	obj[49].width = WALL_SIZE;
	obj[49].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[49].isAlive = true;
	obj[49].isWall = true;
	obj[49].isItem = false;
	obj[49].rcObject = RectMake(obj[49].x, obj[49].y, obj[49].width, obj[49].height);

	// 7�� �� ���� ��
	obj[50].OBJ_TYPE = OBJ_DOOR;
	obj[50].image = IMAGEMANAGER->FindImage(TEXT("Door"));
	obj[50].x = WINSIZEX;
	obj[50].y = WINSIZEY * 3 + (WINSIZEY / 2 - WALL_SIZE / 2);
	obj[50].width = WALL_SIZE;
	obj[50].height = WALL_SIZE;
	obj[50].isAlive = true;
	obj[50].isWall = true;
	obj[50].isItem = false;
	obj[50].rcObject = RectMake(obj[50].x, obj[50].y, obj[50].width, obj[50].height);

	// 7�� �� �� ���� ��
	obj[51].OBJ_TYPE = OBJ_WALL;
	obj[51].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[51].x = WINSIZEX;
	obj[51].y = WINSIZEY * 3;
	obj[51].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[51].height = WALL_SIZE;
	obj[51].isAlive = true;
	obj[51].isWall = true;
	obj[51].isItem = false;
	obj[51].rcObject = RectMake(obj[51].x, obj[51].y, obj[51].width, obj[51].height);

	// 7�� �� �� ������ ��
	obj[52].OBJ_TYPE = OBJ_WALL;
	obj[52].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[52].x = WINSIZEX + (WINSIZEX / 2 + WALL_SIZE / 2);
	obj[52].y = WINSIZEY * 3;
	obj[52].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[52].height = WALL_SIZE;
	obj[52].isAlive = true;
	obj[52].isWall = true;
	obj[52].isItem = false;
	obj[52].rcObject = RectMake(obj[52].x, obj[52].y, obj[52].width, obj[52].height);

	// 7�� �� ���� ��
	obj[53].OBJ_TYPE = OBJ_DOOR;
	obj[53].image = IMAGEMANAGER->FindImage(TEXT("Door"));
	obj[53].x = WINSIZEX + (WINSIZEX / 2 - WALL_SIZE / 2);
	obj[53].y = WINSIZEY * 3;
	obj[53].width = WALL_SIZE;
	obj[53].height = WALL_SIZE;
	obj[53].isAlive = false;
	obj[53].isWall = true;
	obj[53].isItem = false;
	obj[53].rcObject = RectMake(obj[53].x, obj[53].y, obj[53].width, obj[53].height);

	// 7�� �� �Ʒ��� ��
	obj[54].OBJ_TYPE = OBJ_WALL;
	obj[54].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[54].x = WINSIZEX;
	obj[54].y = WINSIZEY * 4 - WALL_SIZE;
	obj[54].width = WINSIZEX;
	obj[54].height = WALL_SIZE;
	obj[54].isAlive = true;
	obj[54].isWall = true;
	obj[54].isItem = false;
	obj[54].rcObject = RectMake(obj[54].x, obj[54].y, obj[54].width, obj[54].height);

	// 7�� �� ������ ��
	obj[55].OBJ_TYPE = OBJ_WALL;
	obj[55].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[55].x = WINSIZEX * 2 - WALL_SIZE;
	obj[55].y = WINSIZEY * 3;
	obj[55].width = WALL_SIZE;
	obj[55].height = WINSIZEY;
	obj[55].isAlive = true;
	obj[55].isWall = true;
	obj[55].isItem = false;
	obj[55].rcObject = RectMake(obj[55].x, obj[55].y, obj[55].width, obj[55].height);


	return true;
}