#include "GameObject.h"


bool GameObject::Init_Room6()
{
	// 6�� �� ���� �� ��
	obj[40].OBJ_TYPE = OBJ_WALL;
	obj[40].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[40].x = WINSIZEX;
	obj[40].y = WINSIZEY * 2;
	obj[40].width = WALL_SIZE;
	obj[40].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[40].isAlive = true;
	obj[40].isWall = true;
	obj[40].isItem = false;
	obj[40].rcObject = RectMake(obj[40].x, obj[40].y, obj[40].width, obj[40].height);

	// 6�� �� ���� �Ʒ� ��
	obj[41].OBJ_TYPE = OBJ_WALL;
	obj[41].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[41].x = WINSIZEX;
	obj[41].y = WINSIZEY * 2 + (WINSIZEY / 2 + WALL_SIZE / 2);
	obj[41].width = WALL_SIZE;
	obj[41].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[41].isAlive = true;
	obj[41].isWall = true;
	obj[41].isItem = false;
	obj[41].rcObject = RectMake(obj[41].x, obj[41].y, obj[41].width, obj[41].height);

	// 6�� �� ���� ��
	obj[42].OBJ_TYPE = OBJ_DOOR;
	obj[42].image = IMAGEMANAGER->FindImage(TEXT("Door"));
	obj[42].x = WINSIZEX;
	obj[42].y = WINSIZEY * 2 + (WINSIZEY / 2 - WALL_SIZE / 2);
	obj[42].width = WALL_SIZE;
	obj[42].height = WALL_SIZE;
	obj[42].isAlive = false;
	obj[42].isWall = true;
	obj[42].isItem = false;
	obj[42].rcObject = RectMake(obj[42].x, obj[42].y, obj[42].width, obj[42].height);

	// 6�� �� ���� ��
	obj[43].OBJ_TYPE = OBJ_WALL;
	obj[43].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[43].x = WINSIZEX;
	obj[43].y = WINSIZEY * 2;
	obj[43].width = WINSIZEX;
	obj[43].height = WALL_SIZE;
	obj[43].isAlive = true;
	obj[43].isWall = true;
	obj[43].isItem = false;
	obj[43].rcObject = RectMake(obj[43].x, obj[43].y, obj[43].width, obj[43].height);

	// 6�� �� �Ʒ� ���� ��
	obj[44].OBJ_TYPE = OBJ_WALL;
	obj[44].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[44].x = WINSIZEX;
	obj[44].y = WINSIZEY * 3 - WALL_SIZE;
	obj[44].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[44].height = WALL_SIZE;
	obj[44].isAlive = true;
	obj[44].isWall = true;
	obj[44].isItem = false;
	obj[44].rcObject = RectMake(obj[44].x, obj[44].y, obj[44].width, obj[44].height);

	// 6�� �� �Ʒ� ������ ��
	obj[45].OBJ_TYPE = OBJ_WALL;
	obj[45].image = IMAGEMANAGER->FindImage(TEXT("WidthOutWall"));
	obj[45].x = WINSIZEX + (WINSIZEX / 2 + WALL_SIZE / 2);
	obj[45].y = WINSIZEY * 3 - WALL_SIZE;
	obj[45].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[45].height = WALL_SIZE;
	obj[45].isAlive = true;
	obj[45].isWall = true;
	obj[45].isItem = false;
	obj[45].rcObject = RectMake(obj[45].x, obj[45].y, obj[45].width, obj[45].height);

	// 6�� �� �Ʒ� ��
	obj[46].OBJ_TYPE = OBJ_DOOR;
	obj[46].image = IMAGEMANAGER->FindImage(TEXT("Door"));
	obj[46].x = WINSIZEX + (WINSIZEX / 2 - WALL_SIZE / 2);
	obj[46].y = WINSIZEY * 3 - WALL_SIZE;
	obj[46].width = WALL_SIZE;
	obj[46].height = WALL_SIZE;
	obj[46].isAlive = true;
	obj[46].isWall = true;
	obj[46].isItem = false;
	obj[46].rcObject = RectMake(obj[46].x, obj[46].y, obj[46].width, obj[46].height);

	// 6�� �� ������ ��
	obj[47].OBJ_TYPE = OBJ_WALL;
	obj[47].image = IMAGEMANAGER->FindImage(TEXT("HeightOutWall"));
	obj[47].x = WINSIZEX * 2 - WALL_SIZE;
	obj[47].y = WINSIZEY * 2;
	obj[47].width = WALL_SIZE;
	obj[47].height = WINSIZEY;
	obj[47].isAlive = true;
	obj[47].isWall = true;
	obj[47].isItem = false;
	obj[47].rcObject = RectMake(obj[47].x, obj[47].y, obj[47].width, obj[47].height);



	// 6�� �� ��ֹ� 1
	obj[78].OBJ_TYPE = OBJ_STONE;
	obj[78].image = IMAGEMANAGER->FindImage(TEXT("Stone"));
	obj[78].x = WINSIZEX + (WINSIZEX / 8) - (WALL_SIZE / 2);
	obj[78].y = (WINSIZEY * 2) + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[78].width = WALL_SIZE;
	obj[78].height = WALL_SIZE;
	obj[78].isAlive = true;
	obj[78].isWall = true;
	obj[78].isItem = false;
	obj[78].rcObject = RectMake(obj[78].x, obj[78].y, obj[78].width, obj[78].height);

	// 6�� �� ��ֹ� 2
	obj[79].OBJ_TYPE = OBJ_STONE;
	obj[79].image = IMAGEMANAGER->FindImage(TEXT("Stone"));
	obj[79].x = WINSIZEX + (WINSIZEX / 8 * 2) - (WALL_SIZE / 2);
	obj[79].y = (WINSIZEY * 2) + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[79].width = WALL_SIZE;
	obj[79].height = WALL_SIZE;
	obj[79].isAlive = true;
	obj[79].isWall = true;
	obj[79].isItem = false;
	obj[79].rcObject = RectMake(obj[79].x, obj[79].y, obj[79].width, obj[79].height);

	// 6�� �� ��ֹ� 3
	obj[80].OBJ_TYPE = OBJ_STONE;
	obj[80].image = IMAGEMANAGER->FindImage(TEXT("Stone"));
	obj[80].x = WINSIZEX + (WINSIZEX / 8 * 3) - (WALL_SIZE / 2);
	obj[80].y = (WINSIZEY * 2) + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[80].width = WALL_SIZE;
	obj[80].height = WALL_SIZE;
	obj[80].isAlive = true;
	obj[80].isWall = true;
	obj[80].isItem = false;
	obj[80].rcObject = RectMake(obj[80].x, obj[80].y, obj[80].width, obj[80].height);

	// 6�� �� ��ֹ� 4
	obj[81].OBJ_TYPE = OBJ_STONE;
	obj[81].image = IMAGEMANAGER->FindImage(TEXT("Stone"));
	obj[81].x = WINSIZEX + (WINSIZEX / 8 * 4) - (WALL_SIZE / 2);
	obj[81].y = (WINSIZEY * 2) + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[81].width = WALL_SIZE;
	obj[81].height = WALL_SIZE;
	obj[81].isAlive = true;
	obj[81].isWall = true;
	obj[81].isItem = false;
	obj[81].rcObject = RectMake(obj[81].x, obj[81].y, obj[81].width, obj[81].height);

	// 6�� �� ��ֹ� 5
	obj[82].OBJ_TYPE = OBJ_STONE;
	obj[82].image = IMAGEMANAGER->FindImage(TEXT("Stone"));
	obj[82].x = WINSIZEX + (WINSIZEX / 8 * 5) - (WALL_SIZE / 2);
	obj[82].y = (WINSIZEY * 2) + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[82].width = WALL_SIZE;
	obj[82].height = WALL_SIZE;
	obj[82].isAlive = true;
	obj[82].isWall = true;
	obj[82].isItem = false;
	obj[82].rcObject = RectMake(obj[82].x, obj[82].y, obj[82].width, obj[82].height);

	// 6�� �� ��ֹ� 6
	obj[83].OBJ_TYPE = OBJ_STONE;
	obj[83].image = IMAGEMANAGER->FindImage(TEXT("Stone"));
	obj[83].x = WINSIZEX + (WINSIZEX / 8 * 6) - (WALL_SIZE / 2);
	obj[83].y = (WINSIZEY * 2) + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[83].width = WALL_SIZE;
	obj[83].height = WALL_SIZE;
	obj[83].isAlive = true;
	obj[83].isWall = true;
	obj[83].isItem = false;
	obj[83].rcObject = RectMake(obj[83].x, obj[83].y, obj[83].width, obj[83].height);

	// 6�� �� ��ֹ� 7
	obj[84].OBJ_TYPE = OBJ_STONE;
	obj[84].image = IMAGEMANAGER->FindImage(TEXT("Stone"));
	obj[84].x = WINSIZEX + (WINSIZEX / 8 * 7) - (WALL_SIZE / 2);
	obj[84].y = (WINSIZEY * 2) + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[84].width = WALL_SIZE;
	obj[84].height = WALL_SIZE;
	obj[84].isAlive = true;
	obj[84].isWall = true;
	obj[84].isItem = false;
	obj[84].rcObject = RectMake(obj[84].x, obj[84].y, obj[84].width, obj[84].height);

	// 6�� �� ��ֹ� 8
	obj[85].OBJ_TYPE = OBJ_STONE;
	obj[85].image = IMAGEMANAGER->FindImage(TEXT("WidthWall"));
	obj[85].x = WINSIZEX + (WINSIZEX / 3) - (WALL_SIZE / 2);
	obj[85].y = (WINSIZEY * 2) + (WINSIZEY / 4 * 3) - (WALL_SIZE / 2);
	obj[85].width = WINSIZEX / 3 + WALL_SIZE / 2;
	obj[85].height = WALL_SIZE;
	obj[85].isAlive = true;
	obj[85].isWall = true;
	obj[85].isItem = false;
	obj[85].rcObject = RectMake(obj[85].x, obj[85].y, obj[85].width, obj[85].height);


	// 6���� ȸ�� ������ 1
	obj[90].image = IMAGEMANAGER->AddFrameImage(TEXT("HealthPack"), TEXT("Image/HealthPack.bmp"), 42, 30, 1, 1, true, RGB(0, 255, 0));
	obj[90].x = WINSIZEX * 2 - (WALL_SIZE + ITEM_WIDTH) - ITEM_WIDTH / 2;	// ��ġ X
	obj[90].y = WINSIZEY / 2 - ITEM_HEIGHT / 2 + WINSIZEY * 2;								// ��ġ Y
	obj[90].width = ITEM_WIDTH;									// ��
	obj[90].height = ITEM_HEIGHT;								// ����
	obj[90].isAlive = true;										// ��������
	obj[90].isWall = false;										// ���ΰ�?
	obj[90].isItem = true;										// �������ΰ�?
	obj[90].dir = DIRECTION::DIR_NONE;							// ��������ΰ�?
	obj[90].rcObject = RectMakeCenter(obj[90].x, obj[90].y, obj[90].width, obj[90].height);

	return true;
}