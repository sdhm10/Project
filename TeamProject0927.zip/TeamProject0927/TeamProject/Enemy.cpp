
#include "Enemy.h"

Enemy::Enemy()
{
}


Enemy::~Enemy()
{
}

bool Enemy::Init()
{

	IMAGEMANAGER->AddFrameImage(TEXT("Boss"), TEXT("Image/Boss.bmp"), 200, 210, 4, 3, true, RGB(0, 255, 0));
	IMAGEMANAGER->AddFrameImage(TEXT("Homing"), TEXT("Image/Homing.bmp"), 200, 160, 5, 2, true, RGB(0, 255, 0));
	IMAGEMANAGER->AddFrameImage(TEXT("Shooting"), TEXT("Image/Shooting.bmp"), 200, 240, 4, 5, true, RGB(0, 255, 0));
	IMAGEMANAGER->AddFrameImage(TEXT("Turret"), TEXT("Image/Turret.bmp"), 224, 128, 6, 2, true, RGB(0, 255, 0));


	for (int i = 0; i < MAX_MONSTER; i++)
	{
		_Monster[i].angle		= PI + (PI / 2.f);
		_Monster[i].posX		= (float)(i % 10) * 100.f;
		_Monster[i].posY		= 50.f;				
		_Monster[i].endX		= _Monster[i].posX;
		_Monster[i].endY		= _Monster[i].posY;
		_Monster[i].CameraPos.x		= (LONG)_Monster[i].posX;		
		_Monster[i].CameraPos.y		= (LONG)_Monster[i].posY;				
		_Monster[i].length		= 0.f;
		_Monster[i].radius		= 10;
		_Monster[i].realizeRange = 0.f;				
		_Monster[i].hp			= 3;
		_Monster[i].isAlive		= true;
		_Monster[i].speed		= 1;
		_Monster[i].state		= STATE_IDLE;
		_Monster[i].monDir		= DIR_DOWN;
		_Monster[i].isPlayer	= false;
		_Monster[i].ani			= new Animation;

	}

	Init_Enemy_Room2();
	Init_Enemy_Room3();
	Init_Enemy_Room4();
	Init_Enemy_Room5();
	Init_Enemy_Room6();
	Init_Enemy_Room7();

	for (int i = 0; i < MAX_MONSTER; i++)
	{
		_Monster[i].ani->Init(_Monster[i].image);
		_Monster[i].ani->setFPS(1);
		_Monster[i].TickCount = 0;
	}

	return true;
}

void Enemy::Release()
{
	for (int i = 0; i < MAX_MONSTER; i++)
	{
		SAFE_DELETE(_Monster[i].ani);
	}
	IMAGEMANAGER->DeleteImage("Boss");
	IMAGEMANAGER->DeleteImage("Turret");
	IMAGEMANAGER->DeleteImage("Shooting");
	IMAGEMANAGER->DeleteImage("Homing");
	IMAGEMANAGER->DeleteImage("UIhpbar");
}

void Enemy::Update(Bullets& inputBullets, Player& inputPlayer)
{
	_BossTickCount++;
	EnemyMove(inputBullets, inputPlayer);
	

	for (int i = 0; i < MAX_MONSTER; i++)
	{

		if (!_Monster[i].ani->isPlay())	
		{
			if (_Monster[i].state != STATE_DEAD)
			{
				_Monster[i].ani->start();
				_Monster[i].state = STATE_IDLE;
			}

		}
		_Monster[i].ani->frameUpdate(TIMEMANAGER->getElapsedTime() * 6);
	}
}



void Enemy::Render(HDC hdc)
{
	HBRUSH brush = CreateSolidBrush(RGB(255, 0, 0));
	HBRUSH oldbrush = (HBRUSH)SelectObject(hdc, brush);
	for (int i = 0; i < MAX_MONSTER; i++)
	{
		_Monster[i].image->AniRender(hdc, _Monster[i].posX - CAMERA->getPosition()->x, _Monster[i].posY - CAMERA->getPosition()->y, _Monster[i].ani);
	}

	if (_Monster[35].isAlive)
	{
		SelectObject(hdc, brush);
		Rectangle(hdc, _HPbar.left - CAMERA->getPosition()->x, _HPbar.top - CAMERA->getPosition()->y, _HPbar.right - CAMERA->getPosition()->x, _HPbar.bottom - CAMERA->getPosition()->y);
		SelectObject(hdc, oldbrush);
		DeleteObject(brush);

		HPImage->Render(hdc, (WINSIZEX / 2) + WINSIZEX - 180 - CAMERA->getPosition()->x, (WINSIZEY * 3) + 30 - CAMERA->getPosition()->y);
	}
}

void Enemy::HitEvent(Bullets & inputBullets)
{
	for (int i = 0; i < MAX_MONSTER ; i++)
	{
		if (!_Monster[i].isAlive)
			continue;

		if (inputBullets.HitCollision(_Monster[i].posX + _Monster[i].checkRealPos, _Monster[i].posY + _Monster[i].checkRealPos, _Monster[i].radius, _Monster[i].isPlayer, _Monster[i].isAlive)
			&& _Monster[i].isAlive
			&& !_Monster[i].isPlayer)
		{	
			_Monster[i].hp--;	

			if (_Monster[i].type == TYPE_BOSS)
			{
				_HPbar.right -= 7;
			}

			if (_Monster[i].hp <= 0)
			{
				_Monster[i].state = STATE_DEAD;
				_Monster[i].isAlive = false;
			}
		}
	}
}

void Enemy::EnemyMove(Bullets& inputBullets, Player& inputPlayer)
{
	for (int i = 0; i < MAX_MONSTER; i++)
	{
		_Monster[i].TickCount++;

		if (_Monster[i].type == MONSTERTYPE::TYPE_HOMING)
		{
			HomingMove(_Monster[i], inputBullets, inputPlayer);
			
			if (_Monster[i].isAlive == true)
			{
				_Monster[i].ani->setPlayFrame(0, 4, false, true);
			}
			else if(_Monster[i].isAlive == false)
			{
				_Monster[i].ani->setPlayFrame(5, 9, false, false);
			}
		}
		if (_Monster[i].type == MONSTERTYPE::TYPE_SHOOT)
		{
			ShootingMove(_Monster[i], inputBullets, inputPlayer);

			if (_Monster[i].isAlive == true)
			{
				_Monster[i].ani->setPlayFrame(1, 4, false, true);
			}
			else if (_Monster[i].isAlive == false)
			{
				_Monster[i].ani->setPlayFrame(17, 20, false, false);
			}
		}
		if (_Monster[i].type == MONSTERTYPE::TYPE_TURRET)
		{
			TurretMove(_Monster[i], inputBullets, inputPlayer);

			if (_Monster[i].isAlive == true)
			{
				_Monster[i].ani->setPlayFrame(1, 6, false, true);
			}
			else if (_Monster[i].isAlive == false)
			{
				_Monster[i].ani->setPlayFrame(7, 12, false, false);
			}
		}
		if (_Monster[i].type == MONSTERTYPE::TYPE_BOSS)
		{
			BossMove(_Monster[i], inputBullets, inputPlayer);

			if (_Monster[i].isAlive == true)
			{
				_Monster[i].ani->setPlayFrame(1, 8, false, true);
			}
			else if (_Monster[i].isAlive == false)
			{
				_Monster[i].ani->setPlayFrame(5, 12, false, false);
			}
		}
	}

}

void Enemy::HomingMove(Monster& inputMonster, Bullets& inputBullets, Player& inputPlayer)
{	
	if (!inputMonster.isAlive)
	{
		return;
	}

	if (!CollisionCircleAndCircle(inputMonster.realizeRange, inputMonster.posX, inputMonster.posY,
		inputPlayer.GetRadius(), inputPlayer.GetX(), inputPlayer.GetY()))
	{
		return;
	}

	inputMonster.angle = UTIL::getAngle(inputMonster.posX, inputMonster.posY, inputPlayer.GetX() + (cosf(inputPlayer.GetAngle()) * 1.1f), inputPlayer.GetY() + (-sinf(inputPlayer.GetAngle()) *1.1f));
	inputMonster.posX += cosf(inputMonster.angle) * inputMonster.speed;
	inputMonster.posY += -sinf(inputMonster.angle) * inputMonster.speed;
	inputMonster.CameraPos.x = (LONG)inputMonster.posX;	
	inputMonster.CameraPos.y = (LONG)inputMonster.posY;	
	inputMonster.endX = inputMonster.posX + cosf(inputMonster.angle) * 25.f;
	inputMonster.endY = inputMonster.posY + (-sinf(inputMonster.angle)) * 25.f;

	inputMonster.rcMonster = RectMakeCenter(inputMonster.posX + inputMonster.checkRealPos, inputMonster.posY + inputMonster.checkRealPos, inputMonster.radius * 2, inputMonster.radius * 2);

	EnemyFire(inputMonster, inputBullets);

}

void Enemy::ShootingMove(Monster& inputMonster, Bullets& inputBullets, Player& inputPlayer)
{
	if (!inputMonster.isAlive)
	{
		return;
	}

	if (!CollisionCircleAndCircle(inputMonster.realizeRange, inputMonster.posX, inputMonster.posY,
		inputPlayer.GetRadius(), inputPlayer.GetX(), inputPlayer.GetY()))
	{
		return;
	}
	
	inputMonster.angle = UTIL::getAngle(inputMonster.posX, inputMonster.posY, inputPlayer.GetX() + (cosf(inputPlayer.GetAngle()) * 1.1f), inputPlayer.GetY() + (-sinf(inputPlayer.GetAngle()) *1.1f));
	float result = (inputPlayer.GetX() - inputMonster.posX)*(inputPlayer.GetX() - inputMonster.posX) + (inputPlayer.GetY() - inputMonster.posY)*(inputPlayer.GetY() - inputMonster.posY);
	if (sqrt(result) < inputMonster.realizeRange/2)
	{
		EnemyFire(inputMonster, inputBullets);
	}
	else
	{
		inputMonster.posX += cosf(inputMonster.angle) * inputMonster.speed;
		inputMonster.posY += -sinf(inputMonster.angle) * inputMonster.speed;
		inputMonster.CameraPos.x = (LONG)inputMonster.posX;		// ī�޶� ������ X
		inputMonster.CameraPos.y = (LONG)inputMonster.posY;		// ī�޶� ������ Y
		inputMonster.endX = inputMonster.posX + cosf(inputMonster.angle) * 25.f;
		inputMonster.endY = inputMonster.posY + (-sinf(inputMonster.angle)) * 25.f;

		inputMonster.rcMonster = RectMakeCenter(inputMonster.posX + inputMonster.checkRealPos, inputMonster.posY + inputMonster.checkRealPos, inputMonster.radius * 2, inputMonster.radius * 2);
	}

}

void Enemy::TurretMove(Monster& inputMonster, Bullets& inputBullets, Player& inputPlayer)
{
	if (!inputMonster.isAlive)
	{
		return;
	}

	if (!CollisionCircleAndCircle(inputMonster.realizeRange, inputMonster.posX, inputMonster.posY,
		inputPlayer.GetRadius(), inputPlayer.GetX(), inputPlayer.GetY()))
	{
		return;
	}

	inputMonster.angle = UTIL::getAngle(inputMonster.posX, inputMonster.posY, inputPlayer.GetX() + (cosf(inputPlayer.GetAngle()) * 1.1f), inputPlayer.GetY() + (-sinf(inputPlayer.GetAngle()) *1.1f));
	inputMonster.CameraPos.x = (LONG)inputMonster.posX;		// ī�޶� ������ X
	inputMonster.CameraPos.y = (LONG)inputMonster.posY;		// ī�޶� ������ Y
	inputMonster.endX = inputMonster.posX + cosf(inputMonster.angle) * 25.f;
	inputMonster.endY = inputMonster.posY + (-sinf(inputMonster.angle)) * 25.f;

	inputMonster.rcMonster = RectMakeCenter(inputMonster.posX + inputMonster.checkRealPos, inputMonster.posY + inputMonster.checkRealPos, inputMonster.radius * 2, inputMonster.radius * 2);

	EnemyFire(inputMonster, inputBullets);
}


void Enemy::BossMove(Monster& inputMonster, Bullets& inputBullets, Player& inputPlayer)
{
	if (!inputMonster.isAlive)
	{
		return;
	}

	if (!CollisionCircleAndCircle(inputMonster.realizeRange, inputMonster.posX, inputMonster.posY,
		inputPlayer.GetRadius(), inputPlayer.GetX(), inputPlayer.GetY()))
	{

		return;
	}

	inputMonster.CameraPos.x = (LONG)inputMonster.posX;		// ī�޶� ������ X
	inputMonster.CameraPos.y = (LONG)inputMonster.posY;		// ī�޶� ������ Y

	inputMonster.rcMonster = RectMakeCenter(inputMonster.posX + inputMonster.checkRealPos, inputMonster.posY + inputMonster.checkRealPos, inputMonster.radius * 2, inputMonster.radius * 2);
	
	if (inputMonster.hp <= 40 && inputMonster.hp > 30)
	{
		_Bossphasenum = 2;
	}
	if (inputMonster.hp <= 30)
	{
		_Bossphasenum = 3;
	}

	if(inputMonster.TickCount >= PATTERNTIME)
	{
		inputMonster.TickCount = 0;

		_BossPattern = RAND->getFromIntTo(1, 3);
		if (_BossPattern == 1)
			BossPattern1(inputMonster, inputBullets, _Bossphasenum);
		if (_BossPattern == 2)
			BossPattern2(inputMonster, inputBullets, _Bossphasenum);
		if (_BossPattern == 3)
			BossPattern3(inputMonster, inputBullets, _Bossphasenum);


	}
	
}

void Enemy::EnemyFire(Monster& inputMonster, Bullets& inputBullets)
{
	if (!inputMonster.isAlive)
	{
		return;
	}

	if (inputMonster.TickCount >= ATTACKTIME)
	{
		inputMonster.TickCount = 0;
		if (inputMonster.type == MONSTERTYPE::TYPE_HOMING)
		{
			inputBullets.BulletFire(inputMonster.endX, inputMonster.endY, inputMonster.angle, inputMonster.length, inputMonster.isPlayer, GUNYTPE::GUNYTPE_RIFLE);
		}
		if (inputMonster.type == MONSTERTYPE::TYPE_SHOOT)
		{
			inputBullets.ShotGunFire(inputMonster.endX, inputMonster.endY, inputMonster.angle, inputMonster.length, inputMonster.isPlayer, GUNYTPE::GUNYTPE_SHOTGUN);
		}
		if (inputMonster.type == MONSTERTYPE::TYPE_TURRET)
		{
			inputBullets.BulletFire(inputMonster.endX, inputMonster.endY, inputMonster.angle, inputMonster.length, inputMonster.isPlayer, GUNYTPE::GUNYTPE_RIFLE);
		}
	}

}

void Enemy::BossPattern1(Monster & boss, Bullets & bullet, int phasenum)
{
	float angle;
	for (int i = 0; i <= 360; i += 60/phasenum)
	{
		angle = PI * i / 180;
		bullet.BulletFire(boss.endX, boss.endY, angle, boss.length, boss.isPlayer, GUNYTPE::GUNYTPE_RIFLE);
	}
}

void Enemy::BossPattern2(Monster & boss, Bullets& bullet, int phasenum)
{
	float angle;
	float length = 0.f;

	for (int i = 1; i <= 360 * phasenum; i += 10)
	{

		angle = PI * i / 180;
		bullet.BossPattern2(boss.posX + boss.checkRealPos, boss.posY + boss.checkRealPos, angle, length, boss.isPlayer);
		length += 2.f;
	}
}

void Enemy::BossPattern3(Monster & boss, Bullets & bullet, int phasenum)
{
	float angle;
	float length = 50.f;
	for (int i = 0; i <= phasenum; i++)
	{
		for (int j = 0; j <= 360; j += 30)
		{
			angle = PI * j / 180;
			bullet.BossPattern3(boss.posX + boss.checkRealPos, boss.posY + boss.checkRealPos, angle, length, boss.isPlayer);
		}

		length += 60.f;
	}
}



bool Enemy::Init_Enemy_Room2()
{
	// 1�� ������
	_Monster[0].type = TYPE_HOMING;
	_Monster[0].realizeRange = 400.f;						// Ž�� ����
	_Monster[0].radius = 14;
	_Monster[0].checkRealPos = 15;
	_Monster[0].image = IMAGEMANAGER->FindImage(TEXT("Homing"));
	_Monster[0].posX = WINSIZEX + (WINSIZEX / 8 * 3);
	_Monster[0].posY = (WINSIZEY / 2) - _Monster[0].radius * 2;
	_Monster[0].endX = _Monster[0].posX;
	_Monster[0].endY = _Monster[0].posY;


	// 1�� ����
	_Monster[1].type = TYPE_SHOOT;
	_Monster[1].radius = 20;
	_Monster[1].realizeRange = 400.f;						// Ž�� ����
	_Monster[1].checkRealPos = 23;
	_Monster[1].image = IMAGEMANAGER->FindImage(TEXT("Shooting"));
	_Monster[1].posX = WINSIZEX + (WINSIZEX / 8*3);
	_Monster[1].posY = (WINSIZEY / 4) - (WALL_SIZE / 2);
	_Monster[1].endX = _Monster[1].posX;
	_Monster[1].endY = _Monster[1].posY;
			 
	// 2�� ����
	_Monster[2].type = TYPE_SHOOT;
	_Monster[2].radius = 20;
	_Monster[2].realizeRange = 400.f;						// Ž�� ����
	_Monster[2].checkRealPos = 23;
	_Monster[2].image = IMAGEMANAGER->FindImage(TEXT("Shooting"));
	_Monster[2].posX = WINSIZEX + (WINSIZEX / 8 * 3);
	_Monster[2].posY = (WINSIZEY / 4*3)- (WALL_SIZE / 2);
	_Monster[2].endX = _Monster[2].posX;
	_Monster[2].endY = _Monster[2].posY;


	// 1�� �ͷ�
	_Monster[3].type = TYPE_TURRET;
	_Monster[3].radius = 20;
	_Monster[3].realizeRange = 1000.f;						// Ž�� ����
	_Monster[3].checkRealPos = 20;
	_Monster[3].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[3].posX = (WINSIZEX * 2) - WALL_SIZE - _Monster[3].radius*2;
	_Monster[3].posY = WALL_SIZE;
	_Monster[3].endX = _Monster[3].posX;
	_Monster[3].endY = _Monster[3].posY;

	// 2�� �ͷ�
	_Monster[4].type = TYPE_TURRET;
	_Monster[4].radius = 20;
	_Monster[4].realizeRange = 1000.f;						// Ž�� ����
	_Monster[4].checkRealPos = 20;
	_Monster[4].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[4].posX = (WINSIZEX * 2) - WALL_SIZE - _Monster[3].radius * 2;
	_Monster[4].posY = WINSIZEY - WALL_SIZE - _Monster[4].radius * 2 - 10.f;
	_Monster[4].endX = _Monster[4].posX;
	_Monster[4].endY = _Monster[4].posY;


	return true;
}

bool Enemy::Init_Enemy_Room3()
{
	// 1�� ������
	_Monster[5].type = TYPE_HOMING;
	_Monster[5].realizeRange = 400.f;						// Ž�� ����
	_Monster[5].radius = 14;
	_Monster[5].checkRealPos = 15;
	_Monster[5].image = IMAGEMANAGER->FindImage(TEXT("Homing"));
	_Monster[5].posX = WINSIZEX + (WINSIZEX / 4 * 3) - (WALL_SIZE / 2);
	_Monster[5].posY = WINSIZEY + (WINSIZEY / 3) - (WALL_SIZE / 2) - _Monster[5].radius * 2;
	_Monster[5].endX = _Monster[5].posX;
	_Monster[5].endY = _Monster[5].posY;


	// 2�� ������
	_Monster[6].type = TYPE_HOMING;
	_Monster[6].realizeRange = 400.f;						// Ž�� ����
	_Monster[6].radius = 14;
	_Monster[6].checkRealPos = 15;
	_Monster[6].image = IMAGEMANAGER->FindImage(TEXT("Homing"));
	_Monster[6].posX = WINSIZEX + WINSIZEX / 2 + (WALL_SIZE / 2);
	_Monster[6].posY = WINSIZEY + (WINSIZEY / 3 * 2);
	_Monster[6].endX = _Monster[6].posX;
	_Monster[6].endY = _Monster[6].posY;


	// 3�� ������
	_Monster[7].type = TYPE_HOMING;
	_Monster[7].realizeRange = 400.f;						// Ž�� ����
	_Monster[7].radius = 14;
	_Monster[7].checkRealPos = 15;
	_Monster[7].image = IMAGEMANAGER->FindImage(TEXT("Homing"));
	_Monster[7].posX = (WINSIZEX * 2) - WALL_SIZE - _Monster[7].radius * 2;
	_Monster[7].posY = WINSIZEY + (WINSIZEY / 3 * 2);
	_Monster[7].endX = _Monster[7].posX;
	_Monster[7].endY = _Monster[7].posY;


	// 1�� ����
	_Monster[8].type = TYPE_SHOOT;
	_Monster[8].radius = 20;
	_Monster[8].realizeRange = 400.f;						// Ž�� ����
	_Monster[8].checkRealPos = 23;
	_Monster[8].image = IMAGEMANAGER->FindImage(TEXT("Shooting"));
	_Monster[8].posX = WINSIZEX + (WINSIZEX / 4) - (WALL_SIZE / 2);
	_Monster[8].posY = WINSIZEY + (WINSIZEY / 3) - (WALL_SIZE / 2) - _Monster[8].radius * 2;
	_Monster[8].endX = _Monster[8].posX;
	_Monster[8].endY = _Monster[8].posY;


	// 1�� �ͷ�
	_Monster[9].type = TYPE_TURRET;
	_Monster[9].radius = 20;
	_Monster[9].realizeRange = 1000.f;						// Ž�� ����
	_Monster[9].checkRealPos = 20;
	_Monster[9].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[9].posX = WINSIZEX + (WINSIZEX / 4) - (WALL_SIZE / 2);
	_Monster[9].posY = WINSIZEY*2 - WALL_SIZE - _Monster[9].radius*2 - 10.f;
	_Monster[9].endX = _Monster[9].posX;
	_Monster[9].endY = _Monster[9].posY;

	return true;
}

bool Enemy::Init_Enemy_Room4()
{
	// 1�� ������
	_Monster[10].type = TYPE_HOMING;
	_Monster[10].realizeRange = 400.f;						// Ž�� ����
	_Monster[10].radius = 14;
	_Monster[10].checkRealPos = 15;
	_Monster[10].image = IMAGEMANAGER->FindImage(TEXT("Homing"));
	_Monster[10].posX = (WINSIZEX / 4) - (WALL_SIZE / 2);
	_Monster[10].posY = WINSIZEY + (WINSIZEY / 8 * 3);
	_Monster[10].endX = _Monster[10].posX;
	_Monster[10].endY = _Monster[10].posY;


	// 2�� ������
	_Monster[11].type = TYPE_HOMING;
	_Monster[11].realizeRange = 400.f;						// Ž�� ����
	_Monster[11].radius = 14;
	_Monster[11].checkRealPos = 15;
	_Monster[11].image = IMAGEMANAGER->FindImage(TEXT("Homing"));
	_Monster[11].posX = (WINSIZEX / 4) - (WALL_SIZE / 2);
	_Monster[11].posY = WINSIZEY + (WINSIZEY / 8 * 5);
	_Monster[11].endX = _Monster[11].posX;
	_Monster[11].endY = _Monster[11].posY;



	// 1�� �ͷ�
	_Monster[12].type = TYPE_TURRET;
	_Monster[12].radius = 20;
	_Monster[12].realizeRange = 1000.f;						// Ž�� ����
	_Monster[12].checkRealPos = 20;
	_Monster[12].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[12].posX = (WINSIZEX / 8*3) - WALL_SIZE - _Monster[12].radius/2;
	_Monster[12].posY = WINSIZEY + (WINSIZEY / 4) - (WALL_SIZE / 2);
	_Monster[12].endX = _Monster[12].posX;
	_Monster[12].endY = _Monster[12].posY;


	// 2�� �ͷ�
	_Monster[13].type = TYPE_TURRET;
	_Monster[13].radius = 20;
	_Monster[13].realizeRange = 1000.f;						// Ž�� ����
	_Monster[13].checkRealPos = 20;
	_Monster[13].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[13].posX = (WINSIZEX / 8 * 5) - (WALL_SIZE / 2) + _Monster[13].radius / 2;
	_Monster[13].posY = WINSIZEY + (WINSIZEY / 2) - (WALL_SIZE / 2);
	_Monster[13].endX = _Monster[13].posX;
	_Monster[13].endY = _Monster[13].posY;

	// 3�� �ͷ�
	_Monster[14].type = TYPE_TURRET;
	_Monster[14].radius = 20;
	_Monster[14].realizeRange = 1000.f;						// Ž�� ����
	_Monster[14].checkRealPos = 20;
	_Monster[14].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[14].posX = (WINSIZEX / 8 * 3) - WALL_SIZE - _Monster[14].radius / 2;
	_Monster[14].posY = WINSIZEY + (WINSIZEY / 4 * 3) - (WALL_SIZE / 2);
	_Monster[14].endX = _Monster[14].posX;
	_Monster[14].endY = _Monster[14].posY;



	return true;
}

bool Enemy::Init_Enemy_Room5()
{
	// 1�� ����
	_Monster[15].type = TYPE_SHOOT;
	_Monster[15].radius = 20;
	_Monster[15].realizeRange = 400.f;						// Ž�� ����
	_Monster[15].checkRealPos = 23;
	_Monster[15].image = IMAGEMANAGER->FindImage(TEXT("Shooting"));
	_Monster[15].posX = WALL_SIZE;
	_Monster[15].posY = WINSIZEY * 2 + WALL_SIZE;
	_Monster[15].endX = _Monster[15].posX;
	_Monster[15].endY = _Monster[15].posY;


	// 2�� ����
	_Monster[16].type = TYPE_SHOOT;
	_Monster[16].radius = 20;
	_Monster[16].realizeRange = 400.f;						// Ž�� ����
	_Monster[16].checkRealPos = 23;
	_Monster[16].image = IMAGEMANAGER->FindImage(TEXT("Shooting"));
	_Monster[16].posX = WINSIZEX - WALL_SIZE - _Monster[16].radius*2;
	_Monster[16].posY = WINSIZEY * 2 + WALL_SIZE;
	_Monster[16].endX = _Monster[16].posX;
	_Monster[16].endY = _Monster[16].posY;

	// 3�� ����
	_Monster[17].type = TYPE_SHOOT;
	_Monster[17].radius = 20;
	_Monster[17].realizeRange = 400.f;						// Ž�� ����
	_Monster[17].checkRealPos = 23;
	_Monster[17].image = IMAGEMANAGER->FindImage(TEXT("Shooting"));
	_Monster[17].posX = WALL_SIZE;
	_Monster[17].posY = WINSIZEY*3 - WALL_SIZE - _Monster[17].radius * 2;
	_Monster[17].endX = _Monster[17].posX;
	_Monster[17].endY = _Monster[17].posY;


	// 4�� ����
	_Monster[18].type = TYPE_SHOOT;
	_Monster[18].radius = 20;
	_Monster[18].realizeRange = 400.f;						// Ž�� ����
	_Monster[18].checkRealPos = 23;
	_Monster[18].image = IMAGEMANAGER->FindImage(TEXT("Shooting"));
	_Monster[18].posX = WINSIZEX - WALL_SIZE - _Monster[18].radius * 2;
	_Monster[18].posY = WINSIZEY * 3 - WALL_SIZE - _Monster[18].radius * 2;
	_Monster[18].endX = _Monster[18].posX;
	_Monster[18].endY = _Monster[18].posY;


	// 1�� �ͷ�
	_Monster[19].type = TYPE_TURRET;
	_Monster[19].radius = 20;
	_Monster[19].realizeRange = 1000.f;						// Ž�� ����
	_Monster[19].checkRealPos = 20;
	_Monster[19].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[19].posX = (WINSIZEX / 2) - (WALL_SIZE / 2);
	_Monster[19].posY = (WINSIZEY * 2) + (WINSIZEY / 4) + (WALL_SIZE/2);
	_Monster[19].endX = _Monster[19].posX;
	_Monster[19].endY = _Monster[19].posY;


	// 2�� �ͷ�
	_Monster[20].type = TYPE_TURRET;
	_Monster[20].radius = 20;
	_Monster[20].realizeRange = 1000.f;						// Ž�� ����
	_Monster[20].checkRealPos = 20;
	_Monster[20].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[20].posX = (WINSIZEX / 4) + (WALL_SIZE / 2);
	_Monster[20].posY = (WINSIZEY * 2) + (WINSIZEY / 2) - (WALL_SIZE / 2);
	_Monster[20].endX = _Monster[20].posX;
	_Monster[20].endY = _Monster[20].posY;

	// 3�� �ͷ�
	_Monster[21].type = TYPE_TURRET;
	_Monster[21].radius = 20;
	_Monster[21].realizeRange = 1000.f;						// Ž�� ����
	_Monster[21].checkRealPos = 20;
	_Monster[21].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[21].posX = (WINSIZEX / 4 * 3) - (WALL_SIZE / 2) - _Monster[21].radius * 2;
	_Monster[21].posY = (WINSIZEY * 2) + (WINSIZEY / 2) - (WALL_SIZE / 2);
	_Monster[21].endX = _Monster[21].posX;
	_Monster[21].endY = _Monster[21].posY;


	// 4�� �ͷ�
	_Monster[22].type = TYPE_TURRET;
	_Monster[22].radius = 20;
	_Monster[22].realizeRange = 1000.f;						// Ž�� ����
	_Monster[22].checkRealPos = 20;
	_Monster[22].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[22].posX = (WINSIZEX / 2) - (WALL_SIZE / 2);
	_Monster[22].posY =	(WINSIZEY * 2) + (WINSIZEY / 4 * 3) - (WALL_SIZE / 2) - _Monster[22].radius*2 - 10.f;
	_Monster[22].endX = _Monster[22].posX;
	_Monster[22].endY = _Monster[22].posY;


	return true;
}

bool Enemy::Init_Enemy_Room6()
{

	// 1�� ����
	_Monster[23].type = TYPE_SHOOT;
	_Monster[23].radius = 20;
	_Monster[23].realizeRange = 400.f;						// Ž�� ����
	_Monster[23].checkRealPos = 23;
	_Monster[23].image = IMAGEMANAGER->FindImage(TEXT("Shooting"));
	_Monster[23].posX = WINSIZEX + WINSIZEX/4 - _Monster[23].radius/2;
	_Monster[23].posY = WINSIZEY * 2 + WINSIZEY / 2 - _Monster[23].radius / 2;
	_Monster[23].endX = _Monster[23].posX;
	_Monster[23].endY = _Monster[23].posY;


	// 2�� ����
	_Monster[24].type = TYPE_SHOOT;
	_Monster[24].radius = 20;
	_Monster[24].realizeRange = 400.f;						// Ž�� ����
	_Monster[24].checkRealPos = 23;
	_Monster[24].image = IMAGEMANAGER->FindImage(TEXT("Shooting"));
	_Monster[24].posX = WINSIZEX + WINSIZEX/4*3 - _Monster[23].radius/2;
	_Monster[24].posY = WINSIZEY * 2 + WINSIZEY / 2 - _Monster[23].radius / 2;
	_Monster[24].endX = _Monster[24].posX;
	_Monster[24].endY = _Monster[24].posY;



	// 1�� �ͷ�
	_Monster[25].type = TYPE_TURRET;
	_Monster[25].radius = 20;
	_Monster[25].realizeRange = 1000.f;						// Ž�� ����
	_Monster[25].checkRealPos = 20;
	_Monster[25].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[25].posX = WINSIZEX + (WINSIZEX / 16 * 3);
	_Monster[25].posY = WINSIZEY * 2 + WALL_SIZE;
	_Monster[25].endX = _Monster[25].posX;
	_Monster[25].endY = _Monster[25].posY;

	// 2�� �ͷ�
	_Monster[26].type = TYPE_TURRET;
	_Monster[26].radius = 20;
	_Monster[26].realizeRange = 1000.f;						// Ž�� ����
	_Monster[26].checkRealPos = 20;
	_Monster[26].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[26].posX = WINSIZEX + (WINSIZEX / 16 * 5);
	_Monster[26].posY = WINSIZEY * 2 + WALL_SIZE;
	_Monster[26].endX = _Monster[26].posX;
	_Monster[26].endY = _Monster[26].posY;

	// 3�� �ͷ�
	_Monster[27].type = TYPE_TURRET;
	_Monster[27].radius = 20;
	_Monster[27].realizeRange = 1000.f;						// Ž�� ����
	_Monster[27].checkRealPos = 20;
	_Monster[27].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[27].posX = WINSIZEX + (WINSIZEX / 16 * 7);
	_Monster[27].posY = WINSIZEY * 2 + WALL_SIZE;
	_Monster[27].endX = _Monster[27].posX;
	_Monster[27].endY = _Monster[27].posY;

	// 4�� �ͷ�
	_Monster[28].type = TYPE_TURRET;
	_Monster[28].radius = 20;
	_Monster[28].realizeRange = 1000.f;						// Ž�� ����
	_Monster[28].checkRealPos = 20;
	_Monster[28].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[28].posX = WINSIZEX + (WINSIZEX / 16 * 9);
	_Monster[28].posY = WINSIZEY * 2 + WALL_SIZE;
	_Monster[28].endX = _Monster[28].posX;
	_Monster[28].endY = _Monster[28].posY;

	// 5�� �ͷ�
	_Monster[29].type = TYPE_TURRET;
	_Monster[29].radius = 20;
	_Monster[29].realizeRange = 1000.f;						// Ž�� ����
	_Monster[29].checkRealPos = 20;
	_Monster[29].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[29].posX = WINSIZEX + (WINSIZEX / 16 * 11);
	_Monster[29].posY = WINSIZEY * 2 + WALL_SIZE;
	_Monster[29].endX = _Monster[29].posX;
	_Monster[29].endY = _Monster[29].posY;

	// 6�� �ͷ�
	_Monster[30].type = TYPE_TURRET;
	_Monster[30].radius = 20;
	_Monster[30].realizeRange = 1000.f;						// Ž�� ����
	_Monster[30].checkRealPos = 20;
	_Monster[30].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[30].posX = WINSIZEX + (WINSIZEX / 16 * 13);
	_Monster[30].posY = WINSIZEY * 2 + WALL_SIZE;
	_Monster[30].endX = _Monster[30].posX;
	_Monster[30].endY = _Monster[30].posY;


	return true;
}


// ������
bool Enemy::Init_Enemy_Room7()
{
	// 1�� �ͷ�
	_Monster[31].type = TYPE_TURRET;
	_Monster[31].radius = 20;
	_Monster[31].realizeRange = 1000.f;						// Ž�� ����
	_Monster[31].checkRealPos = 20;
	_Monster[31].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[31].posX = WINSIZEX + WALL_SIZE;
	_Monster[31].posY = WINSIZEY * 3 + WALL_SIZE;
	_Monster[31].endX = _Monster[31].posX;
	_Monster[31].endY = _Monster[31].posY;

	// 2�� �ͷ�
	_Monster[32].type = TYPE_TURRET;
	_Monster[32].radius = 20;
	_Monster[32].realizeRange = 1000.f;						// Ž�� ����
	_Monster[32].checkRealPos = 20;
	_Monster[32].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[32].posX = WINSIZEX * 2 - WALL_SIZE - _Monster[32].radius * 2;
	_Monster[32].posY = WINSIZEY * 3 + WALL_SIZE;
	_Monster[32].endX = _Monster[32].posX;
	_Monster[32].endY = _Monster[32].posY;

	// 3�� �ͷ�
	_Monster[33].type = TYPE_TURRET;
	_Monster[33].radius = 20;
	_Monster[33].realizeRange = 1000.f;						// Ž�� ����
	_Monster[33].checkRealPos = 20;
	_Monster[33].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[33].posX = WINSIZEX + WALL_SIZE;
	_Monster[33].posY = WINSIZEY * 4 - WALL_SIZE - _Monster[33].radius * 2;
	_Monster[33].endX = _Monster[33].posX;
	_Monster[33].endY = _Monster[33].posY;

	// 4�� �ͷ�
	_Monster[34].type = TYPE_TURRET;
	_Monster[34].radius = 20;
	_Monster[34].realizeRange = 1000.f;						// Ž�� ����
	_Monster[34].checkRealPos = 20;
	_Monster[34].image = IMAGEMANAGER->FindImage(TEXT("Turret"));
	_Monster[34].posX = WINSIZEX * 2 - WALL_SIZE - _Monster[34].radius * 2;
	_Monster[34].posY = WINSIZEY * 4 - WALL_SIZE - _Monster[34].radius * 2;
	_Monster[34].endX = _Monster[34].posX;
	_Monster[34].endY = _Monster[34].posY;


	// ����
	_Monster[35].type = TYPE_BOSS;
	_Monster[35].hp = 50;
	_Monster[35].radius = 23;
	_Monster[35].speed = 3;
	_Monster[35].realizeRange = 600.f;		// Ž�� ����
	_Monster[35].checkRealPos = 25;
	_Monster[35].image = IMAGEMANAGER->FindImage(TEXT("Boss"));
	_Monster[35].posX = WINSIZEX / 2 + WINSIZEX - _Monster[35].radius;
	_Monster[35].posY = (WINSIZEY * 3) + (WINSIZEY / 2) - _Monster[35].radius;
	_Monster[35].endX = _Monster[35].posX;
	_Monster[35].endY = _Monster[35].posY;

	// ���� ���Ͽ�
	_BossTickCount = 0;
	_Bossphasenum = 1;
	// ���� ui
	HPImage = IMAGEMANAGER->AddImage(TEXT("UIhpbar"), TEXT("Image/BossHP.bmp"), 360, 30, true, RGB(0, 255, 0));		// ui�̹��� �ҷ�����
	_HPbar = RectMakeCenter((WINSIZEX / 2) + WINSIZEX, WINSIZEY*3 + 45, 350, 10);		// ü�¹ٿ� �̹��� ���� (�ӽ�), ���� ���� getposition() + ~~ ������ �ٲ���ҵ� (������Ʈ�κ� �߰�)


	return true;
}
