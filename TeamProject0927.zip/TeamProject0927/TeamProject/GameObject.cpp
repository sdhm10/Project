#include "GameObject.h"



GameObject::GameObject()
{
	
}


GameObject::~GameObject()
{
	for (int i = 0; i < MAX_OBJECT; i++)
	{
		SAFE_DELETE(obj[i].image);
	}
}

bool GameObject::Init()
{
	IMAGEMANAGER->AddImage(TEXT("Stone"), TEXT("Image/Stone.bmp"), 50, 50, false, false);
	IMAGEMANAGER->AddImage(TEXT("WidthWall"), TEXT("Image/WidthWall.bmp"), 550, 50, false, false);
	IMAGEMANAGER->AddImage(TEXT("HeightWall"), TEXT("Image/HeightWall.bmp"), 50, 600, false, false);
	IMAGEMANAGER->AddImage(TEXT("WidthOutWall"), TEXT("Image/WidthOutWall.bmp"), 1000, 50, false, false);
	IMAGEMANAGER->AddImage(TEXT("HeightOutWall"), TEXT("Image/HeightOutWall.bmp"), 50, 1000, false, false);
	IMAGEMANAGER->AddImage(TEXT("Door"), TEXT("Image/Door.bmp"), 50, 50, true, RGB(0,255,0));

	for (int i = 0; i < MAX_OBJECT; i++)
	{
		obj[i].image = NULL;
		obj[i].x = 0.f;							// ��ġ X
		obj[i].y = 0.f;							// ��ġ Y
		obj[i].CameraPos.x = obj[i].x;			// ī�޶� ���� X
		obj[i].CameraPos.x = obj[i].y;			// ī�޶� ���� Y
		obj[i].width = 0.f;						// ��
		obj[i].height = 0.f;					// ����
		obj[i].isAlive = false;					// ��������
		obj[i].isWall = false;					// ���ΰ�?
		obj[i].isItem = false;					// �������ΰ�?
		obj[i].dir = DIRECTION::DIR_NONE;		// ��������ΰ�?
		obj[i].rcObject = RectMake(obj[i].x, obj[i].y, obj[i].width, obj[i].height);
	}

	// ������Ʈ 2 ~ 61�� �� �ܺ�
	Init_Room1();			// 1����
	Init_Room2();			// 2����
	Init_Room3();			// 3����
	Init_Room4();			// 4����
	Init_Room5();			// 5����
	Init_Room6();			// 6����
	Init_Room7();			// 7����
	Init_Room8();			// 8����


	return true;
}

void GameObject::Release()
{

}

void GameObject::Update(Bullets & inputBullets, Player & inputPlayer, Enemy & inputEnemy)
{
	HitEvent(inputBullets, inputPlayer, inputEnemy);


	DoorOpenEvent(inputEnemy, 0, 4, 10, 14);		// 2����
	DoorOpenEvent(inputEnemy, 5, 9, 18, 21);		// 3����
	DoorOpenEvent(inputEnemy, 10, 14, 28, 31);		// 4����
	DoorOpenEvent(inputEnemy, 15, 22, 35, 39);		// 5����
	DoorOpenEvent(inputEnemy, 23, 30, 42, 46);		// 6����

	DoorOpenEvent(inputEnemy, 31, 35, 50, 53);				// 7��(���� ��)
	DoorCloseEvent(inputEnemy, inputPlayer, 35, 50, 53);	// ���� ������ ���� �ݴ´�.
}

void GameObject::Render(HDC hdc)
{
	for (int i = 0; i < MAX_OBJECT; i++)
	{
		if (!obj[i].isAlive)
			continue;

		if (obj[i].isItem)
			obj[i].image->FrameRender(hdc, obj[i].x - obj[i].width/2 - CAMERA->getPosition()->x, obj[i].y - obj[i].height/2 - CAMERA->getPosition()->y);
		if (obj[i].OBJ_TYPE == OBJ_DOOR)
			obj[i].image->Render(hdc, obj[i].x - CAMERA->getPosition()->x, obj[i].y - CAMERA->getPosition()->y, 0, 0, obj[i].width, obj[i].height);
		if (obj[i].OBJ_TYPE == OBJ_STONE)
			obj[i].image->Render(hdc, obj[i].x - CAMERA->getPosition()->x, obj[i].y - CAMERA->getPosition()->y, 0, 0, obj[i].width, obj[i].height);
		if (obj[i].OBJ_TYPE == OBJ_WALL)
			obj[i].image->Render(hdc, obj[i].x - CAMERA->getPosition()->x, obj[i].y - CAMERA->getPosition()->y, 0, 0, obj[i].width, obj[i].height);

	}
}




void GameObject::HitEvent(Bullets & inputBullets, Player & inputPlayer, Enemy & inputEnemy)
{
	HitBullets(inputBullets);
	HitPlayerEnemy(inputPlayer, inputEnemy);
	HitItem(inputPlayer);
}

void GameObject::HitBullets(Bullets & inputBullets)
{
	for (int i = 0; i < MAX_OBJECT; i++)
	{
		if (!obj[i].isAlive)
			continue;

		if (obj[i].isWall)
		{
			inputBullets.HitCollisionRect(obj[i].rcObject, true, obj[i].isAlive);
			inputBullets.HitCollisionRect(obj[i].rcObject, false, obj[i].isAlive);
		}
	}
}

void GameObject::HitPlayerEnemy(Player & inputPlayer, Enemy & inputEnemy)
{
	for (int i = 0; i < MAX_OBJECT; i++)
	{
		if (!obj[i].isAlive)
			continue;

		if (!obj[i].isWall)
			continue;
		if (CollisionRectAndRect(inputPlayer.CollisionRECT(), obj[i].rcObject))
		{
			int result = HitTest(inputPlayer.CollisionRECT(), obj[i].rcObject);

			if ((inputPlayer.CollisionRECT().left < obj[i].rcObject.left) && (inputPlayer.CollisionRECT().right > obj[i].rcObject.left) && result == 1)
			{
				inputPlayer.SetX(obj[i].rcObject.left - inputPlayer.GetRadius());
			}
			if ((inputPlayer.CollisionRECT().left < obj[i].rcObject.right) && (inputPlayer.CollisionRECT().right > obj[i].rcObject.right) && result == 1)
			{
				inputPlayer.SetX(obj[i].rcObject.right + inputPlayer.GetRadius());
			}
			if ((inputPlayer.CollisionRECT().top < obj[i].rcObject.top) && (inputPlayer.CollisionRECT().bottom > obj[i].rcObject.top) && result == 2)
			{
				inputPlayer.SetY(obj[i].rcObject.top - inputPlayer.GetRadius());
			}

			if ((inputPlayer.CollisionRECT().top < obj[i].rcObject.bottom) && (inputPlayer.CollisionRECT().bottom > obj[i].rcObject.bottom) && result == 2)
			{
				inputPlayer.SetY(obj[i].rcObject.bottom + inputPlayer.GetRadius());
			}
		}


		for (int EnemyIndex = 0; EnemyIndex < MAX_MONSTER; EnemyIndex++)
		{
			if (CollisionRectAndRect(inputEnemy.CollisionRECT(EnemyIndex), obj[i].rcObject))
			{
				int result = HitTest(inputEnemy.CollisionRECT(EnemyIndex), obj[i].rcObject);
				if ((inputEnemy.CollisionRECT(EnemyIndex).left < obj[i].rcObject.left) && (inputEnemy.CollisionRECT(EnemyIndex).right > obj[i].rcObject.left) && result == 1)
				{
					inputEnemy.SetX(EnemyIndex, (obj[i].rcObject.left - inputEnemy.GetRadius(EnemyIndex) - inputEnemy.GetCheckRealPos(EnemyIndex)));
				}
				if ((inputEnemy.CollisionRECT(EnemyIndex).left < obj[i].rcObject.right) && (inputEnemy.CollisionRECT(EnemyIndex).right > obj[i].rcObject.right) && result == 1)
				{
					inputEnemy.SetX(EnemyIndex, (obj[i].rcObject.right + inputEnemy.GetRadius(EnemyIndex) - inputEnemy.GetCheckRealPos(EnemyIndex)));
				}
				if ((inputEnemy.CollisionRECT(EnemyIndex).top < obj[i].rcObject.top) && (inputEnemy.CollisionRECT(EnemyIndex).bottom > obj[i].rcObject.top) && result == 2)
				{
					inputEnemy.SetY(EnemyIndex, (obj[i].rcObject.top - inputEnemy.GetRadius(EnemyIndex) - inputEnemy.GetCheckRealPos(EnemyIndex)));
				}

				if ((inputEnemy.CollisionRECT(EnemyIndex).top < obj[i].rcObject.bottom) && (inputEnemy.CollisionRECT(EnemyIndex).bottom > obj[i].rcObject.bottom) && result == 2)
				{
					inputEnemy.SetY(EnemyIndex, (obj[i].rcObject.bottom + inputEnemy.GetRadius(EnemyIndex) - inputEnemy.GetCheckRealPos(EnemyIndex)));
				}
			}
		}
	}
}

bool GameObject::HitItem(Player & inputPlayer)
{
	for (int i = 0; i < MAX_OBJECT; i++)
	{
		if (!obj[i].isAlive)
			continue;

		if (!obj[i].isItem)
			continue;

		if (inputPlayer.GetHp() >= 5)
			return false;
		if (CollisionRectAndRect(inputPlayer.CollisionRECT(), obj[i].rcObject))
		{
			obj[i].isAlive = false;

			inputPlayer.SetHpAdd();

			return true;
		}
	}

	return false;
}


int GameObject::HitTest(const RECT& r1, const RECT& r2)
{
	RECT t;
	int w, h;

	if (IntersectRect(&t, &r1, &r2))
	{
		w = t.right - t.left;
		h = t.bottom - t.top;

		if (w < h)
			return 1;
		else
			return 2;
	}
	else
		return 0;
}

bool GameObject::DoorOpenEvent(Enemy & inputEnemy, int EnemyindexStart, int EnemyindexEnd, int DoorIndex1, int DoorIndex2)
{
	for (int i = EnemyindexStart; i <= EnemyindexEnd; i++) {

		if (inputEnemy.GetIsAlive(i))
			return false;
	}

	obj[DoorIndex1].isAlive = false;
	obj[DoorIndex2].isAlive = false;

	return true;
}


bool GameObject::DoorCloseEvent(Enemy & inputEnemy, Player & inputPlayer, int Enemyindex, int DoorIndex1, int DoorIndex2)
{
	if (!CollisionCircleAndCircle(300.f, inputEnemy.GetX(Enemyindex), inputEnemy.GetY(Enemyindex),
		inputPlayer.GetRadius(), inputPlayer.GetX(), inputPlayer.GetY()))
		return false;

	if(!inputEnemy.GetIsAlive(Enemyindex))
		return false;


	obj[DoorIndex1].isAlive = true;
	obj[DoorIndex2].isAlive = true;

	return true;
}
