#include "MainGame.h"

MainGame::MainGame()
{

}

MainGame::~MainGame()
{
}


bool MainGame::Init()
{
	GameNode::Init();

	//================
	GetClientRect(_hWnd, &_rcClient);
	//================

	stalkerTest = new StalkerTest;
	assert(stalkerTest != NULL);
	stalkerTest->Init();

	//////////////
	return true;
}

void MainGame::Release()
{
	GameNode::Release();

	//================
	stalkerTest->Release();
	//================
}

void MainGame::Update()
{
	GameNode::Update();


	//================
	stalkerTest->Update();
	//================
}

void MainGame::Render(HDC hdc)
{
	HDC backDC = this->GetBackBuffer()->GetMemDC();
	PatBlt(backDC, 0, 0, WINSIZEX, WINSIZEY, WHITENESS);			// ������ HDC ���ÿ� backDC���
																	// GameNode::Render(hdc);
																	//================														
	//================
	stalkerTest->Render(backDC);
	//================

	this->GetBackBuffer()->Render(hdc, 0, 0);
}