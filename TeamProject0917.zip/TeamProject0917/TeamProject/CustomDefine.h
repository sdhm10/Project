#pragma once

//enum DS_STATE
//{
//	LEFT = -1,
//	NONE,
//	RIGHT,
//};


// ���� ���� ����
enum DIRECTION
{
	DIR_NONE = 0,
	DIR_LEFT,
	DIR_RIGHT,
	DIR_UP,
	DIR_DOWN,
};

// ���� ����
enum STATE
{
	STATE_IDLE = 0,
	STATE_MOVE,
	STATE_ATTACK,
	STATE_BEATTACKED,
	STATE_EVADE,
	STATE_DEAD,
};

enum MONSTERTYPE
{
	TYPE_BOSS,
	TYPE_TURRET,
	TYPE_HOMING,
	TYPE_SHOOT,
};
// ���� ����
enum GUNYTPE
{
	GUNYTPE_NONE = 0,
	GUNYTPE_RIFLE,
	GUNYTPE_SHOTGUN,
	GUNYTPE_LASER,
	GUNYTPE_ROCKET,
};


#define PI			3.141592654f
#define PI2			PI*2


#define MAX_BULLET 5	// �ִ� źȯ ��


//Extern
extern HWND _hWnd;
extern HINSTANCE _hInst;
extern POINT _ptMouse;