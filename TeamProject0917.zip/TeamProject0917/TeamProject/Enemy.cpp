#include "GameHeader.h"
#include "Enemy.h"



Enemy::Enemy()
{
}


Enemy::~Enemy()
{
}

bool Enemy::Init()
{
	return false;
}

void Enemy::Release()
{
}

void Enemy::Update()
{
}

void Enemy::Render(HDC hdc)
{
}

void Enemy::HomingTarget()
{
}
