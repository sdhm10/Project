#pragma once
#include "GameNode.h"
#define		MAX_MONSTER 30


struct Monster
{
	Image*		image;
	MONSTERTYPE type;
	float		angle;		//����
	int			posX;		//����
	int			posY;		
	int			hp;			//ü��
	int			speed;
	bool		isAlive;
	
	STATE		state;
	DIRECTION	monDir;
};
class Enemy	: public GameNode
{
private:
	Monster	_Monster[MAX_MONSTER];

public:
	Enemy();
	~Enemy();

	virtual bool Init();
	virtual void Release();
	virtual void Update();
	virtual void Render(HDC hdc);

	void HomingTarget();

};

