#pragma once

// �ý��� ���
#include <Windows.h>
#include <assert.h>
#include <tchar.h>
#include <stdio.h>
#include <math.h>
#include <string>
#include <map>
#include <list>
#include <vector>

//
using std::vector;
using std::map;
using std::string;
using std::list;


// ����� ���
#include "CustomDefine.h"
#include "CommonMacroFunction.h"
#include "RandomFunction.h"
#include "KeyManager.h"
#include "ImageManager.h"


#include "BackBuffer.h"
#include "Image.h"
#include "Util.h"
#include "CollisionFunction.h"




// �̱��� ��ü ��ũ��
#define RAND		RandomFunction::getSingleton()
#define KEYMANAGER	KeyManager::getSingleton()
#define IMAGEMANAGER ImageManager::getSingleton()

// ������ ���̰��� ��ũ��
#define WINSTYLE		WS_CAPTION | WS_SYSMENU
#define WINSIZEX		1000
#define WINSIZEY		800
#define WINSTARTX		100
#define WINSTARTY		100

// �޸� ���� ��ũ��
#define SAFE_DELETE(p)	{if(p) {delete (p); (p) = NULL;}}
#define SAFE_RELEASE(p)	{if(p) {(p)->Release(); (p) = NULL;}}

//
#if defined(_UNICODE)
typedef  std::wstring		tstring;  //std::basic_string<wchar>
#else	
typedef  std::string		tstring;   //std::basic_string<char>
#endif // #if defined(_UNICODE)
