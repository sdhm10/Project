#include "Wall.h"



Wall::Wall()
{
	walls = new Walls[WALL_COUNT];
}


Wall::~Wall()
{
	delete[] walls;
}

bool Wall::Init()
{
	// ù��° �� ���� ��
	walls[0].x = 0;
	walls[0].y = 0;
	walls[0].width = WALL_SIZE;
	walls[0].height = WINSIZEY;
	walls[0].isWall = true;
	walls[0].isAlive = true;
	walls[0].isDoor = false;
	walls[0].rc = RectMake(walls[0].x, walls[0].y, walls[0].width, walls[0].height);

	// ù��° �� ���� ��
	walls[1].x = 0;
	walls[1].y = 0;
	walls[1].width = WINSIZEX;
	walls[1].height = WALL_SIZE;
	walls[1].isWall = true;
	walls[1].isAlive = true;
	walls[1].isDoor = false;
	walls[1].rc = RectMake(walls[1].x, walls[1].y, walls[1].width, walls[1].height);

	// ù��° �� �Ʒ��� ��
	walls[2].x = 0;
	walls[2].y = WINSIZEY - WALL_SIZE;
	walls[2].width = 1000;
	walls[2].height = WALL_SIZE;
	walls[2].isWall = true;
	walls[2].isAlive = true;
	walls[2].isDoor = false;
	walls[2].rc = RectMake(walls[2].x, walls[2].y, walls[2].width, walls[2].height);

	// ù��° �� ������ �� ��
	walls[3].x = WINSIZEX - WALL_SIZE;
	walls[3].y = 0;
	walls[3].width = WALL_SIZE;
	walls[3].height = WINSIZEY / 2 - WALL_SIZE / 2;
	walls[3].isWall = true;
	walls[3].isAlive = true;
	walls[3].isDoor = false;
	walls[3].rc = RectMake(walls[3].x, walls[3].y, walls[3].width, walls[3].height);

	// ù��° �� ������ �Ʒ� ��
	walls[4].x = WINSIZEX - WALL_SIZE;
	walls[4].y = WINSIZEY / 2 + WALL_SIZE / 2;
	walls[4].width = WALL_SIZE;
	walls[4].height = WINSIZEY / 2 - WALL_SIZE / 2;
	walls[4].isWall = true;
	walls[4].isAlive = true;
	walls[4].isDoor = false;
	walls[4].rc = RectMake(walls[4].x, walls[4].y, walls[4].width, walls[4].height);

	// ù��° �� ������ ��
	walls[5].x = WINSIZEX - WALL_SIZE;
	walls[5].y = WINSIZEY / 2 - WALL_SIZE / 2;
	walls[5].width = WALL_SIZE;
	walls[5].height = WALL_SIZE;
	walls[5].isWall = true;
	walls[5].isAlive = false;
	walls[5].isDoor = true;
	walls[5].rc = RectMake(walls[5].x, walls[5].y, walls[5].width, walls[5].height);

	// �ι�° �� ���� �� ��
	walls[6].x = 1000;
	walls[6].y = 0;
	walls[6].width = WALL_SIZE;
	walls[6].height = 375;
	walls[6].isWall = true;
	walls[6].isAlive = true;
	walls[6].isDoor = false;
	walls[6].rc = RectMake(walls[6].x, walls[6].y, walls[6].width, walls[6].height);

	// �ι�° �� ���� �Ʒ� ��
	walls[7].x = 1000;
	walls[7].y = 425;
	walls[7].width = WALL_SIZE;
	walls[7].height = 375;
	walls[7].isWall = true;
	walls[7].isAlive = true;
	walls[7].isDoor = false;
	walls[7].rc = RectMake(walls[7].x, walls[7].y, walls[7].width, walls[7].height);

	// �ι�° �� ���� ��
	walls[8].x = 1000;
	walls[8].y = 375;
	walls[8].width = WALL_SIZE;
	walls[8].height = WALL_SIZE;
	walls[8].isWall = true;
	walls[8].isAlive = true;
	walls[8].isDoor = true;
	walls[8].rc = RectMake(walls[8].x, walls[8].y, walls[8].width, walls[8].height);

	// �ι�° �� ���� ��
	walls[9].x = 1000;
	walls[9].y = 0;
	walls[9].width = 1000;
	walls[9].height = WALL_SIZE;
	walls[9].isWall = true;
	walls[9].isAlive = true;
	walls[9].isDoor = false;
	walls[9].rc = RectMake(walls[9].x, walls[9].y, walls[9].width, walls[9].height);

	// �ι�° �� ���� ��
	walls[10].x = 1000;
	walls[10].y = 750;
	walls[10].width = 1000;
	walls[10].height = WALL_SIZE;
	walls[10].isWall = true;
	walls[10].isAlive = true;
	walls[10].isDoor = false;
	walls[10].rc = RectMake(walls[10].x, walls[10].y, walls[10].width, walls[10].height);

	// �ι�° �� ������ �� ��
	walls[11].x = 1950;
	walls[11].y = 0;
	walls[11].width = WALL_SIZE;
	walls[11].height = 375;
	walls[11].isWall = true;
	walls[11].isAlive = true;
	walls[11].isDoor = false;
	walls[11].rc = RectMake(walls[11].x, walls[11].y, walls[11].width, walls[11].height);

	// �ι�° �� ������ �Ʒ� ��
	walls[12].x = 1950;
	walls[12].y = 425;
	walls[12].width = WALL_SIZE;
	walls[12].height = 375;
	walls[12].isWall = true;
	walls[12].isAlive = true;
	walls[12].isDoor = false;
	walls[12].rc = RectMake(walls[12].x, walls[12].y, walls[12].width, walls[12].height);

	// �ι�° �� ������ ��
	walls[13].x = 1950;
	walls[13].y = 375;
	walls[13].width = WALL_SIZE;
	walls[13].height = WALL_SIZE;
	walls[13].isWall = true;
	walls[13].isAlive = true;
	walls[13].isDoor = true;
	walls[13].rc = RectMake(walls[13].x, walls[13].y, walls[13].width, walls[13].height);


	return true;
}

void Wall::Release()
{
}

void Wall::Update()
{

}

void Wall::Render(HDC hdc)
{
	for (int i = 0; i < WALL_COUNT; i++)
	{
		if (walls[i].isAlive = true)
			Rectangle(hdc, walls[i].rc.left, walls[i].rc.top, walls[i].rc.right, walls[i].rc.bottom);
	}
}
