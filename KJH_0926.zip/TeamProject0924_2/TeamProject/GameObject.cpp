#include "GameObject.h"



GameObject::GameObject()
{
}


GameObject::~GameObject()
{
}

bool GameObject::Init()
{

	for (int i = 0; i < MAX_OBJECT; i++)
	{
		obj[i].image = NULL;
		obj[i].x = 0.f;							// ��ġ X
		obj[i].y = 0.f;							// ��ġ Y
		obj[i].CameraPos.x = obj[i].x;				// ī�޶� ���� X
		obj[i].CameraPos.x = obj[i].y;				// ī�޶� ���� Y
		obj[i].width = 0.f;						// ��
		obj[i].height = 0.f;					// ����
		obj[i].isAlive = false;					// ��������
		obj[i].isWall = false;					// ���ΰ�?
		obj[i].isItem = false;					// �������ΰ�?
		obj[i].dir = DIRECTION::DIR_NONE;		// ��������ΰ�?

		// �簢�� �ʱ�ȭ
		obj[i].rcObject = RectMake(obj[i].x, obj[i].y, obj[i].width, obj[i].height);
//		obj[i].rcObject = RectMakeCenter(obj[i].x, obj[i].y, obj[i].width, obj[i].height);
	}


	// �׽�Ʈ��(ȸ�� ������)
	obj[0].image = IMAGEMANAGER->AddFrameImage(TEXT("HealthPack"), TEXT("Image/HealthPack.bmp"), 42, 30, 1, 1, true, RGB(0, 255, 0));
	obj[0].x = 100.f;						// ��ġ X
	obj[0].y = 500.f;						// ��ġ Y
	obj[0].width = 42.f;					// ��
	obj[0].height = 30.f;					// ����
	obj[0].isAlive = true;					// ��������
	obj[0].isWall = false;					// ���ΰ�?
	obj[0].isItem = true;					// �������ΰ�?
	obj[0].dir = DIRECTION::DIR_NONE;		// ��������ΰ�?
	obj[0].rcObject = RectMakeCenter(obj[0].x, obj[0].y, obj[0].width, obj[0].height);



	// �׽�Ʈ��(��)
	obj[1].x = 500.f;						// ��ġ X
	obj[1].y = 500.f;						// ��ġ Y
	obj[1].width = 400.f;					// ��
	obj[1].height = 50.f;					// ����
	obj[1].isAlive = true;					// ��������
	obj[1].isWall = true;					// ���ΰ�?
	obj[1].isItem = false;					// �������ΰ�?
	obj[1].dir = DIRECTION::DIR_NONE;		// ��������ΰ�?
	obj[1].rcObject = RectMake(obj[1].x, obj[1].y, obj[1].width, obj[1].height);

	// ������Ʈ 2 ~ 61�� �� �ܺ�
	// 1�� �� ���� ��
	obj[2].x = 0.f;
	obj[2].y = 0.f;
	obj[2].width = WALL_SIZE;
	obj[2].height = WINSIZEY;
	obj[2].isAlive = true;
	obj[2].isWall = true;
	obj[2].isItem = false;
	obj[2].rcObject = RectMake(obj[2].x, obj[2].y, obj[2].width, obj[2].height);

	// 1�� �� ���� ��
	obj[3].x = 0.f;
	obj[3].y = 0.f;
	obj[3].width = WINSIZEX;
	obj[3].height = WALL_SIZE;
	obj[3].isAlive = true;
	obj[3].isWall = true;
	obj[3].isItem = false;
	obj[3].rcObject = RectMake(obj[3].x, obj[3].y, obj[3].width, obj[3].height);

	// 1�� �� �Ʒ��� ��
	obj[4].x = 0.f;
	obj[4].y = WINSIZEY - WALL_SIZE;
	obj[4].width = WINSIZEX;
	obj[4].height = WALL_SIZE;
	obj[4].isAlive = true;
	obj[4].isWall = true;
	obj[4].isItem = false;
	obj[4].rcObject = RectMake(obj[4].x, obj[4].y, obj[4].width, obj[4].height);

	// 1�� �� ������ �� ��
	obj[5].x = WINSIZEX - WALL_SIZE;
	obj[5].y = 0.f;
	obj[5].width = WALL_SIZE;
	obj[5].height = (WINSIZEY - WALL_SIZE) / 2;
	obj[5].isAlive = true;
	obj[5].isWall = true;
	obj[5].isItem = false;
	obj[5].rcObject = RectMake(obj[5].x, obj[5].y, obj[5].width, obj[5].height);

	// 1�� �� ������ �Ʒ� ��
	obj[6].x = WINSIZEX - WALL_SIZE;
	obj[6].y = WINSIZEY / 2 + WALL_SIZE / 2;
	obj[6].width = WALL_SIZE;
	obj[6].height = (WINSIZEY - WALL_SIZE) / 2;
	obj[6].isAlive = true;
	obj[6].isWall = true;
	obj[6].isItem = false;
	obj[6].rcObject = RectMake(obj[6].x, obj[6].y, obj[6].width, obj[6].height);

	// 1�� �� ������ ��
	obj[7].x = WINSIZEX - WALL_SIZE;
	obj[7].y = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[7].width = WALL_SIZE;
	obj[7].height = WALL_SIZE;
	obj[7].isAlive = false;
	obj[7].isWall = true;
	obj[7].isItem = false;
	obj[7].rcObject = RectMake(obj[7].x, obj[7].y, obj[7].width, obj[7].height);

	// 2�� �� ���� �� ��
	obj[8].x = WINSIZEX;
	obj[8].y = 0.f;
	obj[8].width = WALL_SIZE;
	obj[8].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[8].isAlive = true;
	obj[8].isWall = true;
	obj[8].isItem = false;
	obj[8].rcObject = RectMake(obj[8].x, obj[8].y, obj[8].width, obj[8].height);

	// 2�� �� ���� �Ʒ� ��
	obj[9].x = WINSIZEX;
	obj[9].y = WINSIZEY / 2 + WALL_SIZE / 2;
	obj[9].width = WALL_SIZE;
	obj[9].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[9].isAlive = true;
	obj[9].isWall = true;
	obj[9].isItem = false;
	obj[9].rcObject = RectMake(obj[9].x, obj[9].y, obj[9].width, obj[9].height);

	// 2�� �� ���� ��
	obj[10].x = WINSIZEX;
	obj[10].y = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[10].width = WALL_SIZE;
	obj[10].height = WALL_SIZE;
	obj[10].isAlive = false;
	obj[10].isWall = true;
	obj[10].isItem = false;
	obj[10].rcObject = RectMake(obj[10].x, obj[10].y, obj[10].width, obj[10].height);

	// 2�� �� ���� ��
	obj[11].x = WINSIZEX;
	obj[11].y = 0.f;
	obj[11].width = WINSIZEX;
	obj[11].height = WALL_SIZE;
	obj[11].isAlive = true;
	obj[11].isWall = true;
	obj[11].isItem = false;
	obj[11].rcObject = RectMake(obj[11].x, obj[11].y, obj[11].width, obj[11].height);

	// 2�� �� �Ʒ� ���� ��
	obj[12].x = WINSIZEX;
	obj[12].y = WINSIZEY - WALL_SIZE;
	obj[12].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[12].height = WALL_SIZE;
	obj[12].isAlive = true;
	obj[12].isWall = true;
	obj[12].isItem = false;
	obj[12].rcObject = RectMake(obj[12].x, obj[12].y, obj[12].width, obj[12].height);

	// 2�� �� �Ʒ� ������ ��
	obj[13].x = WINSIZEX + (WINSIZEX / 2 + WALL_SIZE / 2);
	obj[13].y = WINSIZEY - WALL_SIZE;
	obj[13].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[13].height = WALL_SIZE;
	obj[13].isAlive = true;
	obj[13].isWall = true;
	obj[13].isItem = false;
	obj[13].rcObject = RectMake(obj[13].x, obj[13].y, obj[13].width, obj[13].height);

	// 2�� �� �Ʒ� ��
	obj[14].x = WINSIZEX + (WINSIZEX / 2 - WALL_SIZE / 2);
	obj[14].y = WINSIZEY - WALL_SIZE;
	obj[14].width = WALL_SIZE;
	obj[14].height = WALL_SIZE;
	obj[14].isAlive = false;
	obj[14].isWall = true;
	obj[14].isItem = false;
	obj[14].rcObject = RectMake(obj[14].x, obj[14].y, obj[14].width, obj[14].height);

	// 2�� �� ������ ��
	obj[15].x = WINSIZEX * 2 - WALL_SIZE;
	obj[15].y = 0.f;
	obj[15].width = WALL_SIZE;
	obj[15].height = WINSIZEY;
	obj[15].isAlive = true;
	obj[15].isWall = true;
	obj[15].isItem = false;
	obj[15].rcObject = RectMake(obj[15].x, obj[15].y, obj[15].width, obj[15].height);

	// 3�� �� ���� �� ��
	obj[16].x = WINSIZEX;
	obj[16].y = WINSIZEY;
	obj[16].width = WALL_SIZE;
	obj[16].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[16].isAlive = true;
	obj[16].isWall = true;
	obj[16].isItem = false;
	obj[16].rcObject = RectMake(obj[16].x, obj[16].y, obj[16].width, obj[16].height);

	// 3�� �� ���� �Ʒ� ��
	obj[17].x = WINSIZEX;
	obj[17].y = WINSIZEY + (WINSIZEY / 2 + WALL_SIZE / 2);
	obj[17].width = WALL_SIZE;
	obj[17].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[17].isAlive = true;
	obj[17].isWall = true;
	obj[17].isItem = false;
	obj[17].rcObject = RectMake(obj[17].x, obj[17].y, obj[17].width, obj[17].height);

	// 3�� �� ���� ��
	obj[18].x = WINSIZEX;
	obj[18].y = WINSIZEY + (WINSIZEY / 2 - WALL_SIZE / 2);
	obj[18].width = WALL_SIZE;
	obj[18].height = WALL_SIZE;
	obj[18].isAlive = false;
	obj[18].isWall = true;
	obj[18].isItem = false;
	obj[18].rcObject = RectMake(obj[18].x, obj[18].y, obj[18].width, obj[18].height);

	// 3�� �� �� ���� ��
	obj[19].x = WINSIZEX;
	obj[19].y = WINSIZEY;
	obj[19].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[19].height = WALL_SIZE;
	obj[19].isAlive = true;
	obj[19].isWall = true;
	obj[19].isItem = false;
	obj[19].rcObject = RectMake(obj[19].x, obj[19].y, obj[19].width, obj[19].height);

	// 3�� �� �� ������ ��
	obj[20].x = WINSIZEX + (WINSIZEX / 2 + WALL_SIZE / 2);
	obj[20].y = WINSIZEY;
	obj[20].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[20].height = WALL_SIZE;
	obj[20].isAlive = true;
	obj[20].isWall = true;
	obj[20].isItem = false;
	obj[20].rcObject = RectMake(obj[20].x, obj[20].y, obj[20].width, obj[20].height);

	// 3�� �� ���� ��
	obj[21].x = WINSIZEX + (WINSIZEX / 2 - WALL_SIZE / 2);
	obj[21].y = WINSIZEY;
	obj[21].width = WALL_SIZE;
	obj[21].height = WALL_SIZE;
	obj[21].isAlive = false;
	obj[21].isWall = true;
	obj[21].isItem = false;
	obj[21].rcObject = RectMake(obj[21].x, obj[21].y, obj[21].width, obj[21].height);

	// 3�� �� �Ʒ��� ��
	obj[22].x = WINSIZEX;
	obj[22].y = WINSIZEY * 2 - WALL_SIZE;
	obj[22].width = WINSIZEX;
	obj[22].height = WALL_SIZE;
	obj[22].isAlive = true;
	obj[22].isWall = true;
	obj[22].isItem = false;
	obj[22].rcObject = RectMake(obj[22].x, obj[22].y, obj[22].width, obj[22].height);

	// 3�� �� ������ ��
	obj[23].x = WINSIZEX * 2 - WALL_SIZE;
	obj[23].y = WINSIZEY;
	obj[23].width = WALL_SIZE;
	obj[23].height = WINSIZEY;
	obj[23].isAlive = true;
	obj[23].isWall = true;
	obj[23].isItem = false;
	obj[23].rcObject = RectMake(obj[23].x, obj[23].y, obj[23].width, obj[23].height);

	// 4�� �� ���� ��
	obj[24].x = 0.f;
	obj[24].y = WINSIZEY;
	obj[24].width = WALL_SIZE;
	obj[24].height = WINSIZEY;
	obj[24].isAlive = true;
	obj[24].isWall = true;
	obj[24].isItem = false;
	obj[24].rcObject = RectMake(obj[24].x, obj[24].y, obj[24].width, obj[24].height);

	// 4�� �� ���� ��
	obj[25].x = 0.f;
	obj[25].y = WINSIZEY;
	obj[25].width = WINSIZEX;
	obj[25].height = WALL_SIZE;
	obj[25].isAlive = true;
	obj[25].isWall = true;
	obj[25].isItem = false;
	obj[25].rcObject = RectMake(obj[25].x, obj[25].y, obj[25].width, obj[25].height);

	// 4�� �� �Ʒ� ���� ��
	obj[26].x = 0.f;
	obj[26].y = WINSIZEY * 2 - WALL_SIZE;
	obj[26].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[26].height = WALL_SIZE;
	obj[26].isAlive = true;
	obj[26].isWall = true;
	obj[26].isItem = false;
	obj[26].rcObject = RectMake(obj[26].x, obj[26].y, obj[26].width, obj[26].height);

	// 4�� �� �Ʒ� ���� ��
	obj[27].x = WINSIZEX / 2 + WALL_SIZE / 2;
	obj[27].y = WINSIZEY * 2 - WALL_SIZE;
	obj[27].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[27].height = WALL_SIZE;
	obj[27].isAlive = true;
	obj[27].isWall = true;
	obj[27].isItem = false;
	obj[27].rcObject = RectMake(obj[27].x, obj[27].y, obj[27].width, obj[27].height);

	// 4�� �� �Ʒ� ��
	obj[28].x = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[28].y = WINSIZEY * 2 - WALL_SIZE;
	obj[28].width = WALL_SIZE;
	obj[28].height = WALL_SIZE;
	obj[28].isAlive = false;
	obj[28].isWall = true;
	obj[28].isItem = false;
	obj[28].rcObject = RectMake(obj[28].x, obj[28].y, obj[28].width, obj[28].height);

	// 4�� �� ������ �� ��
	obj[29].x = WINSIZEX - WALL_SIZE;
	obj[29].y = WINSIZEY;
	obj[29].width = WALL_SIZE;
	obj[29].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[29].isAlive = true;
	obj[29].isWall = true;
	obj[29].isItem = false;
	obj[29].rcObject = RectMake(obj[29].x, obj[29].y, obj[29].width, obj[29].height);

	// 4�� �� ������ �Ʒ� ��
	obj[30].x = WINSIZEX - WALL_SIZE;
	obj[30].y = WINSIZEY + (WINSIZEY / 2 + WALL_SIZE / 2);
	obj[30].width = WALL_SIZE;
	obj[30].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[30].isAlive = true;
	obj[30].isWall = true;
	obj[30].isItem = false;
	obj[30].rcObject = RectMake(obj[30].x, obj[30].y, obj[30].width, obj[30].height);

	// 4�� �� ������ ��
	obj[31].x = WINSIZEX - WALL_SIZE;
	obj[31].y = WINSIZEY + (WINSIZEY / 2 - WALL_SIZE / 2);
	obj[31].width = WALL_SIZE;
	obj[31].height = WALL_SIZE;
	obj[31].isAlive = false;
	obj[31].isWall = true;
	obj[31].isItem = false;
	obj[31].rcObject = RectMake(obj[31].x, obj[31].y, obj[31].width, obj[31].height);

	// 5�� �� ���� ��
	obj[32].x = 0.f;
	obj[32].y = WINSIZEY * 2;
	obj[32].width = WALL_SIZE;
	obj[32].height = WINSIZEY;
	obj[32].isAlive = true;
	obj[32].isWall = true;
	obj[32].isItem = false;
	obj[32].rcObject = RectMake(obj[32].x, obj[32].y, obj[32].width, obj[32].height);

	// 5�� �� �� ���� ��
	obj[33].x = 0.f;
	obj[33].y = WINSIZEY * 2;
	obj[33].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[33].height = WALL_SIZE;
	obj[33].isAlive = true;
	obj[33].isWall = true;
	obj[33].isItem = false;
	obj[33].rcObject = RectMake(obj[33].x, obj[33].y, obj[33].width, obj[33].height);

	// 5�� �� �� ������ ��
	obj[34].x = WINSIZEX / 2 + WALL_SIZE / 2;
	obj[34].y = WINSIZEY * 2;
	obj[34].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[34].height = WALL_SIZE;
	obj[34].isAlive = true;
	obj[34].isWall = true;
	obj[34].isItem = false;
	obj[34].rcObject = RectMake(obj[34].x, obj[34].y, obj[34].width, obj[34].height);

	// 5�� �� ���� ��
	obj[35].x = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[35].y = WINSIZEY * 2;
	obj[35].width = WALL_SIZE;
	obj[35].height = WALL_SIZE;
	obj[35].isAlive = false;
	obj[35].isWall = true;
	obj[35].isItem = false;
	obj[35].rcObject = RectMake(obj[35].x, obj[35].y, obj[35].width, obj[35].height);

	// 5�� �� �Ʒ��� ��
	obj[36].x = 0.f;
	obj[36].y = WINSIZEY * 3 - WALL_SIZE;
	obj[36].width = WINSIZEX;
	obj[36].height = WALL_SIZE;
	obj[36].isAlive = true;
	obj[36].isWall = true;
	obj[36].isItem = false;
	obj[36].rcObject = RectMake(obj[36].x, obj[36].y, obj[36].width, obj[36].height);

	// 5�� �� ������ �� ��
	obj[37].x = WINSIZEX - WALL_SIZE;
	obj[37].y = WINSIZEY * 2;
	obj[37].width = WALL_SIZE;
	obj[37].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[37].isAlive = true;
	obj[37].isWall = true;
	obj[37].isItem = false;
	obj[37].rcObject = RectMake(obj[37].x, obj[37].y, obj[37].width, obj[37].height);

	// 5�� �� ������ �Ʒ� ��
	obj[38].x = WINSIZEX - WALL_SIZE;
	obj[38].y = WINSIZEY * 2 + (WINSIZEY / 2 + WALL_SIZE / 2);
	obj[38].width = WALL_SIZE;
	obj[38].height = (WINSIZEY - WALL_SIZE) / 2;
	obj[38].isAlive = true;
	obj[38].isWall = true;
	obj[38].isItem = false;
	obj[38].rcObject = RectMake(obj[38].x, obj[38].y, obj[38].width, obj[38].height);

	// 5�� �� ������ ��
	obj[39].x = WINSIZEX - WALL_SIZE;
	obj[39].y = WINSIZEY * 2 + (WINSIZEY / 2 - WALL_SIZE / 2);
	obj[39].width = WALL_SIZE;
	obj[39].height = WALL_SIZE;
	obj[39].isAlive = false;
	obj[39].isWall = true;
	obj[39].isItem = false;
	obj[39].rcObject = RectMake(obj[39].x, obj[39].y, obj[39].width, obj[39].height);

	// 6�� �� ���� �� ��
	obj[40].x = WINSIZEX;
	obj[40].y = WINSIZEY * 2;
	obj[40].width = WALL_SIZE;
	obj[40].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[40].isAlive = true;
	obj[40].isWall = true;
	obj[40].isItem = false;
	obj[40].rcObject = RectMake(obj[40].x, obj[40].y, obj[40].width, obj[40].height);

	// 6�� �� ���� �Ʒ� ��
	obj[41].x = WINSIZEX;
	obj[41].y = WINSIZEY * 2 + (WINSIZEY / 2 + WALL_SIZE / 2);
	obj[41].width = WALL_SIZE;
	obj[41].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[41].isAlive = true;
	obj[41].isWall = true;
	obj[41].isItem = false;
	obj[41].rcObject = RectMake(obj[41].x, obj[41].y, obj[41].width, obj[41].height);

	// 6�� �� ���� ��
	obj[42].x = WINSIZEX;
	obj[42].y = WINSIZEY * 2 + (WINSIZEY / 2 - WALL_SIZE / 2);
	obj[42].width = WALL_SIZE;
	obj[42].height = WALL_SIZE;
	obj[42].isAlive = false;
	obj[42].isWall = true;
	obj[42].isItem = false;
	obj[42].rcObject = RectMake(obj[42].x, obj[42].y, obj[42].width, obj[42].height);

	// 6�� �� ���� ��
	obj[43].x = WINSIZEX;
	obj[43].y = WINSIZEY * 2;
	obj[43].width = WINSIZEX;
	obj[43].height = WALL_SIZE;
	obj[43].isAlive = true;
	obj[43].isWall = true;
	obj[43].isItem = false;
	obj[43].rcObject = RectMake(obj[43].x, obj[43].y, obj[43].width, obj[43].height);

	// 6�� �� �Ʒ� ���� ��
	obj[44].x = WINSIZEX;
	obj[44].y = WINSIZEY * 3 - WALL_SIZE;
	obj[44].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[44].height = WALL_SIZE;
	obj[44].isAlive = true;
	obj[44].isWall = true;
	obj[44].isItem = false;
	obj[44].rcObject = RectMake(obj[44].x, obj[44].y, obj[44].width, obj[44].height);

	// 6�� �� �Ʒ� ������ ��
	obj[45].x = WINSIZEX + (WINSIZEX / 2 + WALL_SIZE / 2);
	obj[45].y = WINSIZEY * 3 - WALL_SIZE;
	obj[45].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[45].height = WALL_SIZE;
	obj[45].isAlive = true;
	obj[45].isWall = true;
	obj[45].isItem = false;
	obj[45].rcObject = RectMake(obj[45].x, obj[45].y, obj[45].width, obj[45].height);

	// 6�� �� �Ʒ� ��
	obj[46].x = WINSIZEX + (WINSIZEX / 2 - WALL_SIZE / 2);
	obj[46].y = WINSIZEY * 3 - WALL_SIZE;
	obj[46].width = WALL_SIZE;
	obj[46].height = WALL_SIZE;
	obj[46].isAlive = false;
	obj[46].isWall = true;
	obj[46].isItem = false;
	obj[46].rcObject = RectMake(obj[46].x, obj[46].y, obj[46].width, obj[46].height);

	// 6�� �� ������ ��
	obj[47].x = WINSIZEX * 2 - WALL_SIZE;
	obj[47].y = WINSIZEY * 2;
	obj[47].width = WALL_SIZE;
	obj[47].height = WINSIZEY;
	obj[47].isAlive = true;
	obj[47].isWall = true;
	obj[47].isItem = false;
	obj[47].rcObject = RectMake(obj[47].x, obj[47].y, obj[47].width, obj[47].height);

	// 7�� �� ���� �� ��
	obj[48].x = WINSIZEX;
	obj[48].y = WINSIZEY * 3;
	obj[48].width = WALL_SIZE;
	obj[48].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[48].isAlive = true;
	obj[48].isWall = true;
	obj[48].isItem = false;
	obj[48].rcObject = RectMake(obj[48].x, obj[48].y, obj[48].width, obj[48].height);

	// 7�� �� ���� �Ʒ� ��
	obj[49].x = WINSIZEX;
	obj[49].y = WINSIZEY * 3 + (WINSIZEY / 2 + WALL_SIZE / 2);
	obj[49].width = WALL_SIZE;
	obj[49].height = WINSIZEY / 2 - WALL_SIZE / 2;
	obj[49].isAlive = true;
	obj[49].isWall = true;
	obj[49].isItem = false;
	obj[49].rcObject = RectMake(obj[49].x, obj[49].y, obj[49].width, obj[49].height);

	// 7�� �� ���� ��
	obj[50].x = WINSIZEX;
	obj[50].y = WINSIZEY * 3 + (WINSIZEY / 2 - WALL_SIZE / 2);
	obj[50].width = WALL_SIZE;
	obj[50].height = WALL_SIZE;
	obj[50].isAlive = false;
	obj[50].isWall = true;
	obj[50].isItem = false;
	obj[50].rcObject = RectMake(obj[50].x, obj[50].y, obj[50].width, obj[50].height);

	// 7�� �� �� ���� ��
	obj[51].x = WINSIZEX;
	obj[51].y = WINSIZEY * 3;
	obj[51].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[51].height = WALL_SIZE;
	obj[51].isAlive = true;
	obj[51].isWall = true;
	obj[51].isItem = false;
	obj[51].rcObject = RectMake(obj[51].x, obj[51].y, obj[51].width, obj[51].height);

	// 7�� �� �� ������ ��
	obj[52].x = WINSIZEX + (WINSIZEX / 2 + WALL_SIZE / 2);
	obj[52].y = WINSIZEY * 3;
	obj[52].width = WINSIZEX / 2 - WALL_SIZE / 2;
	obj[52].height = WALL_SIZE;
	obj[52].isAlive = true;
	obj[52].isWall = true;
	obj[52].isItem = false;
	obj[52].rcObject = RectMake(obj[52].x, obj[52].y, obj[52].width, obj[52].height);

	// 7�� �� ���� ��
	obj[53].x = WINSIZEX + (WINSIZEX / 2 - WALL_SIZE / 2);
	obj[53].y = WINSIZEY * 3;
	obj[53].width = WALL_SIZE;
	obj[53].height = WALL_SIZE;
	obj[53].isAlive = false;
	obj[53].isWall = true;
	obj[53].isItem = false;
	obj[53].rcObject = RectMake(obj[53].x, obj[53].y, obj[53].width, obj[53].height);

	// 7�� �� �Ʒ��� ��
	obj[54].x = WINSIZEX;
	obj[54].y = WINSIZEY * 4 - WALL_SIZE;
	obj[54].width = WINSIZEX;
	obj[54].height = WALL_SIZE;
	obj[54].isAlive = true;
	obj[54].isWall = true;
	obj[54].isItem = false;
	obj[54].rcObject = RectMake(obj[54].x, obj[54].y, obj[54].width, obj[54].height);

	// 7�� �� ������ ��
	obj[55].x = WINSIZEX * 2 - WALL_SIZE;
	obj[55].y = WINSIZEY * 3;
	obj[55].width = WALL_SIZE;
	obj[55].height = WINSIZEY;
	obj[55].isAlive = true;
	obj[55].isWall = true;
	obj[55].isItem = false;
	obj[55].rcObject = RectMake(obj[55].x, obj[55].y, obj[55].width, obj[55].height);

	// 8�� �� ���� ��
	obj[56].x = 0.f;
	obj[56].y = WINSIZEY * 3;
	obj[56].width = WALL_SIZE;
	obj[56].height = WINSIZEY;
	obj[56].isAlive = true;
	obj[56].isWall = true;
	obj[56].isItem = false;
	obj[56].rcObject = RectMake(obj[56].x, obj[56].y, obj[56].width, obj[56].height);

	// 8�� �� ���� ��
	obj[57].x = 0.f;
	obj[57].y = WINSIZEY * 3;
	obj[57].width = WINSIZEX;
	obj[57].height = WALL_SIZE;
	obj[57].isAlive = true;
	obj[57].isWall = true;
	obj[57].isItem = false;
	obj[57].rcObject = RectMake(obj[57].x, obj[57].y, obj[57].width, obj[57].height);

	// 8�� �� �Ʒ��� ��
	obj[58].x = 0.f;
	obj[58].y = WINSIZEY * 4 - WALL_SIZE;
	obj[58].width = WINSIZEX;
	obj[58].height = WALL_SIZE;
	obj[58].isAlive = true;
	obj[58].isWall = true;
	obj[58].isItem = false;
	obj[58].rcObject = RectMake(obj[58].x, obj[58].y, obj[58].width, obj[58].height);

	// 8�� �� ������ �� ��
	obj[59].x = WINSIZEX - WALL_SIZE;
	obj[59].y = WINSIZEY * 3;
	obj[59].width = WALL_SIZE;
	obj[59].height = (WINSIZEY - WALL_SIZE) / 2;
	obj[59].isAlive = true;
	obj[59].isWall = true;
	obj[59].isItem = false;
	obj[59].rcObject = RectMake(obj[59].x, obj[59].y, obj[59].width, obj[59].height);

	// 8�� �� ������ �Ʒ� ��
	obj[60].x = WINSIZEX - WALL_SIZE;
	obj[60].y = WINSIZEY * 3 + (WINSIZEY / 2 + WALL_SIZE / 2);
	obj[60].width = WALL_SIZE;
	obj[60].height = (WINSIZEY - WALL_SIZE) / 2;
	obj[60].isAlive = true;
	obj[60].isWall = true;
	obj[60].isItem = false;
	obj[60].rcObject = RectMake(obj[60].x, obj[60].y, obj[60].width, obj[60].height);

	// 1�� �� ������ ��
	obj[61].x = WINSIZEX - WALL_SIZE;
	obj[61].y = WINSIZEX * 3 + (WINSIZEY / 2 - WALL_SIZE / 2);
	obj[61].width = WALL_SIZE;
	obj[61].height = WALL_SIZE;
	obj[61].isAlive = false;
	obj[61].isWall = true;
	obj[61].isItem = false;
	obj[61].rcObject = RectMake(obj[61].x, obj[61].y, obj[61].width, obj[61].height);

	// 2�� �� ��ֹ� 1
	obj[62].x = WINSIZEX + (WINSIZEX / 4) - (WALL_SIZE / 2);
	obj[62].y = WINSIZEY / 4 - (WALL_SIZE / 2);
	obj[62].width = WALL_SIZE;
	obj[62].height = WALL_SIZE;
	obj[62].isAlive = true;
	obj[62].isWall = true;
	obj[62].isItem = false;
	obj[62].rcObject = RectMake(obj[62].x, obj[62].y, obj[62].width, obj[62].height);

	// 2�� �� ��ֹ� 2
	obj[63].x = WINSIZEX + (WINSIZEX / 4) - (WALL_SIZE / 2);
	obj[63].y = (WINSIZEY / 4) * 3 - (WALL_SIZE / 2);
	obj[63].width = WALL_SIZE;
	obj[63].height = WALL_SIZE;
	obj[63].isAlive = true;
	obj[63].isWall = true;
	obj[63].isItem = false;
	obj[63].rcObject = RectMake(obj[63].x, obj[63].y, obj[63].width, obj[63].height);

	// 2�� �� ��ֹ� 3
	obj[64].x = WINSIZEX + (WINSIZEX / 2) - (WALL_SIZE / 2);
	obj[64].y = (WINSIZEY / 3) - (WALL_SIZE / 2);
	obj[64].width = WALL_SIZE;
	obj[64].height = (WINSIZEY / 3) + WALL_SIZE;
	obj[64].isAlive = true;
	obj[64].isWall = true;
	obj[64].isItem = false;
	obj[64].rcObject = RectMake(obj[64].x, obj[64].y, obj[64].width, obj[64].height);

	// 3�� �� ��ֹ� 1
	obj[65].x = WINSIZEX + (WINSIZEX / 2) - (WALL_SIZE / 2);
	obj[65].y = WINSIZEY + (WINSIZEY / 3) - (WALL_SIZE / 2);
	obj[65].width = WALL_SIZE;
	obj[65].height = WINSIZEY / 3 * 2 - (WALL_SIZE / 2);
	obj[65].isAlive = true;
	obj[65].isWall = true;
	obj[65].isItem = false;
	obj[65].rcObject = RectMake(obj[65].x, obj[65].y, obj[65].width, obj[65].height);

	// 3�� �� ��ֹ� 2
	obj[66].x = WINSIZEX + (WINSIZEX / 4) - (WALL_SIZE / 2);
	obj[66].y = WINSIZEY + (WINSIZEY / 3) - (WALL_SIZE / 2);
	obj[66].width = WALL_SIZE;
	obj[66].height = WALL_SIZE;
	obj[66].isAlive = true;
	obj[66].isWall = true;
	obj[66].isItem = false;
	obj[66].rcObject = RectMake(obj[66].x, obj[66].y, obj[66].width, obj[66].height);

	// 3�� �� ��ֹ� 3
	obj[67].x = WINSIZEX + (WINSIZEX / 4 * 3) - (WALL_SIZE / 2);
	obj[67].y = WINSIZEY + (WINSIZEY / 3) - (WALL_SIZE / 2);
	obj[67].width = WALL_SIZE;
	obj[67].height = WALL_SIZE;
	obj[67].isAlive = true;
	obj[67].isWall = true;
	obj[67].isItem = false;
	obj[67].rcObject = RectMake(obj[67].x, obj[67].y, obj[67].width, obj[67].height);

	// 4�� �� ��ֹ� 1
	obj[68].x = (WINSIZEX / 4) - (WALL_SIZE / 2);
	obj[68].y = WINSIZEY + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[68].width = WALL_SIZE;
	obj[68].height = WALL_SIZE;
	obj[68].isAlive = true;
	obj[68].isWall = true;
	obj[68].isItem = false;
	obj[68].rcObject = RectMake(obj[68].x, obj[68].y, obj[68].width, obj[68].height);

	// 4�� �� ��ֹ� 2
	obj[69].x = (WINSIZEX - WALL_SIZE) / 2 - WALL_SIZE;
	obj[69].y = WINSIZEY + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[69].width = (WINSIZEX + WALL_SIZE) / 2;
	obj[69].height = WALL_SIZE;
	obj[69].isAlive = true;
	obj[69].isWall = true;
	obj[69].isItem = false;
	obj[69].rcObject = RectMake(obj[69].x, obj[69].y, obj[69].width, obj[69].height);

	// 4�� �� ��ֹ� 3
	obj[70].x = WALL_SIZE;
	obj[70].y = WINSIZEY + (WINSIZEY / 2) - (WALL_SIZE / 2);
	obj[70].width = (WINSIZEX + WALL_SIZE) / 2;
	obj[70].height = WALL_SIZE;
	obj[70].isAlive = true;
	obj[70].isWall = true;
	obj[70].isItem = false;
	obj[70].rcObject = RectMake(obj[70].x, obj[70].y, obj[70].width, obj[70].height);

	// 4�� �� ��ֹ� 4
	obj[71].x = (WINSIZEX / 4 * 3) - (WALL_SIZE / 2);
	obj[71].y = WINSIZEY + (WINSIZEY / 2) - (WALL_SIZE / 2);
	obj[71].width = WALL_SIZE;
	obj[71].height = WALL_SIZE;
	obj[71].isAlive = true;
	obj[71].isWall = true;
	obj[71].isItem = false;
	obj[71].rcObject = RectMake(obj[71].x, obj[71].y, obj[71].width, obj[71].height);

	// 4�� �� ��ֹ� 5
	obj[72].x = (WINSIZEX / 4) - (WALL_SIZE / 2);
	obj[72].y = WINSIZEY + (WINSIZEY / 4 * 3) - (WALL_SIZE / 2);
	obj[72].width = WALL_SIZE;
	obj[72].height = WALL_SIZE;
	obj[72].isAlive = true;
	obj[72].isWall = true;
	obj[72].isItem = false;
	obj[72].rcObject = RectMake(obj[72].x, obj[72].y, obj[72].width, obj[72].height);

	// 4�� �� ��ֹ� 6
	obj[73].x = (WINSIZEX - WALL_SIZE) / 2 - WALL_SIZE;
	obj[73].y = WINSIZEY + (WINSIZEY / 4 * 3) - (WALL_SIZE / 2);
	obj[73].width = (WINSIZEX + WALL_SIZE) / 2;
	obj[73].height = WALL_SIZE;
	obj[73].isAlive = true;
	obj[73].isWall = true;
	obj[73].isItem = false;
	obj[73].rcObject = RectMake(obj[73].x, obj[73].y, obj[73].width, obj[73].height);

	// 5�� �� ��ֹ� 1
	obj[74].x = (WINSIZEX / 2) - (WALL_SIZE / 2);
	obj[74].y = (WINSIZEY * 2) + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[74].width = WALL_SIZE;
	obj[74].height = WALL_SIZE;
	obj[74].isAlive = true;
	obj[74].isWall = true;
	obj[74].isItem = false;
	obj[74].rcObject = RectMake(obj[74].x, obj[74].y, obj[74].width, obj[74].height);

	// 5�� �� ��ֹ� 2
	obj[75].x = (WINSIZEX / 4) - (WALL_SIZE / 2);
	obj[75].y = (WINSIZEY * 2) +(WINSIZEY / 2) - (WALL_SIZE / 2);
	obj[75].width = WALL_SIZE;
	obj[75].height = WALL_SIZE;
	obj[75].isAlive = true;
	obj[75].isWall = true;
	obj[75].isItem = false;
	obj[75].rcObject = RectMake(obj[75].x, obj[75].y, obj[75].width, obj[75].height);

	// 5�� �� ��ֹ� 3
	obj[76].x = (WINSIZEX / 4 * 3) - (WALL_SIZE / 2);
	obj[76].y = (WINSIZEY * 2) + (WINSIZEY / 2) - (WALL_SIZE / 2);
	obj[76].width = WALL_SIZE;
	obj[76].height = WALL_SIZE;
	obj[76].isAlive = true;
	obj[76].isWall = true;
	obj[76].isItem = false;
	obj[76].rcObject = RectMake(obj[76].x, obj[76].y, obj[76].width, obj[76].height);

	// 5�� �� ��ֹ� 4
	obj[77].x = (WINSIZEX / 2) - (WALL_SIZE / 2);
	obj[77].y = (WINSIZEY * 2) + (WINSIZEY / 4 * 3) - (WALL_SIZE / 2);
	obj[77].width = WALL_SIZE;
	obj[77].height = WALL_SIZE;
	obj[77].isAlive = true;
	obj[77].isWall = true;
	obj[77].isItem = false;
	obj[77].rcObject = RectMake(obj[77].x, obj[77].y, obj[77].width, obj[77].height);

	// 6�� �� ��ֹ� 1
	obj[78].x = WINSIZEX + (WINSIZEX / 8) - (WALL_SIZE / 2);
	obj[78].y = (WINSIZEY * 2) + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[78].width = WALL_SIZE;
	obj[78].height = WALL_SIZE;
	obj[78].isAlive = true;
	obj[78].isWall = true;
	obj[78].isItem = false;
	obj[78].rcObject = RectMake(obj[78].x, obj[78].y, obj[78].width, obj[78].height);

	// 6�� �� ��ֹ� 2
	obj[79].x = WINSIZEX + (WINSIZEX / 8 * 2) - (WALL_SIZE / 2);
	obj[79].y = (WINSIZEY * 2) + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[79].width = WALL_SIZE;
	obj[79].height = WALL_SIZE;
	obj[79].isAlive = true;
	obj[79].isWall = true;
	obj[79].isItem = false;
	obj[79].rcObject = RectMake(obj[79].x, obj[79].y, obj[79].width, obj[79].height);

	// 6�� �� ��ֹ� 3
	obj[80].x = WINSIZEX + (WINSIZEX / 8 * 3) - (WALL_SIZE / 2);
	obj[80].y = (WINSIZEY * 2) + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[80].width = WALL_SIZE;
	obj[80].height = WALL_SIZE;
	obj[80].isAlive = true;
	obj[80].isWall = true;
	obj[80].isItem = false;
	obj[80].rcObject = RectMake(obj[80].x, obj[80].y, obj[80].width, obj[80].height);

	// 6�� �� ��ֹ� 4
	obj[81].x = WINSIZEX + (WINSIZEX / 8 * 4) - (WALL_SIZE / 2);
	obj[81].y = (WINSIZEY * 2) + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[81].width = WALL_SIZE;
	obj[81].height = WALL_SIZE;
	obj[81].isAlive = true;
	obj[81].isWall = true;
	obj[81].isItem = false;
	obj[81].rcObject = RectMake(obj[81].x, obj[81].y, obj[81].width, obj[81].height);

	// 6�� �� ��ֹ� 5
	obj[82].x = WINSIZEX + (WINSIZEX / 8 * 5) - (WALL_SIZE / 2);
	obj[82].y = (WINSIZEY * 2) + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[82].width = WALL_SIZE;
	obj[82].height = WALL_SIZE;
	obj[82].isAlive = true;
	obj[82].isWall = true;
	obj[82].isItem = false;
	obj[82].rcObject = RectMake(obj[82].x, obj[82].y, obj[82].width, obj[82].height);

	// 6�� �� ��ֹ� 6
	obj[83].x = WINSIZEX + (WINSIZEX / 8 * 6) - (WALL_SIZE / 2);
	obj[83].y = (WINSIZEY * 2) + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[83].width = WALL_SIZE;
	obj[83].height = WALL_SIZE;
	obj[83].isAlive = true;
	obj[83].isWall = true;
	obj[83].isItem = false;
	obj[83].rcObject = RectMake(obj[83].x, obj[83].y, obj[83].width, obj[83].height);

	// 6�� �� ��ֹ� 7
	obj[84].x = WINSIZEX + (WINSIZEX / 8 * 7) - (WALL_SIZE / 2);
	obj[84].y = (WINSIZEY * 2) + (WINSIZEY / 4) - (WALL_SIZE / 2);
	obj[84].width = WALL_SIZE;
	obj[84].height = WALL_SIZE;
	obj[84].isAlive = true;
	obj[84].isWall = true;
	obj[84].isItem = false;
	obj[84].rcObject = RectMake(obj[84].x, obj[84].y, obj[84].width, obj[84].height);

	// 6�� �� ��ֹ� 8
	obj[85].x = WINSIZEX + (WINSIZEX / 3) - (WALL_SIZE / 2);
	obj[85].y = (WINSIZEY * 2) + (WINSIZEY / 4 * 3) - (WALL_SIZE / 2);
	obj[85].width = WINSIZEX / 3 + WALL_SIZE / 2;
	obj[85].height = WALL_SIZE;
	obj[85].isAlive = true;
	obj[85].isWall = true;
	obj[85].isItem = false;
	obj[85].rcObject = RectMake(obj[85].x, obj[85].y, obj[85].width, obj[85].height);



	return true;
}

void GameObject::Release()
{

}

void GameObject::Update(Bullets & inputBullets, Player & inputPlayer, Enemy & inputEnemy)
{
	HitEvent(inputBullets, inputPlayer, inputEnemy);
}

void GameObject::Render(HDC hdc)
{
	for (int i = 0; i < MAX_OBJECT; i++)
	{
		// isAlive�� false�� ���, �������� �ѱ��.
		if (!obj[i].isAlive)
			continue;

		Rectangle(hdc, obj[i].rcObject.left - CAMERA->getPosition()->x, obj[i].rcObject.top - CAMERA->getPosition()->y, obj[i].rcObject.right - CAMERA->getPosition()->x, obj[i].rcObject.bottom - CAMERA->getPosition()->y);
		

		if (obj[i].image != NULL)
			obj[i].image->FrameRender(hdc, obj[i].x - obj[i].width/2 - CAMERA->getPosition()->x, obj[i].y - obj[i].height/2 - CAMERA->getPosition()->y);
	}
}




void GameObject::HitEvent(Bullets & inputBullets, Player & inputPlayer, Enemy & inputEnemy)
{
	HitBullets(inputBullets);
	HitPlayerEnemy(inputPlayer, inputEnemy);
	HitItem(inputPlayer);
}

void GameObject::HitBullets(Bullets & inputBullets)
{
	for (int i = 0; i < MAX_OBJECT; i++)
	{
		// isAlive�� false�� ���, �������� �ѱ��.
		if (!obj[i].isAlive)
			continue;

		if (obj[i].isWall)
		{
			inputBullets.HitCollisionRect(obj[i].rcObject, true, obj[i].isAlive);
			inputBullets.HitCollisionRect(obj[i].rcObject, false, obj[i].isAlive);
		}
	}
}

// ���� ���� �浹�� ���, �÷��̾ �� �̻� �̵����� �ʵ��� �ϴ� �κ�
void GameObject::HitPlayerEnemy(Player & inputPlayer, Enemy & inputEnemy)
{
	// �÷��̾�� ���� �� �浹�� ���� ���� ���� �κ�
	for (int i = 0; i < MAX_OBJECT; i++)
	{
		if (!obj[i].isAlive)
			continue;

		if (!obj[i].isWall)
			continue;

		// �÷��̾�� ���� �浹�� ���, �÷��̾ ���̻� �̵����� �ʵ��� �ϴ� �κ�
		if (CollisionRectAndRect(inputPlayer.CollisionRECT(), obj[i].rcObject))
		{
			int result = HitTest(inputPlayer.CollisionRECT(), obj[i].rcObject);

			// X�κ�
			if ((inputPlayer.CollisionRECT().left < obj[i].rcObject.left) && (inputPlayer.CollisionRECT().right > obj[i].rcObject.left) && result == 1)
			{
				inputPlayer.SetX(obj[i].rcObject.left - inputPlayer.GetRadius());
			}
			if ((inputPlayer.CollisionRECT().left < obj[i].rcObject.right) && (inputPlayer.CollisionRECT().right > obj[i].rcObject.right) && result == 1)
			{
				inputPlayer.SetX(obj[i].rcObject.right + inputPlayer.GetRadius());
			}

			// Y�κ�
			if ((inputPlayer.CollisionRECT().top < obj[i].rcObject.top) && (inputPlayer.CollisionRECT().bottom > obj[i].rcObject.top) && result == 2)
			{
				inputPlayer.SetY(obj[i].rcObject.top - inputPlayer.GetRadius());
			}

			if ((inputPlayer.CollisionRECT().top < obj[i].rcObject.bottom) && (inputPlayer.CollisionRECT().bottom > obj[i].rcObject.bottom) && result == 2)
			{
				inputPlayer.SetY(obj[i].rcObject.bottom + inputPlayer.GetRadius());
			}
		}


		for (int EnemyIndex = 0; EnemyIndex < MAX_MONSTER; EnemyIndex++)
		{
			// ���� ���� �浹�� ���, �÷��̾ ���̻� �̵����� �ʵ��� �ϴ� �κ�
			if (CollisionRectAndRect(inputEnemy.CollisionRECT(EnemyIndex), obj[i].rcObject))
			{
				int result = HitTest(inputEnemy.CollisionRECT(EnemyIndex), obj[i].rcObject);

				// X�κ�
				if ((inputEnemy.CollisionRECT(EnemyIndex).left < obj[i].rcObject.left) && (inputEnemy.CollisionRECT(EnemyIndex).right > obj[i].rcObject.left) && result == 1)
				{
					inputEnemy.SetX(EnemyIndex, (obj[i].rcObject.left - inputEnemy.GetRadius(EnemyIndex) - inputEnemy.GetCheckRealPos(EnemyIndex)));
				}
				if ((inputEnemy.CollisionRECT(EnemyIndex).left < obj[i].rcObject.right) && (inputEnemy.CollisionRECT(EnemyIndex).right > obj[i].rcObject.right) && result == 1)
				{
					inputEnemy.SetX(EnemyIndex, (obj[i].rcObject.right + inputEnemy.GetRadius(EnemyIndex) - inputEnemy.GetCheckRealPos(EnemyIndex)));
				}

				// Y�κ�
				if ((inputEnemy.CollisionRECT(EnemyIndex).top < obj[i].rcObject.top) && (inputEnemy.CollisionRECT(EnemyIndex).bottom > obj[i].rcObject.top) && result == 2)
				{
					inputEnemy.SetY(EnemyIndex, (obj[i].rcObject.top - inputEnemy.GetRadius(EnemyIndex) - inputEnemy.GetCheckRealPos(EnemyIndex)));
				}

				if ((inputEnemy.CollisionRECT(EnemyIndex).top < obj[i].rcObject.bottom) && (inputEnemy.CollisionRECT(EnemyIndex).bottom > obj[i].rcObject.bottom) && result == 2)
				{
					inputEnemy.SetY(EnemyIndex, (obj[i].rcObject.bottom + inputEnemy.GetRadius(EnemyIndex) - inputEnemy.GetCheckRealPos(EnemyIndex)));
				}
			}
		}
	}
}

// �÷��̾�� �����۰� �浹�� ���, �ش� �������� �������.
bool GameObject::HitItem(Player & inputPlayer)
{
	// �÷��̾�� ������ �浹�� ���� ������ ȿ��
	for (int i = 0; i < MAX_OBJECT; i++)
	{
		if (!obj[i].isAlive)
			continue;

		if (!obj[i].isItem)
			continue;

		// �÷��̾�� ���� �浹�� ���, �÷��̾ ���̻� �̵����� �ʵ��� �ϴ� �κ�
		if (CollisionRectAndRect(inputPlayer.CollisionRECT(), obj[i].rcObject))
		{
			obj[i].isAlive = false;

			inputPlayer.SetHpAdd();		// �÷��̾� ü�� 1ȸ��
//			inputPlayer.SetHp(2);		// �÷��̾� ü�� 2ȸ��

			return true;
		}
	}

	return false;
}


int GameObject::HitTest(const RECT& r1, const RECT& r2)
{
	RECT t;
	int w, h;

	if (IntersectRect(&t, &r1, &r2))
	{
		w = t.right - t.left;
		h = t.bottom - t.top;

		if (w < h)
			return 1;
		else
			return 2;
	}
	else
		return 0;
}