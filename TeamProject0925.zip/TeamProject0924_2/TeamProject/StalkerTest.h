#pragma once

#include "GameNode.h"
#include "GameHeader.h"

#include "Bullets.h"
#include "Player.h"
#include "Enemy.h"
#include "GameObject.h"


class StalkerTest : public GameNode
{
	RECT	_rcWorld;
	RECT	_rcClient;

	Player*		player;
	Enemy*		enemy;

	Bullets*	bullets;
	GameObject*	gameObject;

	int			HitPlayer;		// �׽�Ʈ��
	int			HitWall;		// �׽�Ʈ��

public:
	StalkerTest();
	~StalkerTest();

	virtual bool Init();
	virtual void Release();
	virtual void Update();
	virtual void Render(HDC hdc);
/////////////////////////////

	void HitEvent();				// źȯ�� ���� ��쿡 ���� �浹ó�� �̺�Ʈ �Լ� 
};

